# HOW TO – werken met deze vault

Deze vault is ingericht voor het schrijven van ICT Institute-rapporten. Je schrijft in Markdown, ziet naast de tekst direct het rapport in de huisstijl en exporteert met één klik een PDF. Alles werkt offline.

Alles van een rapport staat in de notitie zelf, in Markdown: de voorkant, de tekst, en ook gegevens van de klant of contactpersonen als je die wilt vermelden. Zo blijft een rapport ook zonder Obsidian leesbaar en te bewerken, bijvoorbeeld in Notepad++.

> [!tip] In het kort
> 1. **Nieuw rapport** in het ICT Institute-paneel (linksboven).
> 2. Kies klantproject of intern project, de map en een documentnaam.
> 3. Pas het voorblad bovenaan aan en vul de rode plaatshouders in.
> 4. Klik op **PDF exporteren** boven het voorbeeld.

## Wat staat waar

| Map | Inhoud |
|---|---|
| `00. Start/` | De sjablonen, de opmaak en andere vaste bestanden. |
| `01. Internal projects/` | Eén map per intern project, met de rapporten daarin. |
| `02. Client Projects/` | Eén map per klant of project, met de rapporten daarin. |
| De sjablonenmap | De rapportsjablonen. Elke notitie hier is een sjabloon bij *Nieuw rapport*. |
| De opmaakmap | De opmaak van het rapport (`report.typ`) en de afbeeldingen (`assets/`). Alleen aanpassen als je weet wat je doet. |

Welke mappen dit precies zijn, staat in *Instellingen → ICT Institute Reports → Mappen*.

## Het ICT Institute-paneel

Linksboven, boven de bestandenlijst, staat het paneel met de belangrijkste acties:

| Knop | Wat het doet |
|---|---|
| **Nieuw rapport** | Maakt een rapport aan vanuit een sjabloon (zie hieronder). |
| **Word-rapport importeren** | Maakt van een bestaand Word-rapport (.docx) een rapportsjabloon (zie *Een sjabloon toevoegen*). |
| **Rapportvoorbeeld openen** | Toont het rapport in de huisstijl naast de tekst. |
| **Zoeken** | Zoekt een notitie op naam (de snelle wisselaar van Obsidian). |
| **Opdrachtenpalet** | Alle opdrachten van Obsidian en ICT Institute. |
| **Zoom notitie** − 100% + | Maakt de tekst van de geopende notitie groter of kleiner; de rest van Obsidian blijft gelijk. Elke notitie onthoudt haar eigen zoom, alleen op je eigen computer. Klik op het percentage om terug te gaan naar 100%. |

**Log**, **Voorblad**, **Omslagafbeelding**, **Kop**, **Inhoud** en **PDF exporteren** zijn knoppen boven het rapportvoorbeeld.

Paneel per ongeluk gesloten? Open het opdrachtenpalet (`Ctrl+P`) en kies **ICT Institute-menu tonen**. Alle acties staan ook in het opdrachtenpalet; typ bijvoorbeeld `rapport`.

## Een nieuw rapport maken

1. Klik op **Nieuw rapport**.
2. Kies het **sjabloon** (alleen als er meer dan één is): *Eenvoudig rapport* (Nederlands) of *Simple report* (Engels).
3. Kies **Intern project** of **Klantproject**.
4. Kies de **map** van het project of de klant. Bestaat die nog niet, typ dan de naam en kies *Map "…" maken*. Met een schuine streep maak je een map in een map, bijvoorbeeld `ABC/Audit 2026`.
5. Typ de **documentnaam**, bijvoorbeeld *ISO 27001 interne audit 2026*, en druk op Enter. Dit wordt de naam van de notitie en van de PDF.

Het rapport opent met het voorbeeld ernaast. Titel en datum staan al op het voorblad. Rode tekst is nog in te vullen.

## Markdown of opgemaakt: de schuifknop

Rechtsboven in elke notitie staat een kleine schuifknop **Markdown**:

- **Aan**: je ziet de Markdown-code zelf, in één lettertype, zoals in Notepad++. Handig om precies te zien wat er staat.
- **Uit**: je ziet de notitie zoals gewoonlijk, met koppen, vet en tabellen opgemaakt (Live Preview). Je kunt in beide gewoon typen.

## Lettergrootte

Alle tekst in een rapport is 11 punt, tekst in tabellen 10 punt. Koppen, het voorblad en de kop- en voettekst van de pagina's hebben hun eigen grootte.

## Het voorblad

Het voorblad is een blok bovenaan de notitie:

```
> [!cover]
> # Informatiebeveiligingsregels
> Rapport voor ABC B.V.
> 13 november 2026
> ![Cover](../Afbeeldingen/abc-logo.png)
> Opgesteld voor ABC B.V.
> Jan Jansen, CISO
```

- De regel met `#` is de **titel**. Zonder kop-blok staat die ook linksboven op alle andere pagina's. De titel krijgt vanzelf de grootste lettergrootte waarbij hij tussen de balken past: een korte titel wordt groot, een lange kleiner of over meer regels.
- De eerste regel daarna is de **ondertitel**, de tweede de kleine regel eronder (meestal de datum). Ze staan tussen de blauwe balken, zoals in het Word-sjabloon.
- **Elke volgende regel** staat onder de balken, onder elkaar. Hier zet je bijvoorbeeld de auteur, voor wie het rapport is of de classificatie. Een lege regel (`>`) tussen twee van deze regels blijft een lege regel.
- De **afbeelding** is de omslagafbeelding bovenaan de pagina, passend gemaakt zonder uit te rekken. Een nieuw rapport heeft hier de regel met de standaardafbeelding, zodat je in de Markdown altijd ziet welke afbeelding op het voorblad staat. Zonder afbeeldingsregel staat er ook de standaardafbeelding.

In Obsidian zie je het blok als een blauw kader; in andere programma's als een citaat. De knop **Voorblad** boven het voorbeeld zet zo'n blok bovenaan de notitie, of haalt het weg (met `Ctrl+Z` in de notitie krijg je het terug). Zonder voorblad begint het rapport op pagina 1.

**Omslagafbeelding** boven het voorbeeld: kies een afbeelding uit de vault of van je computer. De plugin schrijft hem als gewone Markdown-afbeelding in het voorblad (`![Cover](…)`, met het pad vanaf de notitie). *Standaardafbeelding gebruiken* zet de regel met de standaardafbeelding terug.

## De kop van de pagina's

Linksboven op elke pagina (behalve het voorblad) staan twee regels. Die schrijf je in een kop-blok:

```
> [!header]
> Project: ISO 27001 interne audit – ABC B.V.
> Document: Rapport
```

- De **eerste regel** is de bovenste regel van de kop, de **tweede regel** de regel eronder. Ze kunnen vet, cursief of rood zijn.
- Een derde regel komt niet in het rapport (het voorbeeld waarschuwt).
- Zonder kop-blok staat in de kop de titel van het rapport.

De sjablonen hebben een kop-blok onder het voorblad. In Obsidian zie je het als een groenblauw kader. De knop **Kop** boven het voorbeeld zet zo'n blok onder het voorblad, of haalt het weg (met `Ctrl+Z` in de notitie krijg je het terug).

## De inhoudsopgave

De inhoudsopgave wordt automatisch gemaakt. Een blok `> [!inhoud]` in de notitie geeft aan waar hij komt. In de PDF staan daar alle hoofdstukken (kop 1) en paragrafen (kop 2, ingesprongen) met hun paginanummer. Voeg je een hoofdstuk toe of verander je een kop, dan werkt de inhoudsopgave zichzelf bij.

```
> [!inhoud]

\pagebreak
```

De knop **Inhoud** boven het voorbeeld zet de inhoudsopgave aan of uit: hij zet het blok met een `\pagebreak` onder het voorblad en de kop, of haalt ze weg (met `Ctrl+Z` in de notitie krijg je ze terug). Wil je een andere titel dan *Inhoud*, zet die achter het blok: `> [!inhoud] Inhoudsopgave`. De sjablonen hebben er een, en de Word-import ook.

Rapporten met de oude, met de hand geschreven inhoudstabel houden die tabel. Vervang hem door het blok (of druk op **Inhoud** en haal de oude tabel weg) als je automatische paginanummers wilt.

## Eigenschappen

Een rapport heeft geen eigenschappen nodig. Eén doet nog iets:

| Eigenschap | Betekenis |
|---|---|
| `language` | `nl` of `en`: taal van de vaste teksten in het rapport. Standaard Engels; het Nederlandse sjabloon heeft `language: nl`. |

## Schrijven

| Je typt | In het rapport |
|---|---|
| `# Kop` en `## Subkop` | Hoofdstuk en paragraaf |
| `**vet**`, `*cursief*` | **vet**, *cursief* |
| `- punt` of `1. punt` | Opsomming |
| `==nog invullen==` | Rode plaatshoudertekst (de export waarschuwt dat er nog iets in te vullen is) |
| `<span style="color:red">tekst</span>` | Rode tekst met opzet: ook rood in Obsidian, en geen waarschuwing bij de export |
| `> [!note] Titel` met regels eronder | Een citaatblok met een vette titel |
| `\pagebreak` op een eigen regel | Nieuwe pagina |
| `![[afbeelding.png]]`, `![[afbeelding.png\|300]]` of `![](map/afbeelding.png)` | Afbeelding (optioneel 300 pt breed) |
| `<br>` in een tabelcel | Nieuwe regel in de cel |

**Tabellen** krijgen allemaal dezelfde stijl, met een blauwe koprij. Je kunt ze gewoon bewerken met de tabeleditor van Obsidian. Contactgegevens of versiebeheer zet je, als je ze nodig hebt, gewoon als tabel of tekst in het rapport.

## Voorbeeld en export

- Het **voorbeeld** wordt een halve seconde nadat je stopt met typen bijgewerkt. Meldingen staan boven de pagina's; klik op een melding om naar de regel in de tekst te gaan.
- **Exporteren** slaat de PDF naast het rapport op, met de datum, de map en de documentnaam, bijvoorbeeld `20261109_ABC_ISO 27001 interne audit 2026.pdf`. Hernoem je de notitie, dan verandert de naam van de PDF mee.
- Staat er nog rode plaatshoudertekst in het rapport (ook op het voorblad), dan vraagt de export eerst of je die wilt zien, toch wilt exporteren of wilt annuleren.

> [!warning] Let op
> Obsidian heeft ook een eigen export naar PDF (*Export to PDF*). Die gebruikt de huisstijl **niet**. Gebruik altijd de knop **PDF exporteren** boven het voorbeeld van ICT Institute.

## Log

Elke notitie heeft een log. Klik op **Log** boven het voorbeeld (of kies *Log* in het opdrachtenpalet) en je ziet wanneer de notitie is aangemaakt en wie daarna wat heeft gewijzigd:

- **Bewerkt**: welke hoofdstukken en eigenschappen zijn veranderd, met daaronder precies wat er veranderde: per hoofdstuk de verwijderde regels (rood, −) en toegevoegde regels (groen, +). Wijzigingen door dezelfde persoon binnen 15 minuten staan samen op één regel.
- **Hernoemd** en **Geëxporteerd naar PDF** (met de naam van de PDF).

Je naam in de log stel je één keer in: Obsidian vraagt erom bij je eerste wijziging, en je kunt hem aanpassen onder *Instellingen → ICT Institute Reports → Je naam*. De naam wordt alleen op je eigen computer bewaard, zodat elke collega in een gedeelde vault zijn eigen naam heeft.

De log staat in de verborgen map `.logboek` in de vault. Die map zie je niet in Obsidian en komt nooit in een rapport, maar wordt wel mee gesynchroniseerd.

## Een sjabloon toevoegen

**Vanuit Word:** klik op **Word-rapport importeren** en kies een of meer .docx-bestanden. Elk bestand wordt een sjabloon in de sjablonenmap en verschijnt meteen bij *Nieuw rapport*. Het Word-voorblad wordt een voorblad-blok met de titel en ondertitel uit Word. De rest blijft zoals hij is, ook hoofdstukken als *Contactgegevens* en *Versiebeheer*: koppen, alinea's, vet en cursief, lijsten, tabellen, links en afbeeldingen (in de submap *Afbeeldingen*). Gemarkeerde (in elke kleur) of rode tekst wordt rode plaatshoudertekst (`==tekst==`). De inhoudsopgave uit Word wordt vervangen door de automatische inhoudsopgave. Koppen die Word automatisch nummerde, worden opnieuw genummerd. Opmerkingen, bijgehouden verwijderingen, verborgen tekst en documenteigenschappen (zoals auteurs) worden niet overgenomen. Lees het sjabloon daarna even na: namen en gegevens uit het oorspronkelijke rapport staan er nog in.

**Zelf:** kopieer een sjabloon in de sjablonenmap naar een nieuwe naam (bijvoorbeeld `Pre-audit.md`) en pas het aan. Het verschijnt meteen bij *Nieuw rapport*. In sjablonen kun je deze velden gebruiken; ze worden ingevuld bij het aanmaken:

| Veld | Wordt |
|---|---|
| `{{title}}` | De documentnaam die je koos |
| `{{long_date}}` | De datum van vandaag, uitgeschreven (*13 november 2026*; Engels in een sjabloon zonder `language: nl`) |
| `{{date}}`, `{{year}}` | De datum (JJJJ-MM-DD) en het jaar van vandaag |
| `{{folder}}` | De naam van de map van de klant of het project |
| `{{type}}` | De naam van het sjabloon |

## Handige instellingen

- **Spellingcontrole:** *Instellingen → Editor →* talen voor spellingcontrole (*Settings → Editor → Spellcheck languages*): voeg Nederlands en Engels toe.
- **Taal van Obsidian:** *Instellingen → Algemeen → Taal* (*Settings → General → Language*) → Nederlands, daarna Obsidian herstarten.
- **Plugin-instellingen:** *Instellingen → ICT Institute Reports*: mappen, PDF-map en -bestandsnaam, vertraging van het voorbeeld en de taal van de plugin. Na een update van de plugin: **Opmaak bijwerken** en **Startbestanden installeren** (voegt nieuwe sjablonen toe, bestaande bestanden blijven staan).

## Problemen oplossen

| Probleem | Oplossing |
|---|---|
| Het voorbeeld toont meldingen | Klik op de melding: je springt naar de regel. |
| Een afbeelding ontbreekt | Controleer de bestandsnaam en het pad; de afbeelding moet in de vault staan. |
| Het ICT Institute-paneel is weg | `Ctrl+P` → **ICT Institute-menu tonen**. |
| De PDF heeft niet de huisstijl | Je gebruikte de eigen export van Obsidian; gebruik **PDF exporteren** boven het voorbeeld. |
| Na een update van de plugin geeft het voorbeeld een melding over de opmaak, of iets nieuws werkt niet | *Instellingen → ICT Institute Reports →* **Opmaak bijwerken**. De oude opmaak blijft bewaard als `report.typ.bak`. |
| De plugin geeft een foutmelding of een knop doet niets | Fouten van de plugin staan in `.obsidian/plugins/icti-reports/errors.log` in de vault. Stuur dat bestand mee als je het probleem meldt. |
| Een presentatie opent als gewone tekst | Controleer of bij de eigenschappen `presentation: true` staat, of klik op de knop **Openen als presentatie** rechtsboven in het tabblad. |
| De presentatie-plugin geeft een fout | Fouten staan in `.obsidian/plugins/icti-presentations/errors.log`. Stuur dat bestand mee als je het probleem meldt. |
| De iconenbalk links is weg | Dat is zo ingesteld; terugzetten via de instelling voor het lint onder *Weergave* (*Settings → Appearance → Show ribbon*). |
