---
language: nl
---

> [!cover]
> # {{title}}
> ==Ondertitel, bijvoorbeeld: Rapport voor de naam van de klant==
> {{long_date}}

> [!header]
> Project: {{title}}
> ==Document: Rapport==

> [!inhoud]

\pagebreak

# Inleiding

==Doel van dit rapport en wat het behandelt.==

# ==Hoofdstuk==

==Tekst.==

## ==Paragraaf==

==Tekst.==

# Conclusie

==Conclusie en aanbevelingen.==
