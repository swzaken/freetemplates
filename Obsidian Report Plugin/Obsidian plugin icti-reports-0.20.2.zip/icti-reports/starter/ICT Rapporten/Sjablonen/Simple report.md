> [!cover]
> # {{title}}
> ==Subtitle, for example: Report for the client's name==
> {{long_date}}

> [!header]
> Project: {{title}}
> ==Document: Report==

> [!contents]

\pagebreak

# Introduction

==Purpose of this report and what it covers.==

# ==Chapter==

==Text.==

## ==Section==

==Text.==

# Conclusion

==Conclusion and recommendations.==
