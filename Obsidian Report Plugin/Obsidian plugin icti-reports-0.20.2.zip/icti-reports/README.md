# ICT Institute Reports

An Obsidian plugin for writing reports in Markdown, with a live preview in a professional report style and one-click PDF export. Everything runs inside Obsidian and fully offline: the [Typst](https://typst.app) typesetting engine, fonts and artwork are in the plugin folder.

A report is a plain `.md` file: readable in any editor and easy to keep in git.

- **Get started:** [docs/HOW-TO.md](docs/HOW-TO.md) (install, first report, your own look)
- **The format:** [docs/REPORT-FORMAT.md](docs/REPORT-FORMAT.md) (cover, header, contents, placeholders, tables)
- **Licence:** [CC BY 4.0](LICENSE), © ICT Institute. Third-party parts: [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md)

The rest of this file is the full reference manual.

---

## Install

1. Close Obsidian. Copy the folder `icti-reports` into `<your vault>/.obsidian/plugins/` (create `plugins` if needed).
2. Start Obsidian. Go to *Settings → Community plugins*. If it says **Restricted mode**, click **Turn on community plugins**. Then switch on **ICT Institute Reports**.
3. In *Settings → ICT Institute Reports*, click **Install starter files**. This adds the layout, the two report templates and a Dutch **HOW TO** note at the top of the vault that explains how to work with it. Nothing is ever overwritten.
4. **Spelling check.** Obsidian checks spelling with the languages set in *Settings → Editor → Spellcheck languages*; add Dutch (Nederlands) and English so both kinds of reports are checked.
5. **Dutch.** The plugin's own commands, settings and messages are in Dutch by default (*Taal van de plugin* in its settings; English is available). Obsidian's own menus are an app-wide setting that a plugin cannot change: go to *Settings → General → Language*, choose **Nederlands** and restart Obsidian. Reports themselves follow each note's `language` property (`nl` or `en`).

To update the plugin, replace the `icti-reports` folder and restart Obsidian. Your settings are kept in its `data.json`; copy that file over too if you replace the whole folder. Then, in *Settings → ICT Institute Reports*, click **Update layout** (replaces the vault's `report.typ` with the new built-in layout and keeps the old one as `report.typ.bak`) and **Install starter files** (adds new templates; existing files are kept). A layout from before version 0.12 cannot read the simple report: until you update it, the built-in layout is used and the preview says so.

> Obsidian also has a built-in *Export to PDF*. That one does **not** use the house style. Use **ICT Institute Reports: Export report to PDF** (type `ICT` in the command palette) or the ribbon icon.

## Use

There is one kind of report: a cover page (optional), a page header and your own text, including an automatic table of contents if you want one. Everything about the report is written in the note itself, in Markdown, so it can also be read and edited without Obsidian (for example in Notepad++). Client details, contact persons or a version history are ordinary text or tables in the note.

Command names below are the English ones; in Dutch they are *Nieuw rapport*, *Rapportvoorbeeld openen*, *Voorblad toevoegen of verwijderen*, *Kop toevoegen of verwijderen*, *Omslagafbeelding wijzigen*, *Word-rapport importeren als sjabloon* and *Rapport exporteren naar PDF*.

**ICT Institute panel.** On first start the plugin puts a panel with the main actions (new report, import Word report, preview, search, command palette, and a *Zoom note* row with − / 100% / + that zooms only the open note, remembered per note on this computer (Obsidian's local storage, not the shared settings); also available as commands for your own hotkeys; export and the cover buttons are above the preview) at the top of the left sidebar, above the file list, and hides Obsidian's separate icon bar so everything is in one column. Drag the divider to resize it. Closed it? *ICT Institute-menu tonen* (Show ICT Institute menu) in the command palette brings it back; *Settings → Appearance → Show ribbon* brings back the icon bar.

- **New report** (command, ribbon or panel): pick a template (only asked when there is more than one), then **Internal project** or **Client project**, then a folder inside it: an existing one, or type a name to create it (one folder per client or project; `ABC/Audit 2026` makes a folder inside a folder). Then the document name (the name of the note and of the PDF). The note is created from the template and opens next to the preview. The main folders are `01. Internal projects` and `02. Client Projects` by default (*Settings → Folders*); next to them, `00. Start` holds the templates, the layout and this kind of reference material.
- **Markdown slider** (in the header of every note, next to the other buttons): on = the Markdown code itself, in one monospace font like Notepad++ (Obsidian's Source mode); off = the note as it normally shows (Live Preview). Switching with Obsidian's own command moves the slider too.
- **Open report preview**: the branded report next to the editor, updated half a second after you stop typing. Problems are listed above the pages; click one to jump to the line.
- **Cover page** (button above the preview, or the command *Add or remove cover page*): adds a cover block at the top of the note, or removes it (Ctrl+Z in the note brings it back). See *The cover page* below.
- **Header** (button *Kop* above the preview, or the command *Add or remove header block*): adds a header block under the cover block (or at the top of the note), or removes it. See *The page header* below.
- **Contents** (button *Inhoud* above the preview, or the command *Add or remove table of contents*): adds the automatic table of contents under the cover and header blocks (with a page break after it), or removes it. See *The table of contents* below.
- **Cover image** (button above the preview, or the command *Change cover image*): pick an image from your vault, or *Choose an image from this computer…* (it is copied into the vault's attachment folder). It is written into the cover block as an ordinary Markdown image, `> ![Cover](../Images/logo.png)`, with the path relative to the note. *Use the standard picture* writes the standard picture into the block. Without a cover block, one is added with the picture.
- **Import Word report** (panel or command *Import Word report as template*): pick one or more .docx files; each becomes a report template in the templates folder (pictures in its *Images*/*Afbeeldingen* subfolder) and shows up in **New report**. The Word cover (everything before the first heading 1) becomes a cover block with the Word title and subtitle; Word's table of contents is replaced by the automatic table of contents. Everything else is kept, also chapters such as contact details and version history: headings, paragraphs, bold/italic, lists, tables, links, pictures and footnotes; highlighted or red text becomes `==placeholder==`. Heading numbers that Word added automatically are renumbered. Comments, tracked deletions, hidden text and document properties (such as authors) are never read. Nothing is overwritten. If the templates folder had no templates yet, the built-in ones are copied in first, so they stay available.
- **Change log** (button *Log* above the preview, or the command): when the note was created and every later change and by whom. Edits by one person within 15 minutes form one entry with the changed chapters and properties, the characters added/removed, and exactly what changed (removed and added lines per chapter, up to 300 lines per entry); renames and PDF exports are logged too. Each colleague sets their name once (asked at the first change, or *Settings → Your name*); it is stored per computer (Obsidian's local storage), not in the shared plugin settings. The log is one JSON file per note in the hidden vault folder `.logboek`, so it syncs with a shared vault but never shows in the file list or a report. Only changes made in Obsidian with the plugin on are logged; a change that arrives through a sync program is logged on the computer where it was made.
- **Before export**: if the report still contains red `==placeholder==` text (also on the cover), export asks whether to show the first one, export anyway or cancel. The preview lists the number of places left.
- **Export report to PDF**: saves the PDF next to the note, named `YYYYMMDD_folder_document name.pdf`: today's date, the name of the folder the note is in (the client or project folder) and the note's name (folder and name pattern are in the settings).

**The cover page** is a block at the top of the note:

```
> [!cover]
> # Information security rules
> Report for ABC B.V.
> 13 November 2026
> ![Cover](../Images/abc-logo.png)
> Prepared for ABC B.V.
> Jan Jansen, CISO
```

The heading is the title (without a header block it is also printed at the top left of every other page). The first line below it is the subtitle and the second line the small line under it (normally the date); they sit between the navy bars like in the Word template. The title takes the largest size at which it fits between the bars (40 pt at most, 12 pt at least): a short title is printed big, a long one smaller or on more lines, and it never runs past the edge or the bars. Every further line is printed below the bars, one under the other; an empty line in the block between two of these lines stays an empty line. The picture is the cover image, scaled to fit at the top of the page without being stretched. New report and the **Cover page** button write the standard picture (`assets/cover-default.png` next to the layout) into the block, so the Markdown always shows which picture is used; a cover block without a picture line, or with one that cannot be found, also gets the standard picture. In Obsidian the block shows as a navy box; in other Markdown programs as a quote. Delete the block (or use the **Cover page** button) and the report has no cover: it then starts on page 1. A second cover block is ignored with a warning. Old reports that still use the properties `title`, `subtitle`, `voorblad` and so on print without a cover until they get a cover block.

**Text sizes.** All text in a report is 11 pt (also code), text in tables is 10 pt. Headings, the cover and the page header and footer have their own sizes.

**The page header** (the two lines at the top left of every page after the cover) is a block too:

```
> [!header]
> Project: ISO 27001 internal audit – ABC B.V.
> Document: Report
```

The first line is the top line, the second line the one under it; each can have bold, italic or red text. A third line is ignored with a warning, a second header block too. Without a header block the header shows the title. The templates have a header block under the cover block.

**The table of contents** is generated: a `> [!inhoud]` block (or `> [!contents]`) in the note marks where it goes. The PDF lists every chapter (heading 1) and section (heading 2, indented) with its page number at that spot, and it updates by itself when you add or rename headings. Text after the marker is its own title (`> [!inhoud] Inhoudsopgave`); without it the title is *Inhoud* or *Contents* (by `language`). Turn it on or off with the **Inhoud** button above the preview: it adds the block plus a `\pagebreak` under the cover and header blocks, or removes them. The templates and the Word import have one:

```
> [!header]
> Project: …
> Document: …

> [!inhoud]

\pagebreak

# 1. Introduction
```

Without the plugin the block reads as a quote with the word *inhoud*. A second contents block gives a warning. Reports written with the old hand-written contents table keep it; replace it with the block (or press *Inhoud*) to get page numbers that update.

**Properties.** A report needs none. One is still read: `language` (`nl` gives Dutch labels; default English). The old `inhoudsopgave` property does nothing any more.

**Markdown conventions**

| Write | Result |
|---|---|
| `# Heading`, `## Heading` | Report headings |
| `> [!cover]` block at the top | The cover page (see above) |
| `> [!header]` block | The two header lines (see above) |
| `==text to fill in==` | Red placeholder text (export warns that it is still there) |
| `<span style="color:red">text</span>` | Red text on purpose: red in Obsidian too, no placeholder warning. Only this form is read (also `#f00`, `#ff0000`, `rgb(255, 0, 0)`); other HTML stays literal text |
| `> [!note] Title` + lines (any callout type) | A quote with a bold title |
| `<br>` inside a table cell | Line break in the cell |
| `\|------\|---------\|` (different dash counts) | Relative column widths (each column counts as 4–30 dashes, so tables edited with Obsidian's table editor keep usable widths) |
| `\pagebreak` on its own line | New page |
| `![[image.png]]`, `![[image.png\|300]]`, `![](folder/image.png)`, `![](../image.png)` | Image (optionally 300 pt wide); a relative path may point to another folder of the vault, never outside it |

Raw Typst is not supported on purpose: note text is always printed literally.

## ICT Institute theme for Obsidian

`dist/themes/ICT Institute` is an Obsidian theme in the house style of ictinstitute.nl: Open Sans (embedded, so it works offline), the teal of the logo for links and accents, H1 headings on a grey band, small uppercase H3 section labels, square buttons, report-style tables with a teal header row, and `==highlights==` in red like placeholders in the PDF. It has a light and a dark mode.

Install: copy the folder `ICT Institute` into `<your vault>/.obsidian/themes/`, then pick it in *Settings → Appearance → Themes*. The theme and the plugin are independent; each works without the other.

**Labels next to the ribbon icons:** copy `dist/snippets/ICT Institute - ribbon labels.css` into `<your vault>/.obsidian/snippets/` and switch it on in *Settings → Appearance → CSS snippets*. The left ribbon then shows each icon's name (the same text as its tooltip, in Obsidian's language). Switch it off to get the narrow icon bar back. To hide icons you don't need (for example *Nieuw canvas maken*, *Dagelijkse notitie openen* and *Sjabloon invoegen*), use *Settings → Appearance → Ribbon → Manage* in each vault; the features stay available through the command palette.

## Add a report template

There are two starter templates: *Simple report* (English) and *Eenvoudig rapport* (Dutch, `language: nl`), each with a cover block, a header block and red placeholder text. Copy one of them to a new name in the templates folder, for example `Pre-audit.md`, and edit it, or import a Word report. Every note in the templates folder is a template in **New report**. Templates can use `{{title}}` (the document name), `{{long_date}}` (today, written out in the template's language), `{{date}}` (YYYY-MM-DD), `{{year}}`, `{{folder}}` (the client or project folder) and `{{type}}` (the template's name); in properties, keep them inside double quotes. The page design itself is `report.typ` (Typst) in the layout folder, with its artwork (`header-logo.png`, `cover-default.png`) in the `assets` folder next to it. The repository ships neutral placeholder artwork: replace `assets/cover-default.png` in the layout folder of your vault (or `assets/img/` before building) with your own picture.

## Build from source (maintainers)

Needs Node.js 20+ (development machine only). In the repository:

```
npm ci            # installs exact versions from package-lock.json; install scripts are disabled (.npmrc)
npm test          # unit tests and render tests
npx tsc --noEmit  # type check
npm run build     # -> dist/icti-reports (the plugin folder) and dist/vault-starter
node tools/check-offline.mjs   # fails on any unexplained network or code-execution pattern in the bundle
```

`npm run render -- <note.md> [out.pdf] [--vault dir]` renders a note from the command line. After upgrading the Typst engine, refresh the notices with `py tools/crate-licenses.py` and `node tools/notices.mjs`. A release is the zipped `dist/icti-reports` folder.

## Troubleshooting

Errors from the plugin are written to `.obsidian/plugins/icti-reports/errors.log` (repeats are counted, the file stays under 200 KB). Obsidian otherwise only shows them in its developer console (Ctrl+Shift+I).
