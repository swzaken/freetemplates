// ICT Institute report layout (Typst).
// layout-version: 16  (raise this when the plugin needs a newer layout; older vault copies then get a warning)
// The plugin provides /meta.json (language, title, header, cover) and /doc.json (the note as a document tree).
// Note text only ever arrives as JSON strings, which Typst prints literally: it is never evaluated as code.
// Coordinates are in pt from the top-left of an A4 page; text positions are baselines.

#let meta = json("/meta.json")
#let doc = json("/doc.json")
#let L = meta.labels

// ---------- colours ----------
#let navy = rgb("#011F60")
#let h1-col = rgb("#244890")
#let h2-col = rgb("#34A8A8")
#let header-col = rgb("#238D91")
#let footer-col = rgb("#002060")
#let table-head = rgb("#4BACC6")
#let placeholder-col = rgb("#FF0000")
#let link-col = rgb("#0563C1")
#let contents-col = rgb("#365F91")

// ---------- page geometry ----------
#let page-w = 595.28pt
#let margin-x = 65.3pt
#let margin-top = 71pt
#let margin-bottom = 72pt
#let blank-line = 13.43pt      // one empty 11 pt line between paragraphs
// Explicit edges = Carlito hhea ascender/descender, so a line is 1.2207 em like Word's "single" spacing.
#let top-e = 0.952em
#let bottom-e = -0.2685em

// ---------- helpers ----------
// Places `body` so that its baseline sits at (x, y) on the page (use inside page background).
#let at(x, y, body, right-edge: false) = {
  let t = text(top-edge: "baseline", bottom-edge: "baseline", body)
  if right-edge { place(top + right, dx: x - page-w, dy: y, t) } else { place(top + left, dx: x, dy: y, t) }
}

// ---------- inline content ----------
#let missing-image(n) = box(
  stroke: (paint: placeholder-col, thickness: 0.5pt, dash: "dashed"), inset: 4pt,
  text(fill: placeholder-col, size: 9pt)[#L.imageMissing: #n.ref],
)

// Images keep their natural size but never get wider than the space they are in (page, cell).
#let img(n) = {
  if n.at("src", default: none) == none { return missing-image(n) }
  let w = n.at("width", default: none)
  box(width: if w == none { auto } else { calc.min(w, 464) * 1pt }, image(n.src, width: if w == none { auto } else { 100% }))
}

#let inl(nodes) = {
  for n in nodes {
    if n.t == "text" { n.v }
    else if n.t == "strong" { text(weight: "bold", inl(n.c)) }
    else if n.t == "em" { text(style: "italic", inl(n.c)) }
    else if n.t == "placeholder" { text(fill: placeholder-col, inl(n.c)) }
    else if n.t == "red" { text(fill: placeholder-col, inl(n.c)) }  // red on purpose (<span style="color:red">)
    else if n.t == "link" {
      if n.href == "" { inl(n.c) } else { link(n.href, text(fill: link-col, underline(inl(n.c)))) }
    }
    else if n.t == "code" { box(fill: luma(240), outset: (y: 1pt), inset: (x: 1.5pt), n.v) }
    else if n.t == "br" { linebreak() }
    else if n.t == "image" { img(n) }
    // A node type this layout does not know (from a newer plugin): its text, not nothing.
    else if "c" in n { inl(n.c) }
    else if "v" in n { n.v }
  }
}

// ---------- block content ----------
#let kind(b) = {
  if b.t == "heading" { "h" + str(calc.min(b.level, 3)) }
  else if b.t == "list" and not b.loose { "tight-list" }
  else { b.t }
}

// Gap between the bottom of one block and the top of the next (Word's space before/after, measured).
#let gap(prev, next) = {
  if next == "pagebreak" or prev == "pagebreak" { 0pt }
  else if prev == "contents" or next == "contents" { if next == "h1" { 19.2pt } else { blank-line } }
  else if next == "h1" { if prev == "table" { 8pt } else { 19.2pt } }
  else if next == "h2" { if prev == "h1" { 8pt } else { 10.5pt } }
  else if next == "h3" { if prev in ("h1", "h2") { 4pt } else { 10.5pt } }
  else if prev in ("h1", "h2", "h3") { if next == "table" { 1pt } else { 2pt } }
  else if next == "tight-list" and prev == "para" { 0pt }  // a list right after its intro line
  else { blank-line }
}

#let list-block(b, render) = {
  for (i, item) in b.items.enumerate() {
    if i > 0 and b.loose { v(blank-line) }
    let marker = if b.ordered { str(b.start + i) + "." } else { "-" }
    grid(columns: (18pt, 18pt, 1fr), [], marker, render(item))
  }
}

#let table-block(b) = {
  let n = b.head.len()
  let cols = if b.at("widths", default: none) != none { b.widths.map(w => w * 1fr) } else { (1fr,) * n }
  // Text in tables is always 10 pt (body text is 11 pt).
  let head = b.head.map(c => text(fill: white, weight: "bold", size: 10pt, inl(c)))
  let body = b.rows.map(row => row.map(c => text(size: 10pt, inl(c)))).flatten()
  // Word lets tables run 8.6 pt into the right margin (x 65.3 to 538.6).
  block(width: 473.3pt, table(
    columns: cols,
    inset: (x: 5.5pt, y: 0.25pt),
    align: left + top,
    fill: (x, y) => if y == 0 { table-head } else { white },
    stroke: 0.5pt + black,
    table.header(repeat: false, ..head),
    ..body,
  ))
}

// ---------- automatic table of contents: the > [!inhoud] / > [!contents] block ----------
// Chapters (level 1) and sections (level 2, indented) with their page numbers, each a link to the heading.
#let contents-block(b) = {
  let title = b.at("title", default: none)
  block(text(size: 16.1pt, fill: contents-col, if title != none and title.len() > 0 { inl(title) } else { L.contents }))
  context {
    let hs = query(heading).filter(h => h.level <= 2)
    for (i, h) in hs.enumerate() {
      let pg = counter(page).at(h.location()).first()
      // Single-line entries sit 19.93 pt apart (13.43 pt line + 6.5 pt); long ones wrap at normal line height.
      block(inset: (top: if i == 0 { 2.6pt } else { 6.5pt }, right: 0.6pt), grid(
        columns: (if h.level == 2 { 11pt } else { 0pt }, 1fr, auto),
        column-gutter: (0pt, 12pt),
        [], text(font: "Open Sans", link(h.location(), h.body)), str(pg),
      ))
    }
  }
}

#let render-block(b, render) = {
  if b.t == "heading" { heading(level: b.level, inl(b.c)) }
  else if b.t == "para" {
    let only-images = b.c.len() > 0 and b.c.all(n => n.t == "image" or (n.t == "text" and n.v.trim() == ""))
    if only-images { for n in b.c.filter(n => n.t == "image") { block(img(n)) } }
    else { block(inl(b.c)) }
  }
  else if b.t == "list" { list-block(b, render) }
  else if b.t == "table" { table-block(b) }
  else if b.t == "quote" {
    block(inset: (left: 12pt), stroke: (left: 1.5pt + h2-col), {
      if b.title != none { block(text(weight: "bold", inl(b.title))); v(2pt) }
      render(b.c)
    })
  }
  else if b.t == "codeblock" { block(width: 100%, fill: luma(245), inset: 6pt, text(size: 11pt, b.v)) }
  else if b.t == "pagebreak" { pagebreak(weak: true) }
  else if b.t == "rule" { line(length: 100%, stroke: 0.5pt) }
  else if b.t == "contents" { contents-block(b) }
}

#let render-blocks(blocks) = {
  let prev = none
  for b in blocks {
    if prev != none { v(gap(prev, kind(b)), weak: true) }
    render-block(b, render-blocks)
    prev = kind(b)
  }
}

// ---------- document setup ----------
#set document(title: meta.title)
// All text in the report is 11 pt, except tables (10 pt), headings, the cover and the page header and footer.
#set text(font: "Carlito", size: 11pt, top-edge: top-e, bottom-edge: bottom-e, lang: meta.lang, hyphenate: false)
#set par(leading: 0pt, spacing: 0pt, justify: false)
#set block(spacing: 0pt)
#set table.cell(breakable: false)  // Word keeps table rows on one page
#show heading: set block(above: 0pt, below: 0pt)
#show heading.where(level: 1): set text(size: 19.9pt, weight: "bold", fill: h1-col)
#show heading.where(level: 2): set text(size: 13.9pt, weight: "bold", fill: h2-col)
#show heading: it => {
  // Level 3 and deeper: bold body-size text in the H1 colour
  if it.level >= 3 { block(text(size: 11pt, weight: "bold", fill: h1-col, it.body)) } else { block(it.body) }
}

// ---------- cover (the > [!cover] block of the note) ----------
#let cover(c) = {
  // The cover picture, scaled to fit (never stretched) a 324 x 211.5 pt box (150% of the Word template's 216 x 141)
  // centred horizontally, its middle 157.9 pt from the top.
  let (cw, ch) = (324pt, 211.5pt)
  place(dx: (page-w - cw) / 2, dy: 157.9pt - ch / 2, box(width: cw, height: ch, align(center + horizon, image(c.image, width: 100%, height: 100%, fit: "contain"))))
  // Navy bars
  place(dx: 0pt, dy: 328.2pt, rect(width: page-w, height: 4.1pt, fill: navy))
  place(dx: 0pt, dy: 453.3pt, rect(width: page-w, height: 4.1pt, fill: navy))
  // Between the bars: the title, the first line (as a subtitle) and the second line (small, like a date), letter-spaced
  // as in the Word template, centred as a group in the band. The title takes the largest size (40 pt at most, 12 pt at
  // least) at which it fits: on one line when it can, else wrapped, never wider than the band and never past the bars.
  set text(fill: navy, kerning: false)  // Word does not kern these lines
  let lines = c.lines
  context {
    let max-w = 470pt
    let band-top = 332.3pt  // bottom of the upper bar
    let band-bottom = 453.3pt  // top of the lower bar
    let pad = 8pt
    let gap = 7pt
    // A block of text in the band; its height runs from the ascender of the first line to the descender of the last.
    let blk(size, body) = block(width: max-w, {
      set par(leading: size * 0.2207)  // with ascender/descender edges: Word single spacing
      text(size: size, top-edge: "ascender", bottom-edge: "descender", body)
    })
    // The subtitle: 18 pt, smaller (down to 11 pt) when it would not fit on one line, wrapping only then.
    let subtitle = if lines.len() > 0 {
      let body = text(tracking: 1.578pt, inl(lines.at(0)))
      let natural = measure(text(size: 18pt, body)).width
      blk(if natural > max-w { calc.max(11, 18 * max-w / natural) * 1pt } else { 18pt }, body)
    } else { none }
    let small = if lines.len() > 1 { blk(10.1pt, text(tracking: 1.549pt, inl(lines.at(1)))) } else { none }
    let others = (subtitle, small).filter(b => b != none)
    let others-h = others.map(b => measure(b).height).sum(default: 0pt) + gap * others.len()
    let avail = band-bottom - band-top - 2 * pad - others-h
    // The title: the plain words, to make sure no single word is wider than the band.
    let plain(nodes) = nodes.map(n => if "v" in n and type(n.v) == str { n.v } else if "c" in n { plain(n.c) } else { " " }).join("")
    let words = plain(c.title).split(regex("\s+")).filter(w => w != "")
    let title-body = text(weight: "bold", tracking: 1.567pt, inl(c.title))
    let fits(s) = {
      measure(blk(s, title-body)).height <= avail and words.all(w => measure(text(size: s, weight: "bold", tracking: 1.567pt, w)).width <= max-w)
    }
    let size = 40
    while size > 12 and not fits(size * 1pt) { size -= 0.5 }
    let title = blk(size * 1pt, title-body)
    // Centre the group between the bars.
    let parts = (title, ..others)
    let total = parts.map(b => measure(b).height).sum() + gap * others.len()
    let y = band-top + (band-bottom - band-top - total) / 2
    for b in parts {
      place(dx: 72.5pt, dy: y, b)
      y += measure(b).height + gap
    }
  }
  // Any further lines: below the band, one under the other (for example "Prepared for", a name, an address).
  for (i, l) in lines.slice(calc.min(2, lines.len())).enumerate() {
    at(176.2pt, 495pt + i * 18pt, text(size: 12pt, inl(l)))
  }
}

// ---------- header and footer of inner pages ----------
#let inner-background = context {
  set text(font: "Open Sans", size: 7.9pt)
  // The two header lines at the top left (the > [!header] block; without one, the title).
  let header = meta.at("header", default: ((( t: "text", v: meta.title),),))
  at(65.3pt, 33.8pt, text(fill: header-col, inl(header.at(0, default: ()))))
  at(65.3pt, 44.9pt, text(fill: header-col, inl(header.at(1, default: ()))))
  // No logo in the header (removed in layout version 14).
  at(510.9pt, 804pt, text(fill: footer-col, str(counter(page).get().first())), right-edge: true)
}

// ---------- assemble ----------
// Without a cover block the report starts on page 1 with the text. The table of contents, if any, is where the
// note has its > [!inhoud] block (generated, with page numbers).
#if meta.cover != none [#page(margin: 0pt, background: cover(meta.cover))[#counter(page).update(0)]]

#set page(
  paper: "a4",
  margin: (left: margin-x, right: margin-x, top: margin-top, bottom: margin-bottom),
  background: inner-background,
)
#render-blocks(doc)
