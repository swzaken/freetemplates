// A minimal stand-in for the 'obsidian' module, enough to run plugin classes in tests.
export class TFile {
  basename: string;
  extension: string;
  stat = { ctime: 0, mtime: 0, size: 0 };
  parent = null;
  constructor(public path: string) {
    const name = path.split('/').pop() ?? path;
    this.extension = name.includes('.') ? name.split('.').pop()! : '';
    this.basename = name.replace(/\.[^.]+$/, '');
  }
}

/** A fake element with the parts of the DOM API the plugin uses on view content. */
export function fakeEl() {
  const props = new Map<string, string>();
  const classes = new Set<string>();
  return {
    props,
    classes,
    style: { setProperty: (k: string, v: string) => props.set(k, v), removeProperty: (k: string) => props.delete(k) },
    toggleClass: (c: string, on: boolean) => (on ? classes.add(c) : classes.delete(c)),
    removeClass: (c: string) => classes.delete(c),
    ownerDocument: { body: {} },
  };
}

export class View {}

export class MarkdownView extends View {
  contentEl = fakeEl();
  constructor(public file: TFile | null) {
    super();
  }
}

export class ItemView extends View {}
export class Modal {}
export class Notice {
  constructor(public message: string) {}
}
export class Plugin {}
export class PluginSettingTab {}
export class Setting {}
export class FuzzySuggestModal {}
export class SuggestModal {}
export const normalizePath = (p: string) => p.split('\\').join('/').replace(/\/+/g, '/').replace(/^\/|\/$/g, '');
export const setIcon = () => {};
export const parseYaml = (s: string) => s;
