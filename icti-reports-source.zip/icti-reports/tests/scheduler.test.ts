import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { RenderScheduler } from '../src/preview/scheduler';

describe('RenderScheduler', () => {
  beforeEach(() => vi.useFakeTimers());
  afterEach(() => vi.useRealTimers());

  it('debounces: a burst of requests gives one run after the last one', async () => {
    const run = vi.fn(async () => {});
    const s = new RenderScheduler(() => 500, run);
    for (let i = 0; i < 10; i++) {
      s.request();
      await vi.advanceTimersByTimeAsync(100);
    }
    expect(run).not.toHaveBeenCalled();
    await vi.advanceTimersByTimeAsync(500);
    expect(run).toHaveBeenCalledTimes(1);
  });

  it('never overlaps runs; requests during a run become exactly one follow-up', async () => {
    let active = 0;
    let maxActive = 0;
    const run = vi.fn(async () => {
      active++;
      maxActive = Math.max(maxActive, active);
      await new Promise((r) => setTimeout(r, 1000));
      active--;
    });
    const s = new RenderScheduler(() => 0, run);
    s.request();
    await vi.advanceTimersByTimeAsync(10); // run 1 is busy
    s.request();
    await vi.advanceTimersByTimeAsync(10);
    s.request();
    await vi.advanceTimersByTimeAsync(10);
    await vi.advanceTimersByTimeAsync(3000);
    expect(run).toHaveBeenCalledTimes(2);
    expect(maxActive).toBe(1);
  });

  it('stop() cancels pending work, and a failing run does not break later ones', async () => {
    const run = vi.fn(async () => {
      throw new Error('boom');
    });
    vi.spyOn(console, 'error').mockImplementation(() => {});
    const s = new RenderScheduler(() => 100, run);
    s.request(true);
    await vi.advanceTimersByTimeAsync(1);
    s.request(true);
    await vi.advanceTimersByTimeAsync(1);
    expect(run).toHaveBeenCalledTimes(2);
    s.request();
    s.stop();
    await vi.advanceTimersByTimeAsync(500);
    expect(run).toHaveBeenCalledTimes(2);
  });
});
