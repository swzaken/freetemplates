// Plugin classes that talk to Obsidian, run against the stand-in in tests/mocks/obsidian.ts.
import { describe, expect, it, vi } from 'vitest';
import { MarkdownView, TFile, View } from './mocks/obsidian';
import { NoteZoom } from '../src/obsidian/noteZoom';
import { markdownViews } from '../src/obsidian/views';

function fakePlugin(leaves: { view: unknown }[]) {
  const storage = new Map<string, unknown>();
  return {
    storage,
    app: {
      loadLocalStorage: (k: string) => storage.get(k) ?? null,
      saveLocalStorage: (k: string, v: unknown) => (v === null ? storage.delete(k) : storage.set(k, v)),
      workspace: { getLeavesOfType: () => leaves, on: () => ({}), onLayoutReady: () => {}, getMostRecentLeaf: () => null },
      vault: { on: () => ({}) },
    },
    settings: { legacyNoteZoom: { 'Oud.md': 125 } as Record<string, number> | undefined },
    saveSettings: vi.fn(async () => {}),
    registerEvent: () => {},
    register: () => {},
  };
}

describe('deferred (not yet loaded) tabs', () => {
  const note = new TFile('Rapport.md');
  const loaded = new MarkdownView(note);
  const deferred = new View(); // what Obsidian puts in a background tab until it is shown

  it('markdownViews skips them', () => {
    const app = fakePlugin([{ view: loaded }, { view: deferred }]).app;
    expect(markdownViews(app as never)).toEqual([loaded]);
  });

  it('zooming a note does not crash on them, and sizes the loaded tab', async () => {
    vi.stubGlobal('getComputedStyle', () => ({ getPropertyValue: (k: string) => (k === '--font-preferred-size' ? '16px' : '700px') }));
    const plugin = fakePlugin([{ view: deferred }, { view: loaded }]);
    const zoom = new NoteZoom(plugin as never);
    zoom.start();
    // zoom levels from the old shared settings move to this computer
    expect(plugin.storage.get('icti-reports-note-zoom')).toEqual({ 'Oud.md': 125 });
    expect(plugin.settings.legacyNoteZoom).toBeUndefined();
    await zoom.change(1);
    expect(plugin.storage.get('icti-reports-note-zoom')).toEqual({ 'Oud.md': 125, 'Rapport.md': 110 });
    expect(loaded.contentEl.props.get('--font-preferred-size')).toBe('17.6px');
    await zoom.change(0);
    expect(plugin.storage.get('icti-reports-note-zoom')).toEqual({ 'Oud.md': 125 });
    expect(loaded.contentEl.props.size).toBe(0);
    vi.unstubAllGlobals();
  });
});
