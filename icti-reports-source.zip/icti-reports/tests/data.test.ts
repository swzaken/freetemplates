import { describe, expect, it } from 'vitest';
import { buildMeta } from '../src/data/meta';
import { formatDate, parseDate } from '../src/data/labels';
import { findBlock, findCoverBlock, markdownImagePath, rebaseCoverImage, withCoverImage } from '../src/data/coverText';
import { DEFAULT_COVER, imageFormat, isSafeImageRef, isVaultPath, joinInVault, prepare } from '../src/pipeline';
import { readFileSync } from 'node:fs';
import { parseSimpleYaml } from '../tools/simple-yaml';

const PNG = new Uint8Array(readFileSync('assets/img/header-logo.png'));
const JPEG = new Uint8Array([0xff, 0xd8, 0xff, 0xe0, 0, 0x10, 0x4a, 0x46]);
const today = new Date(2026, 10, 9);
const host = (readImage: (r: string) => Promise<Uint8Array | null> = async () => null) => ({ parseYaml: parseSimpleYaml, readImage, today, noteName: 'My report' });

describe('buildMeta', () => {
  it('defaults: English, today, no cover, no automatic contents, the note name as title', () => {
    expect(buildMeta({}, null, 'My report', today)).toMatchObject({ lang: 'en', isoDate: '20261109', cover: null, contents: false, title: 'My report' });
  });

  it('language, date, inhoudsopgave and an old title property', () => {
    const m = buildMeta({ language: 'nl', date: '2026-02-03', inhoudsopgave: false, title: 'Oud' }, null, 'x', today);
    expect(m).toMatchObject({ lang: 'nl', isoDate: '20260203', contents: false, title: 'Oud' });
    expect(m.labels.contents).toBe('Inhoud');
  });
});

describe('helpers', () => {
  it('dates', () => {
    expect(formatDate(new Date(2026, 0, 1), 'en')).toBe('January 1 2026');
    expect(formatDate(new Date(2026, 10, 13), 'nl')).toBe('13 november 2026');
    expect(parseDate('2026-11-09')?.getDate()).toBe(9);
    expect(parseDate('09-11-2026')).toBeNull();
  });

  it('image references: files only; "../" may not leave the vault', () => {
    for (const ok of ['a.png', 'img/a.png', 'img\\a b.png', '../a.png']) expect(isSafeImageRef(ok)).toBe(true);
    for (const bad of ['', '/etc/a.png', 'C:\\a.png', 'https://x/a.png', 'file:///a.png', 'data:image/png;base64,xx']) expect(isSafeImageRef(bad)).toBe(false);
    expect(joinInVault('Klanten/ABC', '../Images/a.png')).toBe('Klanten/Images/a.png');
    expect(joinInVault('Klanten/ABC', './a.png')).toBe('Klanten/ABC/a.png');
    expect(joinInVault('Klanten', '../../a.png')).toBeNull();
    expect(joinInVault('', '../a.png')).toBeNull();
  });

  it('path settings must stay inside the vault', () => {
    for (const ok of ['', 'Reports', 'ICT Reports/Layout/report.typ', 'a\\b']) expect(isVaultPath(ok)).toBe(true);
    for (const bad of ['..', '../x', 'a/../../x', 'C:\\out', 'c:/out', '/etc', '\\\\server\\share']) expect(isVaultPath(bad)).toBe(false);
  });

  it('simple YAML reader', () => {
    expect(parseSimpleYaml('a: 1\nb: "x: y"\nc: [x, "y, z"]\nd:\n  - "[[P]]"\n  - Q\ne: false')).toEqual({
      a: 1, b: 'x: y', c: ['x', 'y, z'], d: ['[[P]]', 'Q'], e: false,
    });
  });
});

describe('cover block in the note text', () => {
  it('finds the block and its picture line; ignores code blocks', () => {
    const lines = ['---', 'language: nl', '---', '', '```', '> [!cover]', '```', '> [!cover]', '> # T', '> line', '> ![Cover](a.png)', '', '# Text'];
    expect(findCoverBlock(lines)).toEqual({ start: 7, end: 11, imageLine: 10 });
    expect(findCoverBlock(['> [!COVER] Title', '> ![[x.png]]'])).toEqual({ start: 0, end: 2, imageLine: 1 });
    expect(findCoverBlock(['> [!note]', '> x'])).toBeNull();
    expect(findBlock(['> [!cover]', '> # T', '', '> [!header]', '> a', '> b', 'text'], 'header')).toEqual({ start: 3, end: 6, imageLine: -1 });
  });

  it('withCoverImage puts the picture under "> [!cover]" only when the block has none', () => {
    const line = '> ![Cover](../assets/cover-default.png)';
    expect(withCoverImage('---\nlanguage: nl\n---\n> [!cover]\n> # T\n> Sub\n\nText', line)).toBe(`---\nlanguage: nl\n---\n> [!cover]\n${line}\n> # T\n> Sub\n\nText`);
    expect(withCoverImage('> [!cover]\r\n> # T', line)).toBe(`> [!cover]\r\n${line}\r\n> # T`);
    expect(withCoverImage('> [!cover]\n> ![Cover](own.png)\n> # T', line)).toBe('> [!cover]\n> ![Cover](own.png)\n> # T');
    expect(withCoverImage('# No cover', line)).toBe('# No cover');
  });

  it('rebaseCoverImage makes a template picture path relative to the new report', () => {
    const tpl = '> [!cover]\n> ![Cover](../Opmaak/assets/cover-default.png)\n> # T';
    const exists = (p: string) => p === '00. Start/00. Sjablonen/Opmaak/assets/cover-default.png';
    expect(rebaseCoverImage(tpl, '00. Start/00. Sjablonen/Sjablonen', '02. Client Projects/ABC', exists))
      .toBe('> [!cover]\n> ![Cover](../../00.%20Start/00.%20Sjablonen/Opmaak/assets/cover-default.png)\n> # T');
    expect(rebaseCoverImage(tpl, 'elsewhere', '02. Client Projects/ABC', exists)).toBe(tpl); // not found: unchanged
    expect(rebaseCoverImage('> [!cover]\n> ![[logo.png]]', 'a', 'b', () => true)).toBe('> [!cover]\n> ![[logo.png]]');
    expect(rebaseCoverImage('> [!cover]\n> ![x](https://e.com/a.png)', 'a', 'b', () => true)).toBe('> [!cover]\n> ![x](https://e.com/a.png)');
  });

  it('writes picture paths relative to the note, encoded', () => {
    expect(markdownImagePath('01. Klantprojecten/ABC', '01. Klantprojecten/ABC/logo.png')).toBe('logo.png');
    expect(markdownImagePath('01. Klantprojecten/ABC', 'Images/ABC logo (blue).png')).toBe('../../Images/ABC%20logo%20%28blue%29.png');
    expect(markdownImagePath('', 'Images/a#b.png')).toBe('Images/a%23b.png');
  });
});

describe('prepare', () => {
  it('maps found images to virtual paths and flags missing ones with their line', async () => {
    const note = '---\nlanguage: en\n---\n![[a.png]] ![[a.png]] ![[gone.png]] ![[x.exe]]';
    const p = await prepare(note, host(async (r) => (r === 'a.png' ? PNG : null)));
    expect(Object.keys(p.images)).toEqual(['/img/0.png']);
    const para = p.blocks[0];
    if (para.t !== 'para') throw new Error();
    const imgs = para.c.filter((n) => n.t === 'image');
    expect(imgs.map((i) => (i as { src?: string }).src ?? 'missing')).toEqual(['/img/0.png', '/img/0.png', 'missing']);
    expect(p.diagnostics.map((d) => d.line)).toEqual([4]);
    expect(para.c.some((n) => n.t === 'text' && n.v.includes('x.exe'))).toBe(true); // non-image embeds show as text
    expect(p.meta.cover).toBeNull();
  });

  it('the cover block becomes the cover: title, lines, picture; it is not part of the text', async () => {
    const note = '> [!cover]\n> # Security rules\n> For ABC\n> 13 November 2026\n> ![Cover](logo%201.png)\n> Prepared for ABC\n\n# Introduction\n\nText';
    const p = await prepare(note, host(async (r) => (r === 'logo 1.png' ? PNG : null)));
    expect(p.blocks.map((b) => b.t)).toEqual(['heading', 'para']);
    expect(p.meta.title).toBe('Security rules');
    expect(p.meta.cover?.lines.map((l) => (l[0] as { v: string }).v)).toEqual(['For ABC', '13 November 2026', 'Prepared for ABC']);
    expect(p.meta.cover?.image).toBe('/img/0.png');
    expect(p.diagnostics).toEqual([]);
  });

  it('without a picture, or with a missing or damaged one, the cover uses the standard picture', async () => {
    const readImage = async (r: string) => (r === 'bad.png' ? new Uint8Array([1, 2, 3]) : null);
    for (const img of ['', '\n> ![](gone.png)', '\n> ![[bad.png]]']) {
      const p = await prepare(`> [!cover] Title${img}`, host(readImage));
      expect(p.meta.cover?.image).toBe(DEFAULT_COVER);
      expect(p.diagnostics).toHaveLength(img ? 1 : 0);
    }
  });

  it('title from "[!cover] Title" or the first line; a second cover block is ignored with a warning', async () => {
    expect((await prepare('> [!cover] Short\n> line', host())).meta.title).toBe('Short');
    const p = await prepare('> [!cover]\n> First line\n> Second\n\n> [!cover]\n> # Other', host());
    expect(p.meta.title).toBe('First line');
    expect(p.meta.cover?.lines).toHaveLength(1);
    expect(p.diagnostics.map((d) => d.line)).toEqual([5]);
    expect(p.blocks).toEqual([]);
  });

  it('the header block gives the two header lines; without it, the title and an empty line', async () => {
    const p = await prepare('> [!cover]\n> # Title\n\n> [!header]\n> Project: X\n> ==Document==\n\nText', host());
    expect(p.meta.header).toEqual([[{ t: 'text', v: 'Project: X' }], [{ t: 'placeholder', c: [{ t: 'text', v: 'Document' }] }]]);
    expect(p.blocks.map((b) => b.t)).toEqual(['para']);
    expect(p.placeholders).toEqual([4]);
    expect((await prepare('> [!cover]\n> # Title', host())).meta.header).toEqual([[{ t: 'text', v: 'Title' }], []]);
    expect((await prepare('> [!header]\n> Only one', host())).meta.header).toEqual([[{ t: 'text', v: 'Only one' }], []]);
    const extra = await prepare('> [!header]\n> 1\n> 2\n> 3\n\n> [!header]\n> other', host());
    expect(extra.meta.header.map((l) => (l[0] as { v: string }).v)).toEqual(['1', '2']);
    expect(extra.diagnostics.map((d) => d.line)).toEqual([6, 1]);
  });

  it('placeholders on the cover count for the export warning; red text on purpose does not', async () => {
    expect((await prepare('> [!cover]\n> # ==Title==', host())).placeholders).toEqual([1]);
    expect((await prepare('A <span style="color:red">red</span> word.', host())).placeholders).toEqual([]);
    expect((await prepare('---\nlanguage: en\n---\nA ==placeholder== word.', host())).placeholders).toEqual([4]);
  });

  it('a damaged image becomes a placeholder with a warning, not a failed PDF', async () => {
    const note = 'text\n\n![[bad.png]] ![[photo.png]]';
    const p = await prepare(note, host(async (r) => (r === 'bad.png' ? new Uint8Array([0x89, 0x50, 0x4e, 0x47, 1, 2, 3]) : JPEG)));
    expect(Object.keys(p.images)).toEqual(['/img/1.jpg']); // a JPEG saved as .png is named by its real format
    expect(p.diagnostics.map((d) => [d.line, d.message])).toEqual([[3, 'Image "bad.png" is damaged or not really an image.']]);
  });

  it('imageFormat recognises real image headers only', () => {
    expect(imageFormat(PNG)).toBe('png');
    expect(imageFormat(JPEG)).toBe('jpg');
    expect(imageFormat(new TextEncoder().encode('<?xml version="1.0"?><svg xmlns="x"></svg>'))).toBe('svg');
    expect(imageFormat(new TextEncoder().encode('GIF89a......'))).toBe('gif');
    expect(imageFormat(new TextEncoder().encode('hello'))).toBeNull();
  });

  it('unreadable properties become an error diagnostic, not a crash', async () => {
    const p = await prepare('---\n: bad\n---\ntext', host());
    expect(p.diagnostics[0]).toMatchObject({ line: 1, severity: 'error' });
    expect(p.blocks).toHaveLength(1);
  });
});

describe('settings from data.json', () => {
  it('keeps valid values, replaces wrong types with defaults, migrates old values', async () => {
    const { cleanSettings, DEFAULT_SETTINGS } = await import('../src/settings');
    const s = cleanSettings({ clientProjectsFolder: 'Klanten 2', templatesFolder: null, previewDelay: '700', fileNamePattern: '{date}_{client}_{note}', noteZoom: { 'a.md': 150 }, uiLanguage: 'de', clientsFolder: 'old' });
    expect(s.clientProjectsFolder).toBe('Klanten 2');
    expect(s.internalProjectsFolder).toBe('01. Internal projects');
    expect(s.templatesFolder).toBe(DEFAULT_SETTINGS.templatesFolder);
    expect(s.previewDelay).toBe(500);
    expect(s.fileNamePattern).toBe('{date}_{folder}_{note}');
    expect(s.uiLanguage).toBe('nl');
    expect(s.legacyNoteZoom).toEqual({ 'a.md': 150 });
    expect('clientsFolder' in s).toBe(false);
    expect(cleanSettings(null)).toEqual(DEFAULT_SETTINGS);
  });
});
