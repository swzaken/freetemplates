import { describe, expect, it } from 'vitest';
import { changeDetails, logFileName, propertyBlocks, summarize } from '../src/data/changes';

const note = (fm: string, body: string) => `---\n${fm}\n---\n${body}`;

describe('change summary', () => {
  const before = note('title: "A"\nteam:\n  - "[[X]]"\nheader_1: ""', '# Inleiding\n\nTekst.\n\n# Resultaten\n\nGoed.\n');

  it('names the changed chapter and counts a small edit as a few characters', () => {
    const after = before.replace('Goed.', 'Heel goed.');
    expect(summarize(before, after)).toEqual({ chapters: ['Resultaten'], properties: [], added: 6, removed: 1 }); // "G" -> "Heel g"
  });

  it('names changed, added and removed properties, including list properties', () => {
    const after = note('title: "B"\nteam:\n  - "[[X]]"\n  - "[[Y]]"\nversion: "1.0"', '# Inleiding\n\nTekst.\n\n# Resultaten\n\nGoed.\n');
    expect(summarize(before, after).properties).toEqual(['title', 'team', 'header_1', 'version']);
    expect(summarize(before, after).chapters).toEqual([]);
  });

  it('reports added and removed chapters and the text before the first heading as ""', () => {
    const after = note('title: "A"\nteam:\n  - "[[X]]"\nheader_1: ""', 'Intro.\n\n# Inleiding\n\nTekst.\n\n# Conclusie\n\nKlaar.\n');
    const s = summarize(before, after);
    expect(s.chapters).toEqual(['', 'Conclusie', 'Resultaten']);
    expect(s.added).toBeGreaterThan(0);
    expect(s.removed).toBeGreaterThan(0);
  });

  it('a "#" inside a code block is not a heading; no change gives an empty summary', () => {
    const code = note('a: 1', '```\n# not a heading\n```\n');
    expect(summarize(code, code)).toEqual({ chapters: [], properties: [], added: 0, removed: 0 });
    expect(summarize(code, code.replace('not', 'still not')).chapters).toEqual(['']);
  });

  it('property blocks keep continuation lines with their key', () => {
    expect([...propertyBlocks('a: 1\nb:\n  - x\n  - y\nc: "q: r"').entries()]).toEqual([['a', '1'], ['b', '\n- x\n- y'], ['c', '"q: r"']]);
  });

  it('each note path gets its own log file name', () => {
    expect(logFileName('01. Klanten/ABC/Rapport 50%.md')).toBe('01. Klanten%2FABC%2FRapport 50%25.md.json');
  });
});

describe('change details', () => {
  const before = note('title: "A"\nversion: "0.1"', '# Inleiding\n\nTekst.\n\n# Resultaten\n\nGoed.\nRegel twee.\n');

  it('lists old and new property values, and removed / added lines per chapter', () => {
    const after = note('title: "B"\nstatus: x', '# Inleiding\n\nTekst.\n\n# Resultaten\n\nHeel goed.\nRegel twee.\nNieuwe regel.\n');
    expect(changeDetails(before, after)).toEqual({
      properties: [
        { name: 'title', before: '"A"', after: '"B"' },
        { name: 'version', before: '"0.1"', after: '' },
        { name: 'status', before: '', after: 'x' },
      ],
      text: [
        { chapter: 'Resultaten', removed: ['Goed.'], added: ['Heel goed.'] },
        { chapter: 'Resultaten', removed: [], added: ['Nieuwe regel.'] },
      ],
    });
  });

  it('a removed chapter shows its lines as removed; only empty lines changed shows nothing', () => {
    const after = note('title: "A"\nversion: "0.1"', '# Inleiding\n\nTekst.\n');
    const d = changeDetails(before, after);
    expect(d.text).toHaveLength(1);
    expect(d.text[0].removed).toEqual(['# Resultaten', '', 'Goed.', 'Regel twee.']);
    expect(changeDetails(before, before.replace('Tekst.\n', 'Tekst.\n\n\n')).text).toEqual([]);
  });

  it('a very long change is cut off', () => {
    const big = note('a: 1', Array.from({ length: 400 }, (_, i) => `regel ${i}`).join('\n'));
    const d = changeDetails(note('a: 1', ''), big);
    expect(d.truncated).toBe(true);
    expect(d.text.reduce((n, h) => n + h.added.length, 0)).toBe(300);
  });
});
