import { describe, expect, it } from 'vitest';
import { fillTemplate, noteFileName } from '../src/data/template';

const vars = { type: 'Simple report', folder: 'ABC', title: 'ABC audit 2026', today: new Date(2026, 2, 5) };

describe('fillTemplate', () => {
  it('fills the documented tokens in properties and body', () => {
    const t = '> [!cover]\n> # {{ title }}\n> {{long_date}}\n\n{{type}} for {{folder}} ({{year}}, {{date}}).';
    expect(fillTemplate(t, vars)).toBe('> [!cover]\n> # ABC audit 2026\n> March 5 2026\n\nSimple report for ABC (2026, 2026-03-05).');
  });

  it('{{long_date}} is written out in the template language', () => {
    expect(fillTemplate('---\nlanguage: nl\n---\n{{long_date}}', vars)).toBe('---\nlanguage: nl\n---\n5 maart 2026');
  });

  it('older templates: {{client}} and {{client_name}} are the folder name; unknown tokens stay', () => {
    expect(fillTemplate('{{tp.date}} {{other}} {{client}} {{client_name}}', vars)).toBe('{{tp.date}} {{other}} ABC ABC');
  });

  it('escapes quotes and backslashes in properties, but not in the body', () => {
    const t = '---\ntitle: "{{title}}"\n---\n{{title}}';
    expect(fillTemplate(t, { ...vars, title: 'A "B" \\ C' })).toBe('---\ntitle: "A \\"B\\" \\\\ C"\n---\nA "B" \\ C');
  });
});

describe('noteFileName', () => {
  it('strips leading dots so no hidden folders are made', () => {
    expect(noteFileName('.NET Solutions')).toBe('NET Solutions');
  });

  it('removes characters that are not allowed in file names or links', () => {
    expect(noteFileName('  ABC: audit / 2026?  ')).toBe('ABC audit 2026');
    expect(noteFileName('a[[b]]#c^d|e')).toBe('a b c d e');
    expect(noteFileName('name...')).toBe('name');
  });
});

describe('folderPath (a new subfolder in New report)', () => {
  it('keeps "/" for a folder inside a folder and makes each part safe', async () => {
    const { folderPath } = await import('../src/obsidian/newReport');
    expect(folderPath('ABC')).toBe('ABC');
    expect(folderPath(' ABC / Audit: 2026 ')).toBe('ABC/Audit 2026');
    expect(folderPath('ABC\\..\\x')).toBe('ABC/x');
    expect(folderPath('//')).toBe('');
  });
});
