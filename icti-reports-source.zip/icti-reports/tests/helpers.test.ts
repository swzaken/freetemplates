import { describe, expect, it } from 'vitest';
import { buildFileName, DEFAULT_PATTERN } from '../src/data/filename';
import { buildMeta } from '../src/data/meta';
import { fromNote, fromTypst, formatProblem } from '../src/problems';

const meta = (props: Record<string, unknown>) => buildMeta(props, null, 'note', new Date(2026, 10, 9));

describe('buildFileName', () => {
  it('default pattern: YYYYMMDD_folder_document name (the note name)', () => {
    expect(buildFileName(DEFAULT_PATTERN, meta({ date: '2026-03-05' }), 'ISO 27001 interne audit 2026', 'ABC')).toBe('20260305_ABC_ISO 27001 interne audit 2026.pdf');
    expect(buildFileName('{date}_{client}_{note}', meta({}), 'n', 'ABC')).toBe('20261109_ABC_n.pdf'); // the old name of {folder}
  });

  it('empty tokens do not leave double separators', () => {
    expect(buildFileName(DEFAULT_PATTERN, meta({}), 'note')).toBe('20261109_note.pdf');
  });

  it('characters Windows forbids are replaced', () => {
    expect(buildFileName(DEFAULT_PATTERN, meta({}), 'x|y?z*<>', 'A: "C"')).toBe('20261109_A- -C-_x-y-z.pdf');
  });

  it('no path tricks: slashes and dots cannot leave the folder', () => {
    const name = buildFileName('{folder}', meta({}), 'note', '../../etc/passwd');
    expect(name).not.toContain('/');
    expect(name).not.toContain('\\');
    expect(name.startsWith('.')).toBe(false);
  });

  it('falls back to the note name, avoids reserved names, keeps unknown tokens', () => {
    expect(buildFileName('{folder}', meta({}), 'My note')).toBe('My note.pdf');
    expect(buildFileName('{folder}', meta({}), 'n', 'CON')).toBe('_CON.pdf');
    expect(buildFileName('{note}-{nope}', meta({}), 'n')).toBe('n-{nope}.pdf');
  });
});

describe('problems', () => {
  it('note problems point to a line or to the properties', () => {
    expect(formatProblem(fromNote({ line: 12, severity: 'warning', message: 'Image "x.png" not found.' }))).toBe('Line 12: Image "x.png" not found.');
    expect(fromNote({ line: 0, severity: 'warning', message: 'm' }).where).toBe('Properties');
  });

  it('Typst problems point into the layout file', () => {
    const p = fromTypst({ path: '/report.typ', line: 40, severity: 'error', message: 'unknown variable: foo' }, 'ICT Rapporten/Opmaak/report.typ');
    expect(formatProblem(p)).toBe('Layout file ICT Rapporten/Opmaak/report.typ, line 40: Unknown variable: foo');
  });
});
