import { deflateRawSync } from 'node:zlib';
import { describe, expect, it } from 'vitest';
import { convertDocx, fillImages, guessLanguage } from '../src/import/docx';
import { templateBaseName, templateNote } from '../src/import/template';
import { Zip } from '../src/import/zip';

// ---------- a tiny zip writer for made-up Word files ----------

const crcTable = Array.from({ length: 256 }, (_, n) => {
  let c = n;
  for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
  return c >>> 0;
});
function crc32(b: Uint8Array): number {
  let c = 0xffffffff;
  for (const x of b) c = crcTable[(c ^ x) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

function makeZip(files: Record<string, string | Uint8Array>, deflate = true): Uint8Array {
  const local: number[] = [];
  const central: number[] = [];
  const u16 = (a: number[], v: number) => a.push(v & 0xff, (v >>> 8) & 0xff);
  const u32 = (a: number[], v: number) => a.push(v & 0xff, (v >>> 8) & 0xff, (v >>> 16) & 0xff, (v >>> 24) & 0xff);
  let count = 0;
  for (const [name, content] of Object.entries(files)) {
    const data = typeof content === 'string' ? new TextEncoder().encode(content) : content;
    const packed = deflate ? new Uint8Array(deflateRawSync(data)) : data;
    const nameBytes = new TextEncoder().encode(name);
    const offset = local.length;
    const head = (a: number[], sig: number, isCentral: boolean) => {
      u32(a, sig);
      if (isCentral) u16(a, 20);
      u16(a, 20); u16(a, 0); u16(a, deflate ? 8 : 0); u16(a, 0); u16(a, 0);
      u32(a, crc32(data)); u32(a, packed.length); u32(a, data.length);
      u16(a, nameBytes.length); u16(a, 0);
      if (isCentral) { u16(a, 0); u16(a, 0); u16(a, 0); u32(a, 0); u32(a, offset); }
      a.push(...nameBytes);
    };
    head(local, 0x04034b50, false);
    local.push(...packed);
    head(central, 0x02014b50, true);
    count++;
  }
  const end: number[] = [];
  u32(end, 0x06054b50); u16(end, 0); u16(end, 0); u16(end, count); u16(end, count);
  u32(end, central.length); u32(end, local.length); u16(end, 0);
  return new Uint8Array([...local, ...central, ...end]);
}

const W = 'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"';
const STYLES = `<?xml version="1.0"?><w:styles ${W}>
  <w:style w:styleId="Title"><w:name w:val="Title"/></w:style>
  <w:style w:styleId="Subtitle"><w:name w:val="Subtitle"/></w:style>
  <w:style w:styleId="Heading1"><w:name w:val="heading 1"/></w:style>
  <w:style w:styleId="Heading2"><w:name w:val="heading 2"/></w:style>
  <w:style w:styleId="TOC1"><w:name w:val="toc 1"/></w:style>
</w:styles>`;
const NUMBERING = `<?xml version="1.0"?><w:numbering ${W}>
  <w:abstractNum w:abstractNumId="0"><w:lvl w:ilvl="0"><w:numFmt w:val="bullet"/></w:lvl><w:lvl w:ilvl="1"><w:numFmt w:val="bullet"/></w:lvl></w:abstractNum>
  <w:abstractNum w:abstractNumId="1"><w:lvl w:ilvl="0"><w:start w:val="1"/><w:numFmt w:val="decimal"/><w:lvlText w:val="%1."/></w:lvl></w:abstractNum>
  <w:num w:numId="1"><w:abstractNumId w:val="0"/></w:num>
  <w:num w:numId="2"><w:abstractNumId w:val="1"/></w:num>
</w:numbering>`;
const PNG = new Uint8Array([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0, 0, 0, 13, 0x49, 0x48, 0x44, 0x52, 0, 0, 0, 1, 0, 0, 0, 1, 8, 2, 0, 0, 0]);

const p = (text: string, style?: string, extra = '') => `<w:p>${style ? `<w:pPr><w:pStyle w:val="${style}"/></w:pPr>` : ''}${extra}${text ? `<w:r><w:t xml:space="preserve">${text}</w:t></w:r>` : ''}</w:p>`;
const li = (text: string, numId: number, ilvl = 0) => `<w:p><w:pPr><w:numPr><w:ilvl w:val="${ilvl}"/><w:numId w:val="${numId}"/></w:numPr></w:pPr><w:r><w:t>${text}</w:t></w:r></w:p>`;
const pic = (rel: string, cx = 1905000) => `<w:r><w:drawing><wp:inline><wp:extent cx="${cx}" cy="100"/><a:graphic><a:graphicData><a:blip r:embed="${rel}"/></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>`;

function docx(body: string, extra: Record<string, string | Uint8Array> = {}): Uint8Array {
  return makeZip({
    '[Content_Types].xml': '<Types/>',
    'word/document.xml': `<?xml version="1.0"?><w:document ${W}><w:body>${body}<w:sectPr/></w:body></w:document>`,
    'word/styles.xml': STYLES,
    'word/numbering.xml': NUMBERING,
    'word/_rels/document.xml.rels': `<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
      <Relationship Id="rImg" Type="image" Target="media/image1.png"/>
      <Relationship Id="rCover" Type="image" Target="media/cover.png"/>
      <Relationship Id="rWeb" Type="image" Target="https://example.com/x.png" TargetMode="External"/>
      <Relationship Id="rLink" Type="hyperlink" Target="https://www.ictinstitute.nl/" TargetMode="External"/>
      <Relationship Id="rBad" Type="hyperlink" Target="javascript:alert(1)" TargetMode="External"/>
    </Relationships>`,
    'word/media/image1.png': PNG,
    'word/media/cover.png': PNG,
    ...extra,
  });
}

// ---------- tests ----------

describe('zip reader', () => {
  it('reads stored and deflated entries and refuses what is not a zip', async () => {
    for (const deflate of [true, false]) {
      const z = Zip.open(makeZip({ 'a.txt': 'hello hello hello', 'b/c.bin': new Uint8Array([1, 2, 3]) }, deflate));
      expect(await z.text('a.txt')).toBe('hello hello hello');
      expect(Array.from((await z.bytes('b/c.bin'))!)).toEqual([1, 2, 3]);
      expect(await z.bytes('missing')).toBeNull();
    }
    expect(() => Zip.open(new TextEncoder().encode('not a zip at all, just text'))).toThrow();
    await expect(convertDocx(new TextEncoder().encode('plain text'))).rejects.toThrow(/not a readable Word file/);
  });
});

describe('Word report → template body', () => {
  it('leaves out the cover and the table of contents; keeps the rest, also contact details and version history', async () => {
    const body = [
      p('Interne audit 2025', 'Title'),
      p('ISMS van een organisatie', 'Subtitle'),
      p('', '', pic('rCover')),
      p('Inhoudsopgave'),
      p('Inleiding 2', 'TOC1'),
      p('Contactgegevens', 'Heading1'),
      '<w:tbl><w:tr><w:tc><w:p><w:r><w:t>Auditor</w:t></w:r></w:p></w:tc></w:tr></w:tbl>',
      p('Inleiding', 'Heading1'),
      p('Dit rapport beschrijft de audit van de organisatie.'),
      p('Aanpak', 'Heading2'),
      p('Versiebeheer', 'Heading1'),
      p('0.1 eerste concept'),
      p('Conclusie', 'Heading1'),
      p('Het ISMS voldoet aan de eisen van de norm.'),
    ].join('');
    const r = await convertDocx(docx(body));
    expect(r.title).toBe('Interne audit 2025');
    expect(r.subtitle).toBe('ISMS van een organisatie');
    expect(r.language).toBe('nl');
    expect(r.left).toEqual(['cover']);
    expect(r.body).toBe('# Contactgegevens\n\n| Auditor |\n| --- |\n\n# Inleiding\n\nDit rapport beschrijft de audit van de organisatie.\n\n## Aanpak\n\n# Versiebeheer\n\n0.1 eerste concept\n\n# Conclusie\n\nHet ISMS voldoet aan de eisen van de norm.');
    expect(r.images.size).toBe(0); // the cover picture is not kept
  });

  it("Word's cover page and table of contents controls are left out as a whole", async () => {
    const gallery = (g: string, inner: string) => `<w:sdt><w:sdtPr><w:docPartObj><w:docPartGallery w:val="${g}"/></w:docPartObj></w:sdtPr><w:sdtContent>${inner}</w:sdtContent></w:sdt>`;
    const r = await convertDocx(docx(gallery('Cover Pages', p('Client B.V.') + p('', '', pic('rCover'))) + gallery('Table of Contents', p('Index') + p('Summary 2', 'TOC1')) + p('Summary', 'Heading1') + p('The audit found that the system works.')));
    expect(r.left).toEqual(['cover']);
    expect(r.body).toBe('# Summary\n\nThe audit found that the system works.');
    expect(r.title).toBe('');
    expect(r.language).toBe('en');
  });

  it('formatting, placeholders, lists, line breaks, links, footnotes and pictures', async () => {
    const run = (t: string, rpr: string) => `<w:r><w:rPr>${rpr}</w:rPr><w:t xml:space="preserve">${t}</w:t></w:r>`;
    const body = [
      p('Results', 'Heading1'),
      `<w:p>${run('Bold', '<w:b/>')}${run(' and ', '')}${run('italic', '<w:i/>')}${run(' and ', '')}${run('[client name]', '<w:highlight w:val="yellow"/>')}${run(' and ', '')}${run('date', '<w:color w:val="FF0000"/>')}${run('hidden', '<w:vanish/>')}<w:del><w:r><w:delText>deleted</w:delText></w:r></w:del></w:p>`,
      li('first', 1), li('nested', 1, 1), li('one', 2), li('two', 2),
      `<w:p><w:r><w:t>line one</w:t><w:br/><w:t>- line two</w:t></w:r></w:p>`,
      `<w:p><w:hyperlink r:id="rLink"><w:r><w:t>our site</w:t></w:r></w:hyperlink><w:r><w:t xml:space="preserve"> </w:t></w:r><w:hyperlink r:id="rBad"><w:r><w:t>bad</w:t></w:r></w:hyperlink></w:p>`,
      `<w:p><w:r><w:t>Text</w:t></w:r><w:r><w:footnoteReference w:id="1"/></w:r></w:p>`,
      p('', '', pic('rImg') + pic('rWeb')),
      p('{{client}} # 50% *star*'),
    ].join('');
    const footnotes = `<?xml version="1.0"?><w:footnotes ${W}><w:footnote w:type="separator" w:id="0"/><w:footnote w:id="1"><w:p><w:r><w:t>See ISO 27001.</w:t></w:r></w:p></w:footnote></w:footnotes>`;
    const r = await convertDocx(docx(body, { 'word/footnotes.xml': footnotes }));
    const md = fillImages(r.body, new Map([[1, 'Report 1.png']]));
    expect(md).toContain('**Bold** and *italic* and ==\\[client name\\]== and ==date==');
    expect(md).not.toMatch(/hidden|deleted/);
    expect(md).toContain('- first\n\t- nested\n1. one\n1. two');
    expect(md).toContain('line one\\\n\\- line two');
    expect(md).toContain('[our site](https://www.ictinstitute.nl/) bad');
    expect(md).toContain('Text (See ISO 27001.)');
    expect(md).toContain('![[Report 1.png|200]]');
    expect(md).not.toContain('example.com');
    expect(md).toContain('\\{\\{client\\}\\} \\# 50\\% \\*star\\*');
    expect([...r.images.keys()]).toEqual([1]);
  });

  it('tables: line breaks as <br>, merged cells, separators escaped', async () => {
    const tc = (inner: string, pr = '') => `<w:tc>${pr ? `<w:tcPr>${pr}</w:tcPr>` : ''}${inner}</w:tc>`;
    const body = p('Plan', 'Heading1') + `<w:tbl>
      <w:tr>${tc(p('Time'))}${tc(p('Topic'))}${tc(p('Who'))}</w:tr>
      <w:tr>${tc(`<w:p><w:r><w:t>a|b</w:t><w:br/><w:t>c</w:t></w:r></w:p>`)}${tc(p('Opening'), '<w:gridSpan w:val="2"/>')}</w:tr>
      <w:tr>${tc(p('x'), '<w:vMerge w:val="restart"/>')}${tc(li('item', 1))}${tc(p('y'))}</w:tr>
      <w:tr>${tc(p('ignored'), '<w:vMerge/>')}${tc(p('z'))}${tc(p(''))}</w:tr>
    </w:tbl>`;
    const r = await convertDocx(docx(body));
    expect(r.body).toBe('# Plan\n\n| Time | Topic | Who |\n| --- | --- | --- |\n| a\\|b<br>c | Opening |  |\n| x | • item | y |\n|  | z |  |');
  });

  it('without any chapter heading everything is kept', async () => {
    const r = await convertDocx(docx(p('Een korte notitie over het beleid van de organisatie.')));
    expect(r.body).toBe('Een korte notitie over het beleid van de organisatie.');
    expect(r.left).toEqual([]);
  });

  it('markup cannot form across formatting boundaries, from titles, list items or control characters', async () => {
    const run = (t: string, rpr = '') => `<w:r>${rpr ? `<w:rPr>${rpr}</w:rPr>` : ''}<w:t xml:space="preserve">${t}</w:t></w:r>`;
    const body = [
      p('Chapter', 'Heading1'),
      `<w:p>${run('x')}${run('{', '<w:b/>')}${run('{title}}')} ${run('x')}${run('[', '<w:i/>')}${run('[Secret]]')} ${run('x')}${run('=', '<w:b/>')}${run('=y')}</w:p>`,
      p('{{{title}}} and ![[x.png]] and [a](b)'),
      p('[[Secret]] {{title}} ==x==', 'Title'),
      li('&gt; [!danger] boom', 1), li('1. nested?', 1),
      p('a&#0;IMG1&#0;b and literal &lt;br&gt; text'),
    ].join('');
    const r = await convertDocx(docx(body));
    const md = r.body;
    expect(md).not.toMatch(/(?<!\\)\{(?<!\\)\{|(?<!\\)\[(?<!\\)\[|(?<!\\)=(?<!\\)=/);
    expect(md).toContain('# \\[\\[Secret\\]\\] \\{\\{title\\}\\} \\=\\=x\\=\\=');
    expect(md).toContain('- \\> \\[!danger\\] boom\n- 1\\. nested?');
    expect(md).toContain('aIMG1b and literal \\<br> text');
    expect(md).not.toContain('\u0000');
    expect(r.images.size).toBe(0);
  });

  it('two line breaks in a table cell stay inside the cell', async () => {
    const cell = `<w:tc><w:p><w:r><w:t>a</w:t><w:br/><w:br/><w:t>b</w:t></w:r></w:p></w:tc>`;
    const r = await convertDocx(docx(p('T', 'Heading1') + `<w:tbl><w:tr>${cell}<w:tc>${p('c')}</w:tc></w:tr></w:tbl>`));
    expect(r.body).toBe('# T\n\n| a<br>b | c |\n| --- | --- |');
  });

  it('generated chapters are recognised in plain text, numbered or highlighted; empty headings do not end them; automatic numbers are renumbered', async () => {
    const numbered = (t: string, style: string, ilvl = 0) => `<w:p><w:pPr><w:pStyle w:val="${style}"/><w:numPr><w:ilvl w:val="${ilvl}"/><w:numId w:val="2"/></w:numPr></w:pPr><w:r><w:t>${t}</w:t></w:r></w:p>`;
    const body = [
      numbered('Inhoudsopgave', 'Heading1'),
      p('Inleiding 3'),
      `<w:p><w:pPr><w:pStyle w:val="Heading1"/></w:pPr><w:r><w:rPr><w:highlight w:val="yellow"/></w:rPr><w:t>A. Contents</w:t></w:r></w:p>`,
      p('', 'Heading1'),
      p('Introduction 3'),
      numbered('Inleiding', 'Heading1'),
      numbered('Doel', 'Heading2'),
      numbered('Conclusie', 'Heading1'),
    ].join('');
    const r = await convertDocx(docx(body));
    expect(r.left).toEqual(['Inhoudsopgave', 'Contents']);
    expect(r.body).toBe('# 1. Inleiding\n\n## 1.1. Doel\n\n# 2. Conclusie');
    // Contact details and version history are ordinary chapters now: the plugin no longer makes them.
    const kept = await convertDocx(docx(p('Contactgegevens', 'Heading1') + p('Auditor A') + p('Versiebeheer', 'Heading1') + p('0.1')));
    expect(kept.left).toEqual([]);
    expect(kept.body).toBe('# Contactgegevens\n\nAuditor A\n\n# Versiebeheer\n\n0.1');
  });

  it('guesses the language from common words', () => {
    expect(guessLanguage('De organisatie heeft een beleid voor de beveiliging van het netwerk.')).toBe('nl');
    expect(guessLanguage('The organisation has a policy for the security of the network.')).toBe('en');
  });
});

describe('the template note', () => {
  it('starts with a cover block with the Word title and subtitle, like the simple template', () => {
    const note = templateNote({ title: 'Audit: *ISMS*', subtitle: '', language: 'nl', body: '# Inleiding\n\nTekst' });
    expect(note).toBe('---\nlanguage: nl\n---\n\n> [!cover]\n> # Audit: \\*ISMS\\*\n> {{long_date}}\n\n> [!header]\n> Project: {{title}}\n> Document: Audit: \\*ISMS\\*\n\n> [!inhoud]\n\n\\pagebreak\n\n# Inleiding\n\nTekst\n');
    const en = templateNote({ title: '', subtitle: 'For {{x}}', language: 'en', body: 'x' });
    expect(en).toBe('> [!cover]\n> # {{title}}\n> For \\{ \\{x\\} \\}\n> {{long_date}}\n\n> [!header]\n> Project: {{title}}\n> Document: Report\n\nx\n');
  });
  it('file names from the Word file name', () => {
    expect(templateBaseName('20250924 Audit-Report: v1.0.docx')).toBe('20250924 Audit-Report v1.0');
    expect(templateBaseName('..docx')).toBe('Word-rapport');
    expect(templateBaseName('a[b]#c.DOCX')).toBe('a b c');
    expect(templateBaseName('CON.docx')).toBe('Word-rapport CON');
  });
});
