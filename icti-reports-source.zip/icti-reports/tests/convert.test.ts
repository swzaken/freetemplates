import { describe, expect, it } from 'vitest';
import { convertMarkdown, splitFrontmatter } from '../src/convert/markdown';
import type { Block, Inline } from '../src/convert/ast';

const para = (b: Block | undefined): Inline[] => {
  if (b?.t !== 'para') throw new Error(`expected para, got ${b?.t}`);
  return b.c;
};

describe('basics', () => {
  it('headings, paragraphs and emphasis', () => {
    const [h1, h2, p] = convertMarkdown('# One\n\n## Two\n\nA **b** *i* ***bi***');
    expect(h1).toMatchObject({ t: 'heading', level: 1, c: [{ t: 'text', v: 'One' }] });
    expect(h2).toMatchObject({ t: 'heading', level: 2 });
    expect(para(p)).toEqual([
      { t: 'text', v: 'A ' },
      { t: 'strong', c: [{ t: 'text', v: 'b' }] },
      { t: 'text', v: ' ' },
      { t: 'em', c: [{ t: 'text', v: 'i' }] },
      { t: 'text', v: ' ' },
      { t: 'em', c: [{ t: 'strong', c: [{ t: 'text', v: 'bi' }] }] },
    ]);
  });

  it('soft line breaks become spaces, hard breaks become br', () => {
    expect(para(convertMarkdown('a\nb')[0])).toEqual([{ t: 'text', v: 'a b' }]);
    expect(para(convertMarkdown('a\\\nb')[0])).toEqual([{ t: 'text', v: 'a' }, { t: 'br' }, { t: 'text', v: 'b' }]);
  });

  it('tight and loose lists, ordered start', () => {
    const [tight] = convertMarkdown('- a\n- b');
    expect(tight).toMatchObject({ t: 'list', ordered: false, loose: false, items: [[{ t: 'para' }], [{ t: 'para' }]] });
    const [loose] = convertMarkdown('3. a\n\n4. b');
    expect(loose).toMatchObject({ t: 'list', ordered: true, start: 3, loose: true });
  });

  it('a list right after a paragraph line is a separate list block', () => {
    expect(convertMarkdown('The MNCs are:\n- 4.1 x\n- 9.1 y').map((b) => b.t)).toEqual(['para', 'list']);
  });

  it('links keep only http(s) and mailto targets', () => {
    const c = para(convertMarkdown('[a](https://x.nl) [b](mailto:a@b.nl) [c](file:///etc/passwd) [d](javascript:alert(1)) [e](obsidian://open)')[0]);
    const hrefs = c.flatMap((n) => (n.t === 'link' ? [n.href] : []));
    // markdown-it already refuses file: and javascript:; other schemes keep their text but lose the target
    expect(hrefs).toEqual(['https://x.nl', 'mailto:a@b.nl', '']);
  });

  it('wikilinks show their alias or name', () => {
    expect(para(convertMarkdown('See [[Clients/ABC|ABC]] and [[Other#Part]].')[0])).toEqual([{ t: 'text', v: 'See ABC and Other.' }]);
  });

  it('records 1-based note lines including the frontmatter', () => {
    const { body, bodyLine } = splitFrontmatter('---\ntitle: x\n---\n\n# H\n\ntext');
    const [h, p] = convertMarkdown(body, bodyLine);
    expect(h.line).toBe(5);
    expect(p.line).toBe(7);
  });
});

describe('report conventions', () => {
  it('==placeholder== becomes a placeholder node', () => {
    expect(para(convertMarkdown('of ==the organisation== insight')[0])).toEqual([
      { t: 'text', v: 'of ' },
      { t: 'placeholder', c: [{ t: 'text', v: 'the organisation' }] },
      { t: 'text', v: ' insight' },
    ]);
  });

  it('<span style="color:red"> is red text on purpose, not a placeholder', () => {
    expect(para(convertMarkdown('a <span style="color:red">red **bold**</span> b')[0])).toEqual([
      { t: 'text', v: 'a ' },
      { t: 'red', c: [{ t: 'text', v: 'red ' }, { t: 'strong', c: [{ t: 'text', v: 'bold' }] }] },
      { t: 'text', v: ' b' },
    ]);
    for (const tag of [`<span style='color: red;'>`, '<span style="color:#FF0000">', '<SPAN STYLE="COLOR: #f00">', '<span style="color: rgb(255, 0, 0)">']) {
      expect(para(convertMarkdown(`${tag}x</span>`)[0])).toEqual([{ t: 'red', c: [{ t: 'text', v: 'x' }] }]);
    }
    // Other HTML, other colours, extra styles or a missing </span> stay literal text.
    for (const src of ['<span style="color:blue">x</span>', '<span style="color:red;font-size:40px">x</span>', '<span style="color:red">x', '<span class="r">x</span>', '<b>x</b>']) {
      expect(para(convertMarkdown(src)[0])).toEqual([{ t: 'text', v: src }]);
    }
    // Spans inside red text are counted: red ends at its own </span>; another span stays literal inside it.
    expect(para(convertMarkdown('<span style="color:red">a <span style="color:red">b</span> c</span> d')[0])).toEqual([
      { t: 'red', c: [{ t: 'text', v: 'a ' }, { t: 'red', c: [{ t: 'text', v: 'b' }] }, { t: 'text', v: ' c' }] },
      { t: 'text', v: ' d' },
    ]);
    expect(para(convertMarkdown('<span style="color:red">a <span class="x">b</span> c</span>')[0])).toEqual([
      { t: 'red', c: [{ t: 'text', v: 'a <span class="x">b</span> c' }] },
    ]);
    expect(para(convertMarkdown('<span style="color:red">a <span>b</span>')[0])).toEqual([{ t: 'text', v: '<span style="color:red">a <span>b</span>' }]);
    // Inside a table cell, and next to a placeholder.
    const [table] = convertMarkdown('| a |\n| --- |\n| <span style="color:red">r</span> ==p== |');
    expect(JSON.stringify(table)).toContain('{"t":"red","c":[{"t":"text","v":"r"}]}');
    expect(JSON.stringify(table)).toContain('"t":"placeholder"');
  });

  it('a lone "=" or unclosed "==" is plain text', () => {
    expect(para(convertMarkdown('a == b and c = d')[0])).toEqual([{ t: 'text', v: 'a == b and c = d' }]);
  });

  it('\\pagebreak on its own line, also directly after a paragraph line', () => {
    expect(convertMarkdown('a\n\\pagebreak\nb').map((b) => b.t)).toEqual(['para', 'pagebreak', 'para']);
    expect(convertMarkdown('x \\pagebreak y').map((b) => b.t)).toEqual(['para']);
  });

  it('audit words are ordinary text now; [!success] etc. are ordinary callouts', () => {
    expect(para(convertMarkdown('Observation (OBS): note')[0])).toEqual([{ t: 'text', v: 'Observation (OBS): note' }]);
    expect(convertMarkdown('> [!danger] Non-Conformity (NC)\n> big deviation.')[0]).toMatchObject({ t: 'quote', title: [{ t: 'text', v: 'Non-Conformity (NC)' }] });
    expect(para(convertMarkdown('\\findings')[0])).toEqual([{ t: 'text', v: '\\findings' }]);
  });

  it('the cover block: title, one line per line, the first picture', () => {
    const [c] = convertMarkdown('> [!cover]\n> # The *title*\n> Line one\n> Line **two**\n> ![Cover](a%20b.png)\n> ![[second.png]]\n>\n> After a blank line', 4);
    expect(c).toMatchObject({
      t: 'cover',
      line: 5,
      title: [{ t: 'text', v: 'The ' }, { t: 'em', c: [{ t: 'text', v: 'title' }] }],
      lines: [[{ t: 'text', v: 'Line one' }], [{ t: 'text', v: 'Line ' }, { t: 'strong', c: [{ t: 'text', v: 'two' }] }], [{ t: 'text', v: 'After a blank line' }]],
      image: { t: 'image', ref: 'a b.png', line: 9 },
    });
  });

  it('the cover block: below the bars an empty line between paragraphs is kept, above them it is not', () => {
    const [c] = convertMarkdown('> [!cover]\n> # T\n> Sub\n>\n> Date\n>\n> Author\n>\n> CONFIDENTIAL');
    if (c.t !== 'cover') throw new Error('expected cover');
    expect(c.lines.map((l) => (l[0] as { v?: string })?.v ?? '')).toEqual(['Sub', 'Date', 'Author', '', 'CONFIDENTIAL']);
  });

  it('the header block: every line is a header line (a heading too); pictures are left out', () => {
    expect(convertMarkdown('> [!header]\n> Project: *X*\n> ![[p.png]]\n> # Document: Y')[0]).toEqual({
      t: 'header',
      line: 1,
      lines: [[{ t: 'text', v: 'Project: ' }, { t: 'em', c: [{ t: 'text', v: 'X' }] }], [{ t: 'text', v: 'Document: Y' }]],
    });
    expect(convertMarkdown('> [!header] One\n> Two')[0]).toMatchObject({ lines: [[{ t: 'text', v: 'One' }], [{ t: 'text', v: 'Two' }]] });
  });

  it('other callouts and plain quotes become quotes', () => {
    const [q] = convertMarkdown('> [!note] Title\n> Body');
    expect(q).toMatchObject({ t: 'quote', title: [{ t: 'text', v: 'Title' }], c: [{ t: 'para', c: [{ t: 'text', v: 'Body' }] }] });
    expect(convertMarkdown('> just a quote')[0]).toMatchObject({ t: 'quote', title: null });
  });

  it('images: wiki embeds with width and markdown images', () => {
    const c = para(convertMarkdown('![[logo.png|300]] ![alt text](img/a%20b.png)')[0]);
    expect(c[0]).toMatchObject({ t: 'image', ref: 'logo.png', width: 300 });
    expect(c[2]).toMatchObject({ t: 'image', ref: 'img/a b.png' });
  });
});

describe('tables', () => {
  it('plain table with guessed widths', () => {
    const [t] = convertMarkdown('| Time | Topic |\n|---|---|\n| 13.00 | Audit opening |');
    if (t.t !== 'table') throw new Error('expected table');
    expect(t.head).toEqual([[{ t: 'text', v: 'Time' }], [{ t: 'text', v: 'Topic' }]]);
    expect(t.widths).toHaveLength(2);
    expect(t.rows[0][1]).toEqual([{ t: 'text', v: 'Audit opening' }]);
  });

  it('dash counts set relative widths', () => {
    expect(convertMarkdown('| a | b |\n|--|------|\n| 1 | 2 |')[0]).toMatchObject({ widths: [4, 6] });
  });

  it('an empty first header cell is an ordinary table now', () => {
    const [t] = convertMarkdown('| | Criterium | Observed | Findings |\n|---|---|---|---|\n| **4.1** | text | | |');
    if (t.t !== 'table') throw new Error('expected table');
    expect(t.rows[0][0]).toEqual([{ t: 'strong', c: [{ t: 'text', v: '4.1' }] }]);
    expect(t.rows[0][2]).toEqual([]);
  });

  it('<br> inside a cell is a line break; other HTML stays text', () => {
    const [t] = convertMarkdown('| a |\n|---|\n| x<br>y<BR/>z <b>no</b> |');
    if (t.t !== 'table') throw new Error('expected table');
    expect(t.rows[0][0]).toEqual([
      { t: 'text', v: 'x' }, { t: 'br' }, { t: 'text', v: 'y' }, { t: 'br' }, { t: 'text', v: 'z <b>no</b>' },
    ]);
  });
});

describe('escaping', () => {
  const SPECIALS = '# $ * _ \\ @ < > [ ] { } " ~ / = ` #set page(fill: red) #import "x.typ" <label> @ref $x^2$';

  it('Typst syntax in a note arrives as literal strings in the tree', () => {
    const blocks = JSON.parse(JSON.stringify(convertMarkdown('# #set text(red)\n\n`` ' + SPECIALS + ' ``')));
    expect(blocks[0].c[0].v).toBe('#set text(red)');
    expect(blocks[1].c[0]).toEqual({ t: 'code', v: SPECIALS });
  });

  it('raw HTML and fenced typst blocks are shown as text, never executed', () => {
    const blocks = convertMarkdown('<script>alert(1)</script>\n\n```typst\n#set page(fill: red)\n```');
    expect(blocks[0]).toMatchObject({ t: 'para', c: [{ t: 'text', v: '<script>alert(1)</script>' }] });
    expect(blocks[1]).toEqual({ t: 'codeblock', v: '#set page(fill: red)', line: 3 });
  });
});

describe('review regressions', () => {
  it('page breaks inside quotes and list items are dropped (only top-level works in Typst)', () => {
    expect(convertMarkdown('> a\n>\n> \\pagebreak')[0]).toMatchObject({ t: 'quote', c: [{ t: 'para' }] });
    const [l] = convertMarkdown('- a\n\n  \\pagebreak');
    if (l.t !== 'list') throw new Error('expected list');
    expect(l.items[0].map((b) => b.t)).toEqual(['para']);
  });

  it('a plain quote joins its lines with a space', () => {
    expect(convertMarkdown('> line one\n> line two')[0]).toMatchObject({ c: [{ t: 'para', c: [{ t: 'text', v: 'line one line two' }] }] });
  });

  it('frontmatter: empty block and a leading BOM', () => {
    expect(splitFrontmatter('---\n---\nbody')).toEqual({ yaml: '', body: 'body', bodyLine: 2 });
    expect(splitFrontmatter('﻿---\ntitle: x\n---\nbody').yaml).toBe('title: x');
  });

  it('empty headings are dropped', () => {
    expect(convertMarkdown('#\n\ntext').map((b) => b.t)).toEqual(['para']);
  });

  it('cells report the line of their own row', () => {
    const [t] = convertMarkdown('| a | b |\n|---|---|\n| 1 | 2 |\n| 3 | ![[p.png]] |');
    if (t.t !== 'table') throw new Error('expected table');
    expect(t.rows[1][1][0]).toMatchObject({ t: 'image', line: 4 });
  });

  it('a loose nested list does not make its parent loose', () => {
    expect(convertMarkdown('- a\n- b\n  - c\n\n  - d')[0]).toMatchObject({ t: 'list', loose: false });
  });

  it('[[#Section]] and ![[Other note]] show readable text', () => {
    expect(para(convertMarkdown('see [[#Scope]] and ![[Other note]]')[0])).toEqual([{ t: 'text', v: 'see Scope and Other note' }]);
  });

  it('images on later lines of a paragraph report their own line', () => {
    const c = para(convertMarkdown('![[a.png]]\n![[b.png]]\n![[c.png]]', 9)[0]);
    expect(c.flatMap((n) => (n.t === 'image' ? [n.line] : []))).toEqual([10, 11, 12]);
  });

  it("a table padded by Obsidian's table editor keeps usable widths", () => {
    const pad = (n: number) => '-'.repeat(n);
    const plain = convertMarkdown(`| Time | Topic |
| ${pad(13)} | ${pad(200)} |
| 13.00 | ${'x'.repeat(200)} |`)[0];
    expect(plain).toMatchObject({ widths: [13, 30] });
  });

  it('dash widths also work inside a quote', () => {
    const [q] = convertMarkdown('> | a | b |\n> |--|------|\n> | 1 | 2 |');
    expect(q).toMatchObject({ t: 'quote', c: [{ t: 'table', widths: [4, 6] }] });
  });
});

describe('automatic table of contents block', () => {
  it('> [!inhoud] and > [!contents] become a contents block, with an optional own title', async () => {
    const { convertMarkdown: markdownToBlocks } = await import('../src/convert/markdown');
    const blocks = markdownToBlocks('> [!inhoud]\n\n# Een\n\n> [!contents] Table of contents\n');
    expect(blocks[0]).toMatchObject({ t: 'contents', title: null });
    expect(blocks[1]).toMatchObject({ t: 'heading', level: 1 });
    expect(blocks[2]).toMatchObject({ t: 'contents', title: [{ t: 'text', v: 'Table of contents' }] });
  });

  it('findBlock finds it (the Inhoud button adds and removes it)', async () => {
    const { findBlock } = await import('../src/data/coverText');
    expect(findBlock(['> [!cover]', '> # T', '', '> [!Inhoud]', '', '\pagebreak'], 'contents')).toEqual({ start: 3, end: 4, imageLine: -1 });
    expect(findBlock(['```', '> [!inhoud]', '```'], 'contents')).toBeNull();
  });
});
