---
language: nl
---

> [!cover]
> # Interne audit ISO 27001
> Rapport voor ABC
> 5 maart 2026
> Opgesteld voor
> **ABC B.V.**
> Jan Jansen, jan@abc.example

# Samenvatting

Typst specials stay literal: # $ * _ \ @ < > [ ] { } " ~ / = ` and #set page(fill: red) and #import "x.typ" and <label> @ref.

A missing image: ![[does-not-exist.png]] and a web image ![x](https://example.com/a.png).

1. First numbered
2. Second with **bold** and *italic* and ***both*** and [a link](https://ictinstitute.nl) and [bad](javascript:alert(1))

> [!note] A plain callout
> Rendered as a quote with a title.

\pagebreak

# Na de pagina-einde

`code with #hash`
