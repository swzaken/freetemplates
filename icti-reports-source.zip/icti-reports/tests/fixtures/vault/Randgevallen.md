> [!cover]
> # A Very Long Report Title That Goes On And On Beyond The Page Width Of The Cover Page
> An equally long subtitle that does not fit on a single line of the cover either, really
> November 9 2026
> ![[veer.png]]
> Prepared for ABC
> Sieuwert van Otterloo
> Jan Jansen
> Noah Wazir

> [!header]
> Project: Edge cases with a very long first header line that goes on and on
> Document: **Edge** cases

# A level-one heading that is far too long to fit on one line of the contents page, so it has to wrap

## Short H2

### A level-three heading

Text with an inline image ![[veer.png]] in the middle.

![[veer.png]]

| Logo | Text |
|---|---|
| ![[veer.png]] | cell |

> quote
>
> \pagebreak

- item

  \pagebreak

#### Level four
