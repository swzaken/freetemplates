> [!cover]
> # Example report - word
> A report made by ICT Institute
> November 9 2026

# Management summary

This report is the final deliverable of an ISO27001 internal audit, conducted by ICT Institute. The goal of the review was to give the management of ==the organisation== insight into the state of the Information Security Management System, and fulfil an ISO27001 requirement of performing internal audits. The audit took place in on …

In this audit, no Major Non-Conformities (NC) were found.  This means that The ISMS of ABC conforms to its own requirements, the requirements of ISO27001:2022 and is effectively implemented and maintained.

The MNC’s are as follows:
- 4.1 Climate change not mentioned
- 9.1 For multiple KPIs no values have been measured

# Audit methodology

## Audit process

The audit was conducted through online video interviews. In these interviews, the auditor asked the auditees to explain how ISMS elements are implemented. The questions were based on the ISMS requirements and previous audit results. In addition, interviewees were asked to show procedures, contracts, tickets, configuration and other evidence for the implementation of requirements.

## Types of findings

The internal audit can return three types of findings:

> [!success] Observation (OBS)
> no compliancy issue for ISO27001, but an opportunity for improvement.

> [!warning] Minor Non-Conformity (MNC)
> a deviation from ISO27001 and/or organisation’s procedures that does not affect the overall effectiveness of the ISMS.

> [!danger] Non-Conformity (NC)
> a deviation from ISO27001 and/or organisation’s procedures that affects the overall effectiveness of the ISMS.

# Audit plan

## Day 1: Nov 1 2026

| Time | Topic | Attendees | Norm element |
|--------|---------|----------------|----------------|
| 13.00 – 13.30 | Audit opening | CSO, CEO, CISO | |
| 13.30 – 14.30 | Main ISMS structure: context, risk | CSO, CEO, CISO | ISO 27001: (4,5,6,8) |
| 14.30 – 15.00 | Control measures | CSO, CISO (CEO optional) | ISO 27001: (7,9,10), A5 (incidents), A6 (training) |
| 15.00 – 15.05 | Break | | |
| 15.05 – 16.00 | Organisational controls – part 1 | CSO, CISO(CEO optional) | A5:1–17, A7 |
| 16.00 – 17.00 | Organisational controls – part 2 (suppliers, compliance, GDPR) | CSO, CISO, CEO/privacy officer | A5:18-34 |

# High Level Structure (HLS) results

## ISO27001 Chapter 4 – Context of the organisation

| | Criterium | Observed in audit | Findings |
|---|---|---|---|
| **4.1** | The organization shall determine external and internal issues that are relevant to its purpose and that affect its ability to achieve the intended outcome(s) of its information security management system. ***The organization shall determine whether climate change is a relevant issue.*** | | |
| **4.2 \*** | The organization shall determine:<br>a) interested parties that are relevant to the information security management system; and<br>b) the requirements of these interested parties relevant to information security.<br>**c) Which of these requirements will be addressed through the Information security management system** | | |
| **4.3** | The organization shall determine the boundaries and applicability of the information security management system to establish its scope.<br><br>When determining this scope, the organization shall consider:<br>a) the external and internal issues referred to in 4.1;<br>b) the requirements referred to in 4.2; and<br>c) **interfaces and dependencies between activities performed by the organization, and those that are performed by other organizations.**<br>The scope shall be available as documented information. | | |
| **4.4 \*** | The organization shall establish, implement, maintain and continually improve an information security management system, including the processes needed and their interactions, in accordance with the requirements of this International Standard. | | |

# Annex results

## Annex A5 – Information security controls

| | Criterium | Observed in audit | Findings |
|---|---|---|---|
| **5.1** | Information security policy and topic-specific policies shall be defined, approved by management, published, communicated to and acknowledged by relevant personnel and relevant interested parties, and reviewed at planned intervals and if significant changes occur. | | |
| **5.2** | Information security roles and responsibilities shall be defined and allocated according to the organization needs. | | |
| **5.3** | Conflicting duties and conflicting areas of responsibility shall be segregated. | | |

Note\
\* means a clause was modified in the 2022 update.
