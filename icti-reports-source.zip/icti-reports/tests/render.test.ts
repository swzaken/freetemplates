// Render tests: compile the fixtures with the real WASM engine, fonts and layout.
// The pixel/position comparison against the Word PDF is tools/compare.py (needs Python + pdfplumber).
import { mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { fillTemplate } from '../src/data/template';
import { describe, expect, it } from 'vitest';
import { renderNote } from '../tools/render';

const VAULT = 'tests/fixtures/vault';
const pageCount = (pdf: Uint8Array) => (Buffer.from(pdf).toString('latin1').match(/\/Type\s*\/Page\b/g) ?? []).length;

describe('render', () => {
  it('renders the example report to 4 pages without errors (no automatic contents page)', async () => {
    const r = await renderNote(`${VAULT}/Voorbeeldrapport.md`, VAULT);
    expect(r.diagnostics.filter((d) => d.severity === 'error')).toEqual([]);
    expect(r.prepared.diagnostics).toEqual([]);
    expect(r.pdf).not.toBeNull();
    expect(pageCount(r.pdf!)).toBe(4);
    mkdirSync('out', { recursive: true });
    writeFileSync('out/example.pdf', r.pdf!);
  }, 60_000);

  it('renders the Dutch report with a cover of six lines; a missing and a web image are warnings, not errors', async () => {
    const r = await renderNote(`${VAULT}/Gekoppeld rapport.md`, VAULT);
    expect(r.pdf).not.toBeNull();
    expect(r.prepared.meta.cover?.lines).toHaveLength(5);
    expect(r.prepared.diagnostics.map((d) => d.severity)).toEqual(['warning', 'warning']);
    writeFileSync('out/dutch.pdf', r.pdf!);
  }, 60_000);

  it('renders edge cases (long cover title and subtitle, cover picture, wrapping contents entry, images in cells)', async () => {
    const r = await renderNote(`${VAULT}/Randgevallen.md`, VAULT);
    expect(r.diagnostics.filter((d) => d.severity === 'error')).toEqual([]);
    expect(r.prepared.diagnostics).toEqual([]);
    expect(r.prepared.meta.cover?.image).toMatch(/^\/img\//);
    expect(r.pdf).not.toBeNull();
    writeFileSync('out/edge.pdf', r.pdf!);
  }, 60_000);

  it.each([
    ['Simple report', 'en', 2],
    ['Eenvoudig rapport', 'nl', 2],
  ])('the starter template "%s", filled in, renders without errors or warnings', async (name, lang, coverLines) => {
    const tpl = readFileSync(`vault-starter/ICT Rapporten/Sjablonen/${name}.md`, 'utf8');
    mkdirSync('out', { recursive: true });
    const note = `out/${name} (test).md`;
    writeFileSync(note, fillTemplate(tpl, { type: name, folder: 'ABC', title: 'ABC report 2026', today: new Date(2026, 10, 9) }));
    try {
      const r = await renderNote(note, 'out');
      expect(r.diagnostics).toEqual([]);
      expect(r.prepared.diagnostics).toEqual([]);
      expect(r.prepared.meta.lang).toBe(lang);
      expect(r.prepared.meta.cover?.lines).toHaveLength(coverLines);
      expect(r.prepared.meta.cover?.ownImage).toBe(false);
      expect(r.prepared.placeholders.length).toBeGreaterThan(0);
      writeFileSync(`out/starter-${name}.pdf`, r.pdf!);
    } finally {
      rmSync(note);
    }
  }, 60_000);

  it('Typst syntax in a heading is rendered literally', async () => {
    const r = await renderNote(`${VAULT}/Gekoppeld rapport.md`, VAULT);
    const special = '#set page(fill: red) $x$ *b* <l> @r \\ "q"';
    const doc = JSON.parse(r.files['/doc.json'] as string);
    doc.unshift({ t: 'heading', level: 1, line: 1, c: [{ t: 'text', v: special }] });
    const files = { ...r.files, '/doc.json': JSON.stringify(doc) };
    expect(r.engine.compile(files).pdf).not.toBeNull();
    const headings = r.engine.query(files, 'heading') as { body: { text?: string } }[];
    expect(headings.map((h) => h.body.text)).toContain(special);
  }, 60_000);

  it('without a cover block there is no cover page', async () => {
    const r = await renderNote(`${VAULT}/Voorbeeldrapport.md`, VAULT);
    const meta = JSON.parse(r.files['/meta.json'] as string);
    const noCover = r.engine.compile({ ...r.files, '/meta.json': JSON.stringify({ ...meta, cover: null }) });
    expect(noCover.pdf).not.toBeNull();
    expect(pageCount(noCover.pdf!)).toBe(3);
  }, 60_000);

  it('a broken layout reports the template line instead of crashing', async () => {
    const r = await renderNote(`${VAULT}/Voorbeeldrapport.md`, VAULT);
    const res = r.engine.compile({ ...r.files, '/report.typ': '#let x = \n' });
    expect(res.pdf).toBeNull();
    expect(res.diagnostics[0]).toMatchObject({ path: '/report.typ', line: 1, severity: 'error' });
  }, 60_000);
});
