import { readdirSync, readFileSync, statSync } from 'node:fs';
import { join } from 'node:path';
import { afterEach, describe, expect, it } from 'vitest';
import { NL, setUiLanguage, t } from '../src/i18n';

const files = (dir: string): string[] =>
  readdirSync(dir).flatMap((f) => (statSync(join(dir, f)).isDirectory() ? files(join(dir, f)) : f.endsWith('.ts') ? [join(dir, f)] : []));

describe('plugin language', () => {
  afterEach(() => setUiLanguage('en'));

  it('every t() text in the source has a Dutch translation', () => {
    const missing: string[] = [];
    for (const f of files('src').filter((f) => !f.endsWith('i18n.ts'))) {
      const src = readFileSync(f, 'utf8');
      for (const m of src.matchAll(/\bt\(\s*(['"])((?:\\.|(?!\1).)*)\1/g)) {
        const text = m[2].replace(/\\(['"\\])/g, '$1');
        if (!(text in NL)) missing.push(`${f}: ${text}`);
      }
    }
    expect(missing).toEqual([]);
  });

  it('translations keep the same {placeholders}', () => {
    const vars = (s: string) => [...s.matchAll(/\{(\w+)\}/g)].map((m) => m[1]).sort().join(',');
    const wrong = Object.entries(NL).filter(([en, nl]) => vars(en) !== vars(nl)).map(([en]) => en);
    expect(wrong).toEqual([]);
  });

  it('switches between English and Dutch and fills in values', () => {
    expect(t('Exported {path}', { path: 'a.pdf' })).toBe('Exported a.pdf');
    setUiLanguage('nl');
    expect(t('Exported {path}', { path: 'a.pdf' })).toBe('Geëxporteerd: a.pdf');
    expect(t('Not in the dictionary')).toBe('Not in the dictionary');
  });
});
