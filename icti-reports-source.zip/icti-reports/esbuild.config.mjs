// Builds the plugin folder dist/icti-reports/ (copy it into <vault>/.obsidian/plugins/), or the dev CLI with --cli.
import { build } from 'esbuild';
import { cpSync, mkdirSync, readFileSync, readdirSync, rmSync, writeFileSync } from 'node:fs';

const COMPILER = 'node_modules/@myriaddreamin/typst-ts-web-compiler/pkg';

// The engine is always started from bytes (initSync). Remove its "load from URL" path so the bundle
// contains no fetch() at all.
const noNetwork = {
  name: 'no-network',
  setup(b) {
    b.onLoad({ filter: /typst_ts_web_compiler\.mjs$/ }, (args) => {
      const src = readFileSync(args.path, 'utf8');
      const patched = src.replace('module_or_path = fetch(module_or_path);', "throw new Error('Loading the engine from a URL is disabled.');");
      if (patched === src) throw new Error('no-network: expected fetch() call not found in the Typst compiler glue');
      return { contents: patched, loader: 'js' };
    });
  },
};

if (process.argv.includes('--cli')) {
  await build({ entryPoints: ['tools/render.ts'], outfile: 'out/render.mjs', bundle: true, platform: 'node', format: 'esm', target: 'node20', logLevel: 'warning' });
} else {
  const prod = !process.argv.includes('--dev');
  // 1. The worker, as a self-contained script.
  const worker = await build({
    entryPoints: ['src/engine/worker.ts'], bundle: true, write: false, format: 'iife', platform: 'browser',
    target: 'es2022', minify: prod, plugins: [noNetwork], logLevel: 'warning',
  });
  const workerSource = worker.outputFiles[0].text;

  // 2. The plugin, with the worker source inlined as a string.
  const out = 'dist/icti-reports';
  rmSync(out, { recursive: true, force: true });
  mkdirSync(`${out}/fonts`, { recursive: true });
  await build({
    entryPoints: ['src/main.ts'], outfile: `${out}/main.js`, bundle: true, format: 'cjs', platform: 'browser',
    target: 'es2022', minify: prod, sourcemap: prod ? false : 'inline', external: ['obsidian', 'electron'],
    logLevel: 'warning',
    plugins: [noNetwork, {
      name: 'worker-source',
      setup(b) {
        b.onResolve({ filter: /^icti:worker-source$/ }, () => ({ path: 'worker-source', namespace: 'icti' }));
        b.onLoad({ filter: /.*/, namespace: 'icti' }, () => ({ contents: `export default ${JSON.stringify(workerSource)};`, loader: 'js' }));
      },
    }],
  });

  // 3. Static files.
  cpSync('manifest.json', `${out}/manifest.json`);
  cpSync('styles.css', `${out}/styles.css`);
  cpSync('README.md', `${out}/README.md`);
  cpSync('THIRD_PARTY_NOTICES.md', `${out}/THIRD_PARTY_NOTICES.md`);
  cpSync(`${COMPILER}/typst_ts_web_compiler_bg.wasm`, `${out}/typst.wasm`);
  for (const f of readdirSync('assets/fonts')) cpSync(`assets/fonts/${f}`, `${out}/fonts/${f}`);
  cpSync('assets/img', `${out}/assets`, { recursive: true });
  cpSync('layout', `${out}/layout`, { recursive: true });

  // 4. Starter notes (templates, example client and people) inside the plugin, with a file list the
  //    plugin uses to install them into a vault. The layout is installed from layout/ and assets/.
  cpSync('vault-starter', `${out}/starter`, { recursive: true });
  const list = (dir, base = '') => readdirSync(dir, { withFileTypes: true })
    .filter((e) => !e.name.startsWith('.') && e.name !== 'desktop.ini' && e.name !== 'Thumbs.db')
    .flatMap((e) => (e.isDirectory() ? list(`${dir}/${e.name}`, `${base}${e.name}/`) : [`${base}${e.name}`]));
  writeFileSync(`${out}/starter/files.json`, JSON.stringify(list('vault-starter'), null, 1));

  // 5. The same starter as a plain folder to copy into a vault by hand, layout included.
  const vs = 'dist/vault-starter';
  rmSync(vs, { recursive: true, force: true });
  cpSync('vault-starter', vs, { recursive: true });
  cpSync('layout/report.typ', `${vs}/ICT Rapporten/Opmaak/report.typ`);
  cpSync('assets/img', `${vs}/ICT Rapporten/Opmaak/assets`, { recursive: true });
  console.log(`built ${out} and ${vs}`);
  await import('./tools/build-theme.mjs');
}
