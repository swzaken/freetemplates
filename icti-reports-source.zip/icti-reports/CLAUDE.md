# ICT Institute Reports (Obsidian plugin) – notes for working on the code

Note -> JSON tree (src/convert) + metadata (src/data) -> Typst layout (layout/report.typ) -> PDF via the Typst WASM compiler in a Web Worker (src/engine). Obsidian glue: src/main.ts, src/obsidian/, src/preview/. User docs: README.md and docs/.

## Rules
- Offline only: no network at runtime. WASM and fonts are passed as bytes; `tools/check-offline.mjs` must pass.
- Note text reaches Typst only as JSON data (`json("/doc.json")`), never as Typst source. No raw Typst.
- Vault-only file access (`isSafeImageRef`, `isVaultPath`); Typst sees only the files we map.
- UI text via `setText`/`createEl({text})`, never innerHTML.
- Exact dependency versions; `.npmrc` has `ignore-scripts=true`.

## Commands
- `npm ci`, `npm test`, `npx tsc --noEmit`, `npm run build`, `node tools/check-offline.mjs`
- `npm run render -- <note.md> [out.pdf] [--vault dir]` – CLI render
- `node tools/install-test-vault.mjs [vault dir]` – copy the build (plugin + theme) into a test vault (default `../Test Vault`); keeps data.json

## Obsidian notes
- Never cast `leaf.view` to `MarkdownView`: background tabs are deferred and have a placeholder view. Use `markdownViews()` / `markdownView()` from src/obsidian/views.ts.
- Plugin code that imports 'obsidian' can be unit-tested against tests/mocks/obsidian.ts (alias in vitest.config.ts).
- Per-person state (author name, note zoom) goes in `app.saveLocalStorage`, not in data.json (data.json is in .obsidian and synced in a shared vault).
- Event handlers must not throw: route errors to `plugin.errorLog.record()` (errors.log in the plugin folder).

## Layout notes
- Text positions are baselines; `at(x, y, ...)` places by baseline. Line height = Carlito hhea 0.952/-0.2685 em.
- Spacing between blocks comes only from `gap(prev, next)` in report.typ (all Typst block spacing is 0).
- Raise `// layout-version: N` at the top of report.typ (and MIN_LAYOUT_VERSION in src/obsidian/resources.ts) when the plugin starts relying on new layout features: vault copies of the layout are not updated automatically.
