import { fileURLToPath } from 'node:url';
import { defineConfig } from 'vitest/config';

// Code that imports 'obsidian' is tested against a small stand-in (tests/mocks/obsidian.ts).
export default defineConfig({
  resolve: { alias: { obsidian: fileURLToPath(new URL('./tests/mocks/obsidian.ts', import.meta.url)) } },
});
