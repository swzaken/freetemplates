// The change log (logboek) of every note: when it was made, and every later change and by whom.
// One JSON file per note in the hidden folder ".logboek" of the vault: it syncs with a shared vault, but
// Obsidian does not show it in the file list and it never reaches a report or PDF.
// Edits are grouped per editing session: saves by the same person within SESSION_GAP form one entry.
import { Modal, Notice, TFile, normalizePath, type App, type TAbstractFile } from 'obsidian';
import { changeDetails, logFileName, summarize, type LogEntry } from '../data/changes';
import { t } from '../i18n';
import type IctiReportsPlugin from '../main';
import { markdownView, markdownViews } from './views';

export const LOG_FOLDER = '.logboek';
const AUTHOR_KEY = 'icti-reports-author';
/** Saves further apart than this start a new log entry. */
const SESSION_GAP = 15 * 60 * 1000;
/** A save counts as made here (not by a sync program) when the user typed or clicked this recently. */
const INPUT_WINDOW = 10 * 1000;
const WRITE_DELAY = 3000;

interface Session {
  id: string;
  base: string;
  latest: string;
  start: number;
  last: number;
}

/** Entries as stored, filtered to well-formed ones (a sync merge can leave odd items behind). */
function validEntries(data: unknown): LogEntry[] {
  if (!Array.isArray(data)) return [];
  return data.filter((e): e is LogEntry => !!e && typeof e === 'object' && typeof (e as LogEntry).time === 'string' && typeof (e as LogEntry).kind === 'string');
}

export class ChangeLog {
  /** Last known text of the notes open in an editor here, to see what a save changed. */
  private known = new Map<string, string>();
  private sessions = new Map<string, Session>();
  private timers = new Map<string, number>();
  /** Writes per log file, one after the other. */
  private queue = new Map<string, Promise<void>>();
  private lastInput = 0;
  /** The note of the editor that was active last (clicking the preview or a panel does not change it). */
  private editing: string | null = null;
  private toldAboutName = false;

  constructor(private plugin: IctiReportsPlugin) {}

  start(): void {
    const p = this.plugin;
    const { workspace, vault } = p.app;
    this.listen(document);
    // Pop-out windows have their own document.
    p.registerEvent(workspace.on('window-open', (w) => this.listen(w.doc)));
    p.registerEvent(workspace.on('active-leaf-change', (leaf) => {
      const view = markdownView(leaf);
      if (view?.file) {
        this.editing = view.file.path;
        this.safe(() => this.remember(view.file));
      }
    }));
    // Opening another note in the same tab (a link, the file list, New report) fires only file-open.
    p.registerEvent(workspace.on('file-open', (file) => {
      if (file && markdownView(workspace.getMostRecentLeaf())?.file?.path === file.path) this.editing = file.path;
      this.safe(() => this.remember(file));
    }));
    // Obsidian reports every existing file as "created" while it loads the vault: only listen once it is ready.
    workspace.onLayoutReady(() => {
      this.editing = workspace.getActiveFile()?.path ?? null;
      this.safe(() => this.remember(workspace.getActiveFile()));
      p.registerEvent(vault.on('create', (f) => this.safe(() => this.created(f))));
      p.registerEvent(vault.on('modify', (f) => this.safe(() => this.modified(f))));
      p.registerEvent(vault.on('rename', (f, old) => this.safe(() => this.renamed(f, old))));
      p.registerEvent(vault.on('delete', (f) => this.deleted(f)));
    });
    p.register(() => this.flushAll());
  }

  /** The name written in the log: set per computer (not in the shared plugin settings). */
  author(): string {
    const v = this.plugin.app.loadLocalStorage(AUTHOR_KEY);
    return typeof v === 'string' ? v.trim() : '';
  }

  setAuthor(name: string): void {
    this.plugin.app.saveLocalStorage(AUTHOR_KEY, name.trim() || null);
  }

  /** All entries of a note, oldest first. Without a "created" entry, the file date stands in for it. */
  async entries(file: TFile): Promise<LogEntry[]> {
    const log = this.logPath(file.path);
    let list: LogEntry[] = [];
    let error: unknown = null;
    await this.serial(log, async () => {
      try {
        list = await this.read(log); // in the queue, so never half-way through a write
      } catch (e) {
        error = e; // reported to the Log window below, not swallowed by the queue
      }
    });
    if (error) throw error;
    if (!list.some((e) => e.kind === 'created')) {
      list.unshift({ time: new Date(file.stat.ctime).toISOString(), author: '', kind: 'created' });
    }
    return list.sort((a, b) => a.time.localeCompare(b.time));
  }

  /** Records a PDF export of the note. */
  async exported(file: TFile, pdfPath: string): Promise<void> {
    await this.append(file.path, { time: new Date().toISOString(), author: this.name(), kind: 'exported', to: pdfPath });
  }

  private listen(doc: Document): void {
    for (const type of ['keydown', 'pointerdown', 'paste', 'drop', 'input'] as const) {
      this.plugin.registerDomEvent(doc, type, () => (this.lastInput = Date.now()), { capture: true });
    }
  }

  /** Runs an event handler; an error (for example a file deleted while it was read) is logged, never thrown. */
  private safe(job: () => Promise<void>): void {
    job().catch((e) => this.plugin.errorLog.record('change log', e));
  }

  private isNote(f: TAbstractFile | null): f is TFile {
    return f instanceof TFile && f.extension === 'md';
  }

  /** The user typed or clicked in a focused Obsidian window just now (and a sync program did not make the change). */
  private local(): boolean {
    return activeDocument.hasFocus() && Date.now() - this.lastInput < INPUT_WINDOW;
  }

  private isOpen(file: TFile): boolean {
    return markdownViews(this.plugin.app).some((v) => v.file?.path === file.path);
  }

  /** The change was made here, in this note: it is the note of the last active editor and the user just typed or
   *  clicked. A colleague's change that a sync program brings into another open note does not count. */
  private editedHere(file: TFile): boolean {
    return this.local() && file.path === this.editing && this.isOpen(file);
  }

  /** The author name. Without one, entries say "Unknown" and a notice tells once how to set it; nothing is ever
   *  opened while you type (a dialog would take the keyboard). */
  private name(): string {
    const name = this.author();
    if (!name && !this.toldAboutName) {
      this.toldAboutName = true;
      new Notice(t('Set your name for the change log under Settings → ICT Institute Reports → Your name.'), 10000);
    }
    return name || t('Unknown');
  }

  private async remember(file: TFile | null): Promise<void> {
    if (this.isNote(file) && !this.known.has(file.path) && this.isOpen(file)) this.known.set(file.path, await this.plugin.app.vault.cachedRead(file));
  }

  private async created(file: TAbstractFile): Promise<void> {
    if (!this.isNote(file) || !this.local()) return;
    await this.append(file.path, { time: new Date().toISOString(), author: this.name(), kind: 'created' });
  }

  private async modified(file: TAbstractFile): Promise<void> {
    if (!this.isNote(file)) return;
    // Only notes open in an editor here are followed; others are not read at all (a sync can bring hundreds).
    if (!this.isOpen(file)) {
      this.known.delete(file.path);
      return;
    }
    const before = this.known.get(file.path);
    const after = await this.plugin.app.vault.read(file);
    this.known.set(file.path, after);
    if (before === after || !this.editedHere(file)) return;
    const now = Date.now();
    let s = this.sessions.get(file.path);
    if (!s || now - s.last > SESSION_GAP) {
      s = { id: `${now.toString(36)}-${Math.random().toString(36).slice(2, 8)}`, base: before ?? after, latest: after, start: now, last: now };
      this.sessions.set(file.path, s);
    }
    s.latest = after;
    s.last = now;
    this.schedule(file.path);
  }

  private async renamed(file: TAbstractFile, oldPath: string): Promise<void> {
    if (!this.isNote(file)) return;
    for (const map of [this.known, this.sessions] as Map<string, unknown>[]) {
      if (map.has(oldPath)) {
        map.set(file.path, map.get(oldPath));
        map.delete(oldPath);
      }
    }
    if (this.editing === oldPath) this.editing = file.path;
    const timer = this.timers.get(oldPath);
    if (timer !== undefined) {
      window.clearTimeout(timer);
      this.timers.delete(oldPath);
      this.schedule(file.path);
    }
    // The log moves with the note.
    const from = this.logPath(oldPath);
    const to = this.logPath(file.path);
    await this.serial(from, async () => {
      const adapter = this.plugin.app.vault.adapter;
      if ((await adapter.exists(from)) && !(await adapter.exists(to))) await adapter.rename(from, to);
    });
    if (this.local()) await this.append(file.path, { time: new Date().toISOString(), author: this.name(), kind: 'renamed', from: oldPath, to: file.path });
  }

  /** A deleted note: forget it. Its log file stays (the history of a deleted report is kept). */
  private deleted(file: TAbstractFile): void {
    window.clearTimeout(this.timers.get(file.path));
    this.timers.delete(file.path);
    this.sessions.delete(file.path);
    this.known.delete(file.path);
  }

  private schedule(path: string): void {
    window.clearTimeout(this.timers.get(path));
    this.timers.set(path, window.setTimeout(() => this.safe(() => this.writeSession(path)), WRITE_DELAY));
  }

  private flushAll(): void {
    for (const [path, timer] of this.timers) {
      window.clearTimeout(timer);
      this.safe(() => this.writeSession(path));
    }
    this.timers.clear();
  }

  /** Writes (or updates) the log entry of the open editing session of a note. */
  private async writeSession(path: string): Promise<void> {
    this.timers.delete(path);
    const s = this.sessions.get(path);
    if (!s) return;
    const sum = summarize(s.base, s.latest);
    const empty = !sum.chapters.length && !sum.properties.length && !sum.added && !sum.removed;
    const entry: LogEntry = {
      time: new Date(s.start).toISOString(),
      end: new Date(s.last).toISOString(),
      author: this.name(),
      kind: 'edited',
      ...sum,
      details: changeDetails(s.base, s.latest),
      session: s.id,
    };
    const log = this.logPath(path);
    await this.serial(log, async () => {
      const old = await this.read(log);
      const list = old.filter((e) => e.session !== s.id);
      if (empty && list.length === old.length) return; // nothing to add or take back (e.g. only re-saved)
      if (!empty) list.push(entry);
      await this.write(log, list);
    });
  }

  private async append(path: string, entry: LogEntry): Promise<void> {
    const log = this.logPath(path);
    await this.serial(log, async () => this.write(log, [...(await this.read(log)), entry]));
  }

  private logPath(notePath: string): string {
    return normalizePath(`${LOG_FOLDER}/${logFileName(notePath)}`);
  }

  /** Runs jobs on one log file one after the other; a failed job is logged and does not block the next. */
  private serial(key: string, job: () => Promise<void>): Promise<void> {
    const next = (this.queue.get(key) ?? Promise.resolve()).then(job).catch((e) => this.plugin.errorLog.record('change log', e));
    this.queue.set(key, next);
    return next;
  }

  private async read(path: string): Promise<LogEntry[]> {
    const adapter = this.plugin.app.vault.adapter;
    if (!(await adapter.exists(path))) return [];
    const text = await adapter.read(path); // a locked or unreadable file throws here and is left alone
    try {
      return validEntries(JSON.parse(text));
    } catch (e) {
      if (!(e instanceof SyntaxError)) throw e;
      // Not valid JSON (for example a sync conflict): keep it aside and start a new list rather than lose it silently.
      await adapter.rename(path, `${path}.${Date.now()}.damaged`).catch(() => {});
      new Notice(t('A change log could not be read and was set aside: {path}', { path }));
      return [];
    }
  }

  private async write(path: string, list: LogEntry[]): Promise<void> {
    const adapter = this.plugin.app.vault.adapter;
    if (!(await adapter.exists(LOG_FOLDER))) await adapter.mkdir(LOG_FOLDER);
    await adapter.write(path, JSON.stringify(list, null, 1));
  }
}

/** Asks for the name to write in the change log (only opened by a click, never while typing). */
export class AuthorModal extends Modal {
  constructor(app: App, private current: string, private done: (name: string) => void) {
    super(app);
  }

  onOpen(): void {
    this.titleEl.setText(t('Your name for the change log'));
    this.contentEl.createEl('p', { text: t('Changes you make are logged under this name. You can change it later in the plugin settings.') });
    const input = this.contentEl.createEl('input', { type: 'text', cls: 'icti-name-input', value: this.current, attr: { placeholder: t('First and last name') } });
    const save = () => {
      if (!input.value.trim()) return;
      this.done(input.value);
      this.close();
    };
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        save();
      }
    });
    const buttons = this.contentEl.createDiv({ cls: 'modal-button-container' });
    buttons.createEl('button', { text: t('Save'), cls: 'mod-cta' }).addEventListener('click', save);
    buttons.createEl('button', { text: t('Cancel') }).addEventListener('click', () => this.close());
    window.setTimeout(() => input.focus(), 0);
  }
}
