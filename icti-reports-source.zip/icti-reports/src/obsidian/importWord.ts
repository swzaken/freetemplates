// "Import Word report": pick one or more .docx files on this computer; each becomes a report template (a note in the
// templates folder of the settings), so "New report" offers it as a report type. Pictures go into a subfolder of the
// templates folder. Nothing is overwritten: a name that is taken gets " 2", " 3" ….
import { normalizePath, Notice, TFile, TFolder, Vault, type App, type TAbstractFile } from 'obsidian';
import { convertDocx, fillImages, NOT_WORD } from '../import/docx';
import { templateBaseName, templateNote } from '../import/template';
import { DAMAGED, TOO_LARGE } from '../import/zip';
import { t, uiLanguage } from '../i18n';
import { isVaultPath } from '../pipeline';
import type IctiReportsPlugin from '../main';

const MAX_SIZE = 100 * 1024 * 1024;

/** The chosen files (not read yet: each is read when it is imported, so several large files are never all in memory). */
function pickWordFiles(plugin: IctiReportsPlugin): Promise<File[]> {
  return new Promise((resolve) => {
    const input = activeDocument.createElement('input');
    input.type = 'file';
    input.accept = '.docx';
    input.multiple = true;
    input.addEventListener('change', () => {
      try {
        resolve(Array.from(input.files ?? []));
      } catch (e) {
        plugin.errorLog.record('import Word report: file picker', e);
        resolve([]);
      }
    });
    input.addEventListener('cancel', () => resolve([]));
    input.click();
  });
}

let running = false;

export async function importWordReports(plugin: IctiReportsPlugin): Promise<void> {
  try {
    if (running) {
      new Notice(t('Word reports are already being imported.'));
      return;
    }
    const setting = plugin.settings.templatesFolder.trim();
    if (!setting || !isVaultPath(setting)) {
      new Notice(t('Set a templates folder inside the vault first (Settings → ICT Institute Reports → Templates folder).'), 10000);
      return;
    }
    const files = await pickWordFiles(plugin);
    if (!files.length || running) return;
    running = true;
    try {
      const folder = await templatesFolder(plugin, normalizePath(setting));
      let last: TFile | null = null;
      for (const f of files) {
        try {
          if (f.size > MAX_SIZE) throw new Error(t('the file is larger than 100 MB'));
          last = await importOne(plugin, f.name, new Uint8Array(await f.arrayBuffer()), folder);
        } catch (e) {
          plugin.errorLog.record(`import Word report ${f.name}`, e);
          new Notice(t('Importing {name} failed: {error}', { name: f.name, error: message(e) }), 10000);
        }
      }
      if (last) await plugin.app.workspace.getLeaf(false).openFile(last);
    } finally {
      running = false;
    }
  } catch (e) {
    plugin.errorLog.record('import Word report', e);
    new Notice(t('Importing failed: {error}', { error: message(e) }), 10000);
  }
}

/** Error texts of the converter are shown translated; anything else as it is. */
function message(e: unknown): string {
  const m = e instanceof Error ? e.message : String(e);
  return [NOT_WORD, TOO_LARGE, DAMAGED].includes(m) ? t(m) : m;
}

/**
 * The templates folder as it is in the vault (Windows ignores case: "sjablonen" on disk is the setting's "Sjablonen").
 * When it holds no templates yet, "New report" was offering the built-in ones: those are copied in first, so the
 * imported template is added to them instead of replacing them.
 */
async function templatesFolder(plugin: IctiReportsPlugin, folder: string): Promise<string> {
  const { resources } = plugin;
  await resources.ensureFolder(folder);
  const dir = resources.find(folder);
  if (!(dir instanceof TFolder)) throw new Error(t('{path} is a file, not a folder.', { path: folder }));
  let own = false;
  Vault.recurseChildren(dir, (f) => {
    if (f instanceof TFile && f.extension === 'md') own = true;
  });
  if (!own) {
    const copied = await resources.copyStarterTemplates(dir.path);
    if (copied) new Notice(t('The built-in report templates were put in {path} first, so they stay available next to the imported ones.', { path: dir.path }), 10000);
  }
  return dir.path;
}

async function importOne(plugin: IctiReportsPlugin, fileName: string, data: Uint8Array, folder: string): Promise<TFile> {
  const { app, resources } = plugin;
  if (!/\.docx$/i.test(fileName)) throw new Error(t('only .docx files can be imported (save older .doc files as .docx in Word first)'));
  const doc = await convertDocx(data);
  if (!doc.body.trim()) throw new Error(t('no text found after the cover and table of contents'));
  const base = templateBaseName(fileName);
  const notePath = await freePath(app, `${folder}/${base}`, 'md');
  const created: TAbstractFile[] = [];
  try {
    // Pictures: in a subfolder, with names that are unique in the vault (the template links them by name).
    const names = new Map<number, string>();
    if (doc.images.size) {
      const imgFolderName = normalizePath(`${folder}/${uiLanguage() === 'nl' ? 'Afbeeldingen' : 'Images'}`);
      await resources.ensureFolder(imgFolderName);
      const imgFolder = resources.find(imgFolderName)?.path ?? imgFolderName;
      const taken = new Set(app.vault.getFiles().map((f) => f.name.toLowerCase()));
      const noteBase = notePath.slice(folder.length + 1, -3);
      for (const [n, img] of doc.images) {
        let name = `${noteBase} ${n}.${img.ext}`;
        for (let i = 2; taken.has(name.toLowerCase()) || (await app.vault.adapter.exists(normalizePath(`${imgFolder}/${name}`))); i++) name = `${noteBase} ${n}-${i}.${img.ext}`;
        taken.add(name.toLowerCase());
        created.push(await app.vault.createBinary(normalizePath(`${imgFolder}/${name}`), img.data.slice().buffer));
        names.set(n, name);
      }
    }
    const note = await app.vault.create(notePath, templateNote({ title: doc.title, subtitle: doc.subtitle, language: doc.language, body: fillImages(doc.body, names) }));
    const left = doc.left.map((l) => (l === 'cover' ? t('cover page') : l));
    const lost = doc.warnings.map((w) => ({ chart: t('charts'), smartart: t('SmartArt diagrams'), equation: t('equations'), image: t('pictures in a format the report cannot show') })[w] ?? w);
    let text = t('{name} imported as report template "{template}".', { name: fileName, template: note.basename });
    if (left.length) text += ' ' + t('Left out (the plugin makes these itself): {parts}.', { parts: left.join(', ') });
    if (lost.length) text += ' ' + t('Not imported: {parts}.', { parts: lost.join(', ') });
    new Notice(text, 15000);
    return note;
  } catch (e) {
    // No half imports: the pictures of a template that could not be saved are removed again.
    for (const f of created) await app.vault.delete(f).catch(() => {});
    throw e;
  }
}

/** The first free "name.ext", "name 2.ext", … (case-insensitive, also checking the disk, which may lag the index). */
async function freePath(app: App, base: string, ext: string): Promise<string> {
  for (let i = 1; ; i++) {
    const path = normalizePath(`${base}${i > 1 ? ` ${i}` : ''}.${ext}`);
    const lower = path.toLowerCase();
    const inIndex = app.vault.getAllLoadedFiles().some((f) => f.path.toLowerCase() === lower);
    if (!inIndex && !(await app.vault.adapter.exists(path))) return path;
  }
}
