// Errors of this plugin, written to errors.log in the plugin folder. Obsidian only shows plugin errors in its
// developer console, which users rarely open; with this file a problem can be reported and found afterwards.
import { normalizePath, type Plugin } from 'obsidian';

const MAX_SIZE = 200_000;
const WRITE_DELAY = 5000;
/** Stack frames of this plugin's code contain "plugin:icti-reports". */
const OURS = /plugin:icti-reports|icti-reports[\\/]main\.js/;

export class ErrorLog {
  private path: string;
  private buffer: string[] = [];
  private seen = new Map<string, number>();
  private timer: number | undefined;
  private writing: Promise<void> = Promise.resolve();

  constructor(private plugin: Plugin, pluginDir: string) {
    this.path = normalizePath(`${pluginDir}/errors.log`);
  }

  /** Catches uncaught errors and unhandled promise rejections from this plugin's code, in every window. */
  start(): void {
    this.listen(window);
    this.plugin.registerEvent(this.plugin.app.workspace.on('window-open', (w) => this.listen(w.win)));
    this.plugin.register(() => this.flush());
  }

  private listen(win: Window): void {
    this.plugin.registerDomEvent(win, 'error', (e: ErrorEvent) => {
      const stack = e.error instanceof Error ? e.error.stack ?? String(e.error) : `${e.message} (${e.filename}:${e.lineno})`;
      if (OURS.test(stack) || OURS.test(e.filename ?? '')) this.record('error', stack);
    });
    this.plugin.registerDomEvent(win, 'unhandledrejection', (e: PromiseRejectionEvent) => {
      const r: unknown = e.reason;
      const stack = r instanceof Error ? r.stack ?? String(r) : String(r);
      if (OURS.test(stack)) this.record('unhandled promise', stack);
    });
  }

  /** Adds an entry. The same error again is only counted; entries are written together at most every 5 seconds. */
  record(where: string, detail: unknown): void {
    const text = detail instanceof Error ? detail.stack ?? String(detail) : String(detail);
    console.error(`ICT Reports – ${where}`, detail);
    const key = `${where}\n${text}`;
    const count = (this.seen.get(key) ?? 0) + 1;
    this.seen.set(key, count);
    if (count > 1 && count !== 10 && count !== 100) return; // repeats: noted at 10 and 100 times only
    this.buffer.push(`[${new Date().toISOString()}] ${where}${count > 1 ? ` (${count} times)` : ''}\n${text}\n\n`);
    if (this.timer === undefined) this.timer = window.setTimeout(() => this.flush(), WRITE_DELAY);
  }

  private flush(): void {
    window.clearTimeout(this.timer);
    this.timer = undefined;
    if (!this.buffer.length) return;
    const add = this.buffer.splice(0).join('');
    const adapter = this.plugin.app.vault.adapter;
    this.writing = this.writing.then(async () => {
      const exists = await adapter.exists(this.path);
      const size = exists ? (await adapter.stat(this.path))?.size ?? 0 : 0;
      if (size + add.length > MAX_SIZE) {
        const old = exists ? await adapter.read(this.path) : '';
        await adapter.write(this.path, (old + add).slice(-MAX_SIZE / 2));
      } else if (exists) await adapter.append(this.path, add);
      else await adapter.write(this.path, add);
    }).catch(() => {});
  }
}
