// Open note tabs. Obsidian loads background tabs only when they are shown ("deferred" tabs): until then
// getLeavesOfType('markdown') returns them with a placeholder view that has no editor, file or contentEl.
// Always go through these helpers instead of casting leaf.view to MarkdownView.
import { MarkdownView, type App, type WorkspaceLeaf } from 'obsidian';

/** Every loaded note view (deferred tabs are skipped; they are handled when Obsidian loads them). */
export function markdownViews(app: App): MarkdownView[] {
  return app.workspace.getLeavesOfType('markdown').map((l) => l.view).filter((v): v is MarkdownView => v instanceof MarkdownView);
}

/** The view of a leaf if it is a loaded note view. */
export function markdownView(leaf: WorkspaceLeaf | null | undefined): MarkdownView | null {
  return leaf?.view instanceof MarkdownView ? leaf.view : null;
}
