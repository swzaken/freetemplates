// The ICT Institute panel: the main actions, at the top of the left sidebar above the file list.
// It is an ordinary sidebar pane, so Obsidian keeps its place and size; the separate icon bar can be hidden.
import { ItemView, Notice, setIcon, type WorkspaceLeaf } from 'obsidian';
import { t } from '../i18n';
import { newReport } from './newReport';
import { importWordReports } from './importWord';
import type IctiReportsPlugin from '../main';

export const MENU_VIEW = 'icti-menu';

/** Is a sister plugin turned on in this vault? (Its main action then gets a place here.) */
function enabled(plugin: IctiReportsPlugin, id: 'icti-presentations' | 'icti-templates'): boolean {
  return !!(plugin.app as unknown as { plugins?: { enabledPlugins?: Set<string> } }).plugins?.enabledPlugins?.has(id);
}

/** Obsidian's command registry is not in the public typings; used only to open the quick switcher and palette. */
function runCommand(plugin: IctiReportsPlugin, id: string): boolean {
  return !!(plugin.app as unknown as { commands?: { executeCommandById(id: string): boolean } }).commands?.executeCommandById(id);
}

/** "Nieuw templatepakket" of ICT Institute Templates; a message when that plugin was turned off meanwhile. */
function newTemplatePackage(plugin: IctiReportsPlugin): void {
  if (!runCommand(plugin, 'icti-templates:new-package')) new Notice(t('Turn on the plugin ICT Institute Templates to make template packages.'));
}

/** "Nieuwe presentatie" of ICT Institute Presentations; a message when that plugin was turned off meanwhile. */
function newPresentation(plugin: IctiReportsPlugin): void {
  if (!runCommand(plugin, 'icti-presentations:new-presentation')) new Notice(t('Turn on the plugin ICT Institute Presentations to make presentations.'));
}

export class MenuView extends ItemView {
  constructor(leaf: WorkspaceLeaf, private plugin: IctiReportsPlugin) {
    super(leaf);
  }

  getViewType(): string {
    return MENU_VIEW;
  }

  getDisplayText(): string {
    return 'ICT Institute';
  }

  getIcon(): string {
    return 'layout-list';
  }

  async onOpen(): Promise<void> {
    const p = this.plugin;
    const root = this.contentEl;
    root.empty();
    root.addClass('icti-menu');

    const items: [string, string, () => unknown][] = [
      ['file-plus', t('New report'), () => newReport(p)],
      ['file-input', t('Import Word report'), () => importWordReports(p)],
      ...(enabled(p, 'icti-presentations') ? [['presentation', t('New presentation'), () => newPresentation(p)] as [string, string, () => unknown]] : []),
      ...(enabled(p, 'icti-templates') ? [['package', t('New template package'), () => newTemplatePackage(p)] as [string, string, () => unknown]] : []),
      ['file-text', t('Open report preview'), () => p.openPreview()],
      // Export and cover image are buttons above the preview.
      ['search', t('Search'), () => runCommand(p, 'switcher:open')],
      ['terminal-square', t('Command palette'), () => runCommand(p, 'command-palette:open')],
    ];
    const list = root.createDiv({ cls: 'icti-menu-items' });
    for (const [icon, label, action] of items) {
      const row = list.createDiv({ cls: 'icti-menu-item', attr: { role: 'button', tabindex: '0' } });
      setIcon(row.createSpan({ cls: 'icti-menu-icon' }), icon);
      row.createSpan({ cls: 'icti-menu-label', text: label });
      row.addEventListener('click', () => void action());
      row.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          void action();
        }
      });
    }
    this.zoomRow(list);
  }

  /** Zoom out / zoom of the open note (click: back to 100%) / zoom in. Only the open note changes size. */
  private zoomRow(list: HTMLElement): void {
    const zoom = this.plugin.noteZoom;
    const row = list.createDiv({ cls: 'icti-menu-item icti-menu-zoom' });
    setIcon(row.createSpan({ cls: 'icti-menu-icon' }), 'zoom-in');
    row.createSpan({ cls: 'icti-menu-label', text: t('Zoom note') });
    const controls = row.createDiv({ cls: 'icti-zoom-controls' });
    const button = (cls: string, label: string, direction: -1 | 0 | 1, icon?: string) => {
      const b = controls.createEl('button', { cls: `icti-zoom-button ${cls}`, attr: { 'aria-label': label } });
      if (icon) setIcon(b, icon);
      b.addEventListener('click', () => void zoom.change(direction));
      return b;
    };
    const out = button('', t('Zoom out'), -1, 'minus');
    const reset = button('icti-zoom-value', t('Reset zoom'), 0);
    const zin = button('', t('Zoom in'), 1, 'plus');
    const update = () => {
      const file = zoom.target();
      reset.setText(file ? `${zoom.level(file)}%` : '–');
      row.setAttr('title', file ? file.basename : t('Open a note to zoom it.'));
      for (const b of [out, reset, zin]) b.disabled = !file;
    };
    update();
    this.register(zoom.onChange(update));
  }
}

/**
 * Puts the panel in the left sidebar, directly above the file explorer (or reveals it if it is open).
 * `first` = the automatic placement on first start: it also hides Obsidian's separate icon bar.
 */
export async function showMenu(plugin: IctiReportsPlugin, first = false): Promise<void> {
  const { workspace } = plugin.app;
  const existing = workspace.getLeavesOfType(MENU_VIEW)[0];
  if (existing) {
    await workspace.revealLeaf(existing);
    return;
  }
  const explorer = workspace.getLeavesOfType('file-explorer')[0];
  const leaf = explorer ? workspace.createLeafBySplit(explorer, 'horizontal', true) : workspace.getLeftLeaf(false);
  if (!leaf) return;
  await leaf.setViewState({ type: MENU_VIEW, active: false });
  // Give the panel just the room it needs; the user can drag the divider (internal API, so guarded).
  (leaf.parent as unknown as { setDimension?: (n: number) => void })?.setDimension?.(32);
  (explorer?.parent as unknown as { setDimension?: (n: number) => void })?.setDimension?.(68);
  if (first) {
    // One column: the panel replaces the icon bar. Settings → Appearance → Show ribbon brings it back.
    (plugin.app.vault as unknown as { setConfig?: (key: string, value: unknown) => void }).setConfig?.('showRibbon', false);
  }
}
