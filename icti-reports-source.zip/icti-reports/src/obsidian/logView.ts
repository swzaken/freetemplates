// The change log window of a note: a table with when, who and what, newest first.
import { Modal, type TFile } from 'obsidian';
import type { ChangeDetails, LogEntry } from '../data/changes';
import { t, uiLanguage } from '../i18n';
import type IctiReportsPlugin from '../main';
import { AuthorModal } from './changeLog';

function when(iso: string): string {
  const d = new Date(iso);
  return d.toLocaleString(uiLanguage() === 'nl' ? 'nl-NL' : 'en-GB', { dateStyle: 'medium', timeStyle: 'short' });
}

/** "Edited: Inleiding, Conclusie · properties: title · +120 / −15 characters" */
export function describe(e: LogEntry): string {
  if (e.kind === 'created') return e.author ? t('Created') : t('Created (date of the file; made before the change log existed)');
  if (e.kind === 'renamed') return t('Renamed from "{from}" to "{to}"', { from: e.from ?? '', to: e.to ?? '' });
  if (e.kind === 'exported') return t('Exported to PDF: {path}', { path: e.to ?? '' });
  const parts: string[] = [];
  const chapters = (e.chapters ?? []).map((c) => c || t('(text before the first heading)'));
  if (chapters.length) parts.push(t('Chapters: {list}', { list: chapters.join(', ') }));
  if (e.properties?.length) parts.push(t('Properties: {list}', { list: e.properties.join(', ') }));
  if (e.added || e.removed) parts.push(t('+{added} / −{removed} characters', { added: e.added ?? 0, removed: e.removed ?? 0 }));
  return `${t('Edited')}${parts.length ? ` – ${parts.join(' · ')}` : ''}`;
}

/** Exactly what changed: old and new property values, then the removed (red) and added (green) lines per chapter. */
function showDetails(parent: HTMLElement, d: ChangeDetails): void {
  const box = parent.createEl('details', { cls: 'icti-log-details', attr: { open: '' } });
  box.createEl('summary', { text: t('Details') });
  for (const p of d.properties) {
    const line = box.createDiv({ cls: 'icti-log-prop' });
    line.createSpan({ cls: 'icti-log-prop-name', text: `${p.name}: ` });
    if (!p.before) line.createSpan({ cls: 'icti-log-add', text: `${p.after} ${t('(added)')}` });
    else if (!p.after) line.createSpan({ cls: 'icti-log-del', text: `${p.before} ${t('(removed)')}` });
    else {
      line.createSpan({ cls: 'icti-log-del', text: p.before });
      line.createSpan({ text: ' → ' });
      line.createSpan({ cls: 'icti-log-add', text: p.after });
    }
  }
  let chapter: string | null = null;
  for (const h of d.text) {
    if (h.chapter !== chapter) {
      chapter = h.chapter;
      box.createDiv({ cls: 'icti-log-chapter', text: chapter || t('(text before the first heading)') });
    }
    const block = box.createDiv({ cls: 'icti-log-lines' });
    for (const l of h.removed) block.createDiv({ cls: 'icti-log-del', text: `− ${l}` });
    for (const l of h.added) block.createDiv({ cls: 'icti-log-add', text: `+ ${l}` });
  }
  if (d.truncated) box.createDiv({ cls: 'setting-item-description', text: t('More changes were made than are shown here.') });
}

export class LogModal extends Modal {
  constructor(private plugin: IctiReportsPlugin, private file: TFile) {
    super(plugin.app);
  }

  async onOpen(): Promise<void> {
    this.modalEl.addClass('icti-log-modal');
    this.titleEl.setText(t('Change log: {note}', { note: this.file.basename }));
    const log = this.plugin.changeLog;
    if (!log.author()) {
      const row = this.contentEl.createDiv({ cls: 'icti-log-bar' });
      row.createSpan({ cls: 'setting-item-description', text: t('Your name is not set yet, so your changes are logged as "Unknown".') });
      row.createEl('button', { text: t('Set name'), cls: 'mod-cta' }).addEventListener('click', () => {
        new AuthorModal(this.app, '', (n) => {
          log.setAuthor(n);
          row.remove();
        }).open();
      });
    }
    let entries: LogEntry[];
    try {
      entries = (await log.entries(this.file)).reverse();
    } catch (e) {
      this.plugin.errorLog.record('change log window', e);
      this.contentEl.createEl('p', { text: t('The change log could not be read: {error}', { error: e instanceof Error ? e.message : String(e) }) });
      return;
    }
    const table = this.contentEl.createEl('table', { cls: 'icti-log-table' });
    const head = table.createEl('thead').createEl('tr');
    for (const h of [t('Date and time'), t('Who'), t('What')]) head.createEl('th', { text: h });
    const body = table.createEl('tbody');
    for (const e of entries) {
      const row = body.createEl('tr');
      const sameDay = e.end && new Date(e.end).toDateString() === new Date(e.time).toDateString();
      const endTime = e.end ? new Date(e.end).toLocaleTimeString(uiLanguage() === 'nl' ? 'nl-NL' : 'en-GB', { hour: '2-digit', minute: '2-digit' }) : '';
      const time = !e.end || when(e.end) === when(e.time) ? when(e.time) : `${when(e.time)} – ${sameDay ? endTime : when(e.end)}`;
      row.createEl('td', { text: time, cls: 'icti-log-time' });
      row.createEl('td', { text: e.author || '–' });
      const what = row.createEl('td');
      what.createDiv({ text: describe(e) });
      if (e.details && (e.details.properties.length || e.details.text.length)) showDetails(what, e.details);
    }
    this.contentEl.createEl('p', {
      cls: 'setting-item-description',
      text: t('Edits by the same person within 15 minutes are combined into one line. The log is kept in the hidden folder .logboek of the vault.'),
    });
  }
}
