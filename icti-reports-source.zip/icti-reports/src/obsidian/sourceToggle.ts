// A small slider in the header of every note: on = the Markdown code itself, like in Notepad++ (Obsidian's Source
// mode, in a monospace font); off = the note as it normally shows (Live Preview). It follows the note: switching
// with Obsidian's own command moves the slider too.
import { ToggleComponent, type MarkdownView } from 'obsidian';
import { markdownViews } from './views';
import type IctiReportsPlugin from '../main';
import { t } from '../i18n';

const CLS = 'icti-source-toggle';
const RAW = 'icti-raw-markdown';

/** Is the view showing the Markdown code (Source mode, not Live Preview or Reading view)? */
function isRaw(view: MarkdownView): boolean {
  const state = view.getState() as { mode?: string; source?: boolean };
  return state.mode === 'source' && state.source === true;
}

export class SourceToggle {
  private toggles = new Map<MarkdownView, { el: HTMLElement; toggle: ToggleComponent }>();

  constructor(private plugin: IctiReportsPlugin) {}

  start(): void {
    const { workspace } = this.plugin.app;
    const refresh = () => {
      try {
        this.refresh();
      } catch (e) {
        this.plugin.errorLog.record('updating the Markdown slider', e);
      }
    };
    workspace.onLayoutReady(refresh);
    this.plugin.registerEvent(workspace.on('layout-change', refresh));
    this.plugin.registerEvent(workspace.on('active-leaf-change', refresh));
    this.plugin.registerEvent(workspace.on('file-open', refresh));
    this.plugin.register(() => {
      for (const [view, { el }] of this.toggles) {
        el.remove();
        view.containerEl.removeClass(RAW);
      }
      this.toggles.clear();
    });
  }

  /** Adds the slider to notes that have none, and moves every slider to its note's current view. */
  private refresh(): void {
    const views = markdownViews(this.plugin.app);
    for (const [view, { el }] of this.toggles) {
      if (!views.includes(view) || !el.isConnected) {
        el.remove();
        this.toggles.delete(view);
      }
    }
    for (const view of views) {
      let entry = this.toggles.get(view);
      if (!entry) {
        const actions = view.containerEl.querySelector('.view-header .view-actions');
        if (!actions) continue;
        const el = createDiv({ cls: CLS, attr: { 'aria-label': t('Show the Markdown code (like Notepad++) or the formatted note') } });
        el.createSpan({ cls: `${CLS}-label`, text: t('Markdown') });
        const toggle = new ToggleComponent(el);
        toggle.onChange((on) => void this.switchTo(view, on));
        actions.prepend(el);
        entry = { el, toggle };
        this.toggles.set(view, entry);
      }
      const raw = isRaw(view);
      if (entry.toggle.getValue() !== raw) entry.toggle.setValue(raw);
      view.containerEl.toggleClass(RAW, raw);
    }
  }

  private async switchTo(view: MarkdownView, raw: boolean): Promise<void> {
    if (isRaw(view) === raw) return;
    try {
      const state = view.leaf.getViewState();
      await view.leaf.setViewState({ ...state, state: { ...state.state, mode: 'source', source: raw } });
      view.containerEl.toggleClass(RAW, raw);
    } catch (e) {
      this.plugin.errorLog.record('switching between Markdown and the formatted note', e);
    }
  }
}
