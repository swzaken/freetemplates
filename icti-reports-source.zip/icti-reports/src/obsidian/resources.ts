// Everything read from disk inside Obsidian: the engine and fonts (plugin folder), the layout and its
// artwork (vault folder from the settings, falling back to the copies bundled with the plugin), and the
// images of a report. All access goes through Obsidian's vault API.
import { normalizePath, parseYaml, TFile, TFolder, Vault, type App, type TAbstractFile } from 'obsidian';
import { isVaultPath, joinInVault, type Host } from '../pipeline';
import { t } from '../i18n';

export const LAYOUT_ASSETS = ['header-logo.png', 'cover-default.png'];
const TEMPLATES_PREFIX = 'ICT Rapporten/Sjablonen/';
/** Layouts older than this cannot read the simple report's data (no cover block yet): the built-in one is used. */
export const MIN_LAYOUT_VERSION = 16;

export interface StarterFolders {
  layoutPath: string;
  templatesFolder: string;
}

const parentOf = (path: string) => (path.includes('/') ? path.slice(0, path.lastIndexOf('/')) : '');

export interface Layout {
  source: string;
  /** Shown in error messages: the vault path, or "(built-in)". */
  name: string;
  /** Artwork mapped into Typst as /assets/<file>. */
  assets: Record<string, Uint8Array>;
  /** The vault layout is older than the plugin's built-in layout ("Update layout" brings it up to date). */
  outdated: boolean;
  /** The vault layout was too old to use at all, so the built-in layout was used instead. */
  replaced: boolean;
}

/** The number in the "// layout-version: N" line of a layout; 0 for layouts from before that line existed. */
export function layoutVersion(source: string): number {
  const m = /^\/\/\s*layout-version:\s*(\d+)/m.exec(source.slice(0, 2000));
  return m ? Number(m[1]) : 0;
}

export class Resources {
  constructor(private app: App, readonly pluginDir: string) {}

  private async pluginBinary(rel: string): Promise<ArrayBuffer> {
    return this.app.vault.adapter.readBinary(normalizePath(`${this.pluginDir}/${rel}`));
  }

  async engineFiles(): Promise<{ wasm: ArrayBuffer; fonts: ArrayBuffer[] }> {
    const fontDir = normalizePath(`${this.pluginDir}/fonts`);
    const listing = await this.app.vault.adapter.list(fontDir);
    const fontFiles = listing.files.filter((f) => /\.(ttf|otf)$/i.test(f));
    if (!fontFiles.length) throw new Error(t('No fonts found in {path}.', { path: fontDir }));
    const [wasm, ...fonts] = await Promise.all([
      this.pluginBinary('typst.wasm'),
      ...fontFiles.map((f) => this.app.vault.adapter.readBinary(f)),
    ]);
    return { wasm, fonts };
  }

  /** The vault layout if it exists, else the built-in one. Artwork next to the vault layout wins too. */
  async layout(vaultPath: string): Promise<Layout> {
    const path = normalizePath(vaultPath || '');
    const file = path ? this.find(path) : null;
    const builtIn = new TextDecoder().decode(await this.pluginBinary('layout/report.typ'));
    const own = file instanceof TFile ? await this.app.vault.read(file) : null;
    const replaced = own !== null && layoutVersion(own) < MIN_LAYOUT_VERSION;
    const inVault = own !== null && !replaced && file instanceof TFile;
    const source = inVault ? own : builtIn;
    const assetDir = inVault ? normalizePath(`${file.parent?.path ?? ''}/assets`) : '';
    const assets: Record<string, Uint8Array> = {};
    for (const name of LAYOUT_ASSETS) {
      const own = assetDir ? this.app.vault.getAbstractFileByPath(normalizePath(`${assetDir}/${name}`)) : null;
      const bytes = own instanceof TFile ? await this.app.vault.readBinary(own) : await this.pluginBinary(`assets/${name}`);
      assets[`/assets/${name}`] = new Uint8Array(bytes);
    }
    return { source, name: inVault || replaced ? path : '(built-in)', assets, outdated: replaced || (inVault && layoutVersion(source) < layoutVersion(builtIn)), replaced };
  }

  /**
   * Copies the starter files into the vault without overwriting anything: the layout and its artwork, and the
   * report templates.
   */
  async installStarter(folders: StarterFolders): Promise<string[]> {
    for (const p of [folders.layoutPath, folders.templatesFolder]) {
      if (!isVaultPath(p)) throw new Error(t('"{path}" must be a path inside the vault (no "..", no drive letter).', { path: p }));
    }
    const layout = normalizePath(folders.layoutPath);
    const layoutDir = parentOf(layout);
    const join = (dir: string, rel: string) => normalizePath(dir ? `${dir}/${rel}` : rel);
    const plan: [string, string][] = [[layout, 'layout/report.typ']];
    for (const name of LAYOUT_ASSETS) plan.push([join(layoutDir, `assets/${name}`), `assets/${name}`]);
    for (const rel of await this.starterList()) {
      if (rel.startsWith(TEMPLATES_PREFIX)) plan.push([join(folders.templatesFolder, rel.slice(TEMPLATES_PREFIX.length)), `starter/${rel}`]);
    }
    const created: string[] = [];
    for (const [target, source] of plan) {
      if (this.find(target)) continue;
      await this.ensureFolder(parentOf(target));
      await this.app.vault.createBinary(target, await this.pluginBinary(source));
      created.push(target);
    }
    return created;
  }

  /**
   * Replaces the vault's copy of the layout with the plugin's built-in layout (after a plugin update).
   * The old file is kept next to it (report.typ.bak; an existing backup is never overwritten).
   * Returns the backup path, 'artwork' when only the artwork changed, 'current' when everything is already the built-in
   * version, or null when the vault has no layout.
   */
  async updateLayout(layoutPath: string): Promise<string | 'current' | 'artwork' | null> {
    if (!isVaultPath(layoutPath)) throw new Error(t('"{path}" must be a path inside the vault (no "..", no drive letter).', { path: layoutPath }));
    const file = this.find(normalizePath(layoutPath));
    if (!(file instanceof TFile)) return null;
    const builtIn = new TextDecoder().decode(await this.pluginBinary('layout/report.typ'));
    const old = await this.app.vault.read(file);
    const adapter = this.app.vault.adapter;
    // The artwork next to the layout belongs to it: copies in the vault that differ from the plugin's are replaced too,
    // each kept as <name>.bak.
    let artwork = false;
    for (const name of LAYOUT_ASSETS) {
      const own = this.app.vault.getAbstractFileByPath(normalizePath(`${file.parent?.path ?? ''}/assets/${name}`));
      if (!(own instanceof TFile)) continue; // missing: the plugin's own copy is used anyway
      const mine = new Uint8Array(await this.app.vault.readBinary(own));
      const theirs = new Uint8Array(await this.pluginBinary(`assets/${name}`));
      if (mine.length === theirs.length && mine.every((b, i) => b === theirs[i])) continue;
      let bak = `${own.path}.bak`;
      for (let i = 2; await adapter.exists(bak); i++) bak = `${own.path}.${i}.bak`;
      await adapter.writeBinary(bak, mine.slice().buffer as ArrayBuffer);
      await this.app.vault.modifyBinary(own, theirs.slice().buffer as ArrayBuffer);
      artwork = true;
    }
    if (old.replace(/\r\n/g, '\n') === builtIn.replace(/\r\n/g, '\n')) return artwork ? 'artwork' : 'current';
    let backup = `${file.path}.bak`;
    for (let i = 2; await adapter.exists(backup); i++) backup = `${file.path}.${i}.bak`;
    await adapter.write(backup, old);
    await this.app.vault.modify(file, builtIn);
    return backup;
  }

  /**
   * The standard cover picture as a file in the vault (`assets/cover-default.png` next to the layout), so a note can
   * show which picture its cover uses. Copied there from the plugin when the vault has none yet.
   */
  async standardCoverImage(layoutPath: string): Promise<TFile> {
    const layout = normalizePath(isVaultPath(layoutPath) && layoutPath.trim() ? layoutPath : 'ICT Rapporten/Opmaak/report.typ');
    const dir = parentOf(layout);
    const path = normalizePath(`${dir ? `${dir}/` : ''}assets/cover-default.png`);
    const existing = this.find(path);
    if (existing instanceof TFile) return existing;
    await this.ensureFolder(parentOf(path));
    return this.app.vault.createBinary(path, await this.pluginBinary('assets/cover-default.png'));
  }

  /** Copies the built-in report templates into the folder (nothing overwritten); returns how many were copied. */
  async copyStarterTemplates(folder: string): Promise<number> {
    let copied = 0;
    for (const rel of await this.starterList()) {
      if (!rel.startsWith(TEMPLATES_PREFIX)) continue;
      const target = normalizePath(`${folder}/${rel.slice(TEMPLATES_PREFIX.length)}`);
      if (this.find(target)) continue;
      await this.ensureFolder(parentOf(target));
      await this.app.vault.createBinary(target, await this.pluginBinary(`starter/${rel}`));
      copied++;
    }
    return copied;
  }

  private async starterList(): Promise<string[]> {
    return JSON.parse(new TextDecoder().decode(await this.pluginBinary('starter/files.json'))) as string[];
  }

  /** Report templates: the notes in the templates folder, or the built-in ones when that folder is empty. */
  async templates(folder: string): Promise<{ name: string; read: () => Promise<string>; folder?: string }[]> {
    const dir = folder.trim() ? this.find(normalizePath(folder)) : null; // empty setting = built-in templates only
    const own: TFile[] = [];
    if (dir instanceof TFolder) Vault.recurseChildren(dir, (f) => {
      if (f instanceof TFile && f.extension === 'md') own.push(f);
    });
    if (own.length) return own.sort((a, b) => a.basename.localeCompare(b.basename)).map((f) => ({ name: f.basename, read: () => this.app.vault.read(f), folder: f.parent?.path ?? '' }));
    return (await this.starterList())
      .filter((rel) => rel.startsWith(TEMPLATES_PREFIX) && rel.endsWith('.md'))
      .map((rel) => ({
        name: rel.slice(TEMPLATES_PREFIX.length, -3).split('/').pop()!,
        read: async () => new TextDecoder().decode(await this.pluginBinary(`starter/${rel}`)),
      }));
  }

  /** Looks a path up like the (case-insensitive) Windows file system does. */
  find(path: string): TAbstractFile | null {
    const exact = this.app.vault.getAbstractFileByPath(path);
    if (exact) return exact;
    const lower = path.toLowerCase();
    return this.app.vault.getAllLoadedFiles().find((f) => f.path.toLowerCase() === lower) ?? null;
  }

  /** Creates the folder (and its parents) unless it exists; a file in the way is a clear error. */
  async ensureFolder(folder: string): Promise<void> {
    if (!folder) return;
    const existing = this.find(folder);
    if (existing instanceof TFolder) return;
    if (existing) throw new Error(t('{path} is a file, so it cannot be used as a folder.', { path: existing.path }));
    await this.app.vault.createFolder(folder);
  }

  /** Host callbacks for prepare(): the note's name and its images, resolved like Obsidian resolves links. */
  host(notePath: string): Host {
    const { metadataCache, vault } = this.app;
    const noteFolder = notePath.includes('/') ? notePath.slice(0, notePath.lastIndexOf('/')) : '';
    const noteName = notePath.split('/').pop()!.replace(/\.md$/i, '');
    return {
      parseYaml: (yaml) => parseYaml(yaml) ?? {},
      noteName,
      readImage: async (ref) => {
        // A path relative to the note first (![](img/a.png), ![](../img/a.png)), then Obsidian's own link
        // resolution (a name, or a path from the top of the vault). Nothing outside the vault is ever read.
        const joined = joinInVault(noteFolder, ref);
        const relative = joined ? vault.getAbstractFileByPath(normalizePath(joined)) : null;
        const f = relative instanceof TFile ? relative : ref.split(/[\\/]/).includes('..') ? null : metadataCache.getFirstLinkpathDest(ref, notePath);
        return f ? new Uint8Array(await vault.readBinary(f)) : null;
      },
    };
  }
}
