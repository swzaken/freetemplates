// "New report": pick a template (when there is more than one), the main folder (client projects or internal
// projects), a subfolder in it (an existing one, or type a name to make it), and the document name.
// The document name is the note's name and, through {note}, part of the PDF file name.
import { Modal, normalizePath, Notice, SuggestModal, TFile, TFolder, type App } from 'obsidian';
import { fillTemplate, noteFileName } from '../data/template';
import { findCoverBlock, markdownImagePath, rebaseCoverImage, withCoverImage } from '../data/coverText';
import { isVaultPath } from '../pipeline';
import type IctiReportsPlugin from '../main';
import { t } from '../i18n';

interface Template {
  name: string;
  read: () => Promise<string>;
  /** The template's folder in the vault (none for the built-in templates). */
  folder?: string;
}

/** Opens a SuggestModal and resolves with the chosen item, or null when it is dismissed. */
export function choose<T>(modal: SuggestModal<T>): Promise<T | null> {
  return new Promise((resolve) => {
    let chosen = false;
    modal.onChooseSuggestion = (item) => {
      chosen = true;
      resolve(item);
    };
    // Obsidian closes the modal before it reports the choice, so wait a tick before giving up.
    modal.onClose = () => window.setTimeout(() => !chosen && resolve(null), 0);
    modal.open();
  });
}

class TemplatePicker extends SuggestModal<Template> {
  constructor(app: App, private items: Template[]) {
    super(app);
    this.setPlaceholder(t('Report template'));
  }
  getSuggestions(q: string): Template[] {
    return this.items.filter((x) => x.name.toLowerCase().includes(q.toLowerCase()));
  }
  renderSuggestion(x: Template, el: HTMLElement): void {
    el.setText(x.name);
  }
  onChooseSuggestion(): void {}
}

interface MainFolder {
  label: string;
  path: string;
}

class MainFolderPicker extends SuggestModal<MainFolder> {
  constructor(app: App, private items: MainFolder[]) {
    super(app);
    this.setPlaceholder(t('Client project or internal project?'));
  }
  getSuggestions(q: string): MainFolder[] {
    return this.items.filter((x) => x.label.toLowerCase().includes(q.toLowerCase()));
  }
  renderSuggestion(x: MainFolder, el: HTMLElement): void {
    el.createDiv({ text: x.label });
    el.createEl('small', { text: x.path, cls: 'icti-suggestion-note' });
  }
  onChooseSuggestion(): void {}
}

export type FolderChoice = { kind: 'folder'; path: string; name: string } | { kind: 'create'; name: string } | { kind: 'here' };

export class SubfolderPicker extends SuggestModal<FolderChoice> {
  constructor(app: App, private main: string, private folders: string[]) {
    super(app);
    this.setPlaceholder(t('Folder in {main} (type a new name to create one; "ABC/Audit 2026" makes a folder inside a folder)', { main: main.split('/').pop() ?? main }));
  }
  getSuggestions(q: string): FolderChoice[] {
    const query = q.trim().toLowerCase();
    const prefix = this.main ? `${this.main}/` : '';
    const hits: FolderChoice[] = this.folders
      .filter((p) => p.slice(prefix.length).toLowerCase().includes(query))
      .map((p) => ({ kind: 'folder', path: p, name: p.split('/').pop()! }));
    const name = folderPath(q);
    if (query && name && !this.folders.some((p) => p.slice(prefix.length).toLowerCase() === name.toLowerCase())) hits.push({ kind: 'create', name });
    if (!query) hits.push({ kind: 'here' });
    return hits;
  }
  renderSuggestion(c: FolderChoice, el: HTMLElement): void {
    const prefix = this.main ? `${this.main}/` : '';
    el.setText(c.kind === 'folder' ? c.path.slice(prefix.length) : c.kind === 'create' ? t('Create folder "{name}"', { name: c.name }) : t('Directly in {main}', { main: this.main || '/' }));
  }
  onChooseSuggestion(): void {}
}

function askName(app: App, initial: string): Promise<string | null> {
  return new Promise((resolve) => {
    const modal = new Modal(app);
    let result: string | null = null;
    modal.titleEl.setText(t('Document name of the new report'));
    modal.contentEl.createEl('p', { text: t('This becomes the name of the note and of the PDF.'), cls: 'setting-item-description' });
    const input = modal.contentEl.createEl('input', { type: 'text', value: initial, cls: 'icti-name-input' });
    const submit = () => {
      result = noteFileName(input.value) || null;
      if (result) modal.close();
    };
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        submit();
      }
    });
    const buttons = modal.contentEl.createDiv({ cls: 'modal-button-container' });
    buttons.createEl('button', { text: t('Create'), cls: 'mod-cta' }).addEventListener('click', submit);
    buttons.createEl('button', { text: t('Cancel') }).addEventListener('click', () => modal.close());
    modal.onClose = () => resolve(result);
    modal.open();
    input.select();
  });
}

/** A new subfolder as typed: "ABC" or "ABC/Audit 2026" (each part made safe, empty parts dropped). */
export function folderPath(typed: string): string {
  return typed.split(/[\\/]/).map(noteFileName).filter(Boolean).join('/');
}

/** A path that does not exist yet: "name.md", else "name 2.md", "name 3.md", ... */
export function freePath(plugin: IctiReportsPlugin, folder: string, name: string): string {
  for (let i = 1; ; i++) {
    const path = normalizePath(`${folder ? `${folder}/` : ''}${name}${i > 1 ? ` ${i}` : ''}.md`);
    if (!plugin.resources.find(path)) return path;
  }
}

/** Every folder inside `main` (at any depth), sorted; empty when `main` does not exist yet. */
function subfolders(plugin: IctiReportsPlugin, main: string): string[] {
  const root = plugin.resources.find(normalizePath(main));
  const out: string[] = [];
  const walk = (f: TFolder) => {
    for (const c of f.children) {
      if (c instanceof TFolder) {
        out.push(c.path);
        walk(c);
      }
    }
  };
  if (root instanceof TFolder) walk(root);
  return out.sort((a, b) => a.localeCompare(b));
}

export async function newReport(plugin: IctiReportsPlugin): Promise<void> {
  const { app, settings, resources } = plugin;
  try {
    for (const p of [settings.templatesFolder, settings.clientProjectsFolder, settings.internalProjectsFolder]) {
      if (!isVaultPath(p)) throw new Error(t('The folder "{path}" in the settings must be inside the vault.', { path: p }));
    }
    const templates = await resources.templates(settings.templatesFolder);
    if (!templates.length) throw new Error(t('No report templates found in "{path}".', { path: settings.templatesFolder }));
    const template = templates.length === 1 ? templates[0] : await choose(new TemplatePicker(app, templates));
    if (!template) return;

    const main = await choose(new MainFolderPicker(app, [
      { label: t('Internal project'), path: normalizePath(settings.internalProjectsFolder || '/') },
      { label: t('Client project'), path: normalizePath(settings.clientProjectsFolder || '/') },
    ]));
    if (!main) return;
    const mainPath = main.path === '/' ? '' : main.path;
    const sub = await choose(new SubfolderPicker(app, mainPath, subfolders(plugin, mainPath)));
    if (!sub) return;
    const folder = sub.kind === 'folder' ? sub.path : sub.kind === 'create' ? normalizePath(`${mainPath ? `${mainPath}/` : ''}${sub.name}`) : mainPath;
    const folderName = sub.kind === 'here' ? '' : folder.split('/').pop() ?? '';

    const name = await askName(app, `${template.name} ${new Date().getFullYear()}`);
    if (!name) return;

    await resources.ensureFolder(folder);
    let text = fillTemplate(await template.read(), { type: template.name, folder: folderName, title: name, today: new Date() });
    // A picture in the template's cover with a path relative to the template: make it relative to the new report.
    if (template.folder !== undefined) text = rebaseCoverImage(text, template.folder === '/' ? '' : template.folder, folder, (p) => resources.find(p) instanceof TFile);
    // A cover without a picture uses the standard one: write it into the note, so the Markdown shows it.
    if (findCoverBlock(text.split(/\r?\n/))) {
      const standard = await resources.standardCoverImage(settings.layoutPath);
      text = withCoverImage(text, `> ![Cover](${markdownImagePath(folder, standard.path)})`);
    }
    const file = await app.vault.create(freePath(plugin, folder, name), text);
    await app.workspace.getLeaf(false).openFile(file);
    await plugin.openPreview();
    new Notice(t('Created {path}', { path: file.path }));
  } catch (e) {
    new Notice(t('New report failed: {error}', { error: e instanceof Error ? e.message : String(e) }), 10000);
  }
}
