// Opens a note (if needed) and puts the cursor on a line, in editing mode.
import { MarkdownView, type App, type TFile } from 'obsidian';

export async function revealLine(app: App, file: TFile, line: number): Promise<void> {
  const { workspace } = app;
  // Also a background tab that is not loaded yet: its view state still names the file.
  let leaf = workspace.getLeavesOfType('markdown').find((l) => l.view instanceof MarkdownView ? l.view.file?.path === file.path : l.getViewState().state?.file === file.path);
  if (!leaf) {
    // A new tab when the last active pane is not a note (for example the preview), so the preview is not replaced.
    leaf = workspace.getMostRecentLeaf()?.view instanceof MarkdownView ? workspace.getLeaf(false) : workspace.getLeaf('tab');
    await leaf.openFile(file);
  }
  await leaf.loadIfDeferred?.(); // Obsidian 1.7.2+
  workspace.setActiveLeaf(leaf, { focus: true });
  if (!(leaf.view instanceof MarkdownView)) return;
  if (leaf.view.getMode() !== 'source') await leaf.setViewState({ ...leaf.getViewState(), state: { ...leaf.getViewState().state, mode: 'source' } });
  if (!(leaf.view instanceof MarkdownView)) return;
  const editor = leaf.view.editor;
  const pos = { line: Math.min(Math.max(line, 1) - 1, editor.lastLine()), ch: 0 };
  editor.setCursor(pos);
  editor.scrollIntoView({ from: pos, to: pos }, true);
}
