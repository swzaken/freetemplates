// The page header is a `> [!header]` block; "Header" adds or removes it.
// The cover page is a `> [!cover]` block in the note itself. "Cover page" adds or removes that block; "Cover image"
// picks a picture (from the vault, or from this computer) and writes it into the block as an ordinary Markdown image,
// `![Cover](../Images/logo.png)`, so the note stays readable and editable without Obsidian.
import { Notice, SuggestModal, TFile, type App } from 'obsidian';
import { imageFormat } from '../pipeline';
import { formatDate } from '../data/labels';
import { findBlock, findCoverBlock, markdownImagePath, withCoverImage } from '../data/coverText';
import { markdownViews } from './views';
import type IctiReportsPlugin from '../main';
import { t } from '../i18n';

const IMAGE = /^(png|jpe?g|gif|webp|svg)$/i;

type Choice = { kind: 'file'; file: TFile } | { kind: 'upload' } | { kind: 'standard' };

class ImagePicker extends SuggestModal<Choice> {
  constructor(app: App, private images: TFile[], private done: (c: Choice) => void) {
    super(app);
    this.setPlaceholder(t('Cover image: type to search the images in your vault'));
  }

  getSuggestions(q: string): Choice[] {
    const query = q.trim().toLowerCase();
    const files: Choice[] = this.images.filter((f) => f.path.toLowerCase().includes(query)).slice(0, 50).map((file) => ({ kind: 'file', file }));
    const extra: Choice[] = [{ kind: 'upload' }, { kind: 'standard' }];
    return query ? [...files, ...extra] : [...extra, ...files];
  }

  renderSuggestion(c: Choice, el: HTMLElement): void {
    el.addClass('icti-cover-choice');
    if (c.kind === 'file') {
      el.createEl('img', { cls: 'icti-cover-thumb', attr: { src: this.app.vault.getResourcePath(c.file), alt: '' } });
      el.createSpan({ text: c.file.path });
    } else {
      el.createSpan({ text: c.kind === 'upload' ? t('Choose an image from this computer…') : t('Use the standard picture') });
    }
  }

  onChooseSuggestion(c: Choice): void {
    this.done(c);
  }
}

/** Lets the user pick an image file from disk; resolves with its name and bytes, or null (also when reading fails). */
function pickFromComputer(): Promise<{ name: string; data: ArrayBuffer } | null> {
  return new Promise((resolve) => {
    const input = activeDocument.createElement('input');
    input.type = 'file';
    input.accept = '.png,.jpg,.jpeg,.gif,.webp,.svg';
    input.addEventListener('change', () => {
      const f = input.files?.[0];
      if (!f) return resolve(null);
      f.arrayBuffer().then((data) => resolve({ name: f.name, data }), () => {
        new Notice(t('{name} could not be read.', { name: f.name }));
        resolve(null);
      });
    });
    input.addEventListener('cancel', () => resolve(null));
    input.click();
  });
}

/**
 * Changes the note's text. When the note is open in an editor, only the changed part is replaced there, so
 * Ctrl+Z undoes it and unsaved typing is kept; otherwise the file is changed directly.
 */
async function changeText(plugin: IctiReportsPlugin, file: TFile, change: (text: string) => string): Promise<void> {
  const view = markdownViews(plugin.app).find((v) => v.file?.path === file.path);
  if (!view) {
    await plugin.app.vault.process(file, change);
    return;
  }
  const editor = view.editor;
  const old = editor.getValue();
  const next = change(old);
  if (next === old) return;
  let start = 0;
  while (start < old.length && start < next.length && old[start] === next[start]) start++;
  let end = 0;
  while (end < old.length - start && end < next.length - start && old[old.length - 1 - end] === next[next.length - 1 - end]) end++;
  editor.replaceRange(next.slice(start, next.length - end), editor.offsetToPos(start), editor.offsetToPos(old.length - end));
}

/** The lines of a new cover block: the picture, the note's name as the title and today's date. */
function newCoverLines(file: TFile, text: string, imageLine: string): string[] {
  const nl = /^---\r?\n[\s\S]*?^language:\s*["']?nl\b[\s\S]*?^---/m.test(text);
  return ['> [!cover]', imageLine, `> # ${file.basename}`, `> ${formatDate(new Date(), nl ? 'nl' : 'en')}`];
}

/** The cover block's line for a picture: "> ![Cover](path relative to the note)". */
export function imageLineFor(note: TFile, image: TFile): string {
  return `> ![Cover](${markdownImagePath(note.parent?.path ?? '', image.path)})`;
}

/** Puts a cover block at the top of the note (after the properties), or removes the one it has. */
export async function toggleCover(plugin: IctiReportsPlugin, file: TFile | null): Promise<void> {
  if (!file || file.extension !== 'md') {
    new Notice(t('Open a report note first.'));
    return;
  }
  try {
    let added = false;
    const standard = imageLineFor(file, await plugin.resources.standardCoverImage(plugin.settings.layoutPath));
    await changeText(plugin, file, (text) => {
      const nlEol = text.includes('\r\n') ? '\r\n' : '\n';
      const lines = text.split(/\r?\n/);
      const block = findCoverBlock(lines);
      if (block) {
        // Remove the block and one empty line after it.
        const after = lines[block.end] !== undefined && lines[block.end].trim() === '' ? 1 : 0;
        lines.splice(block.start, block.end - block.start + after);
        return lines.join(nlEol);
      }
      added = true;
      const at = frontmatterEnd(lines);
      const gapBefore = at > 0 && lines[at - 1]?.trim() !== '' ? [''] : [];
      lines.splice(at, 0, ...gapBefore, ...newCoverLines(file, text, standard), '');
      return lines.join(nlEol);
    });
    new Notice(added ? t('Cover page added at the top of the note. Edit the title and lines there.') : t('Cover page removed. Press Ctrl+Z in the note to get it back.'));
  } catch (e) {
    plugin.errorLog.record('toggling the cover page', e);
    new Notice(t('Changing the cover page failed: {error}', { error: e instanceof Error ? e.message : String(e) }), 10000);
  }
}

/**
 * Puts a header block (the two lines at the top left of the inner pages) under the cover block, or at the top of the
 * note, or removes the one it has.
 */
export async function toggleHeader(plugin: IctiReportsPlugin, file: TFile | null): Promise<void> {
  if (!file || file.extension !== 'md') {
    new Notice(t('Open a report note first.'));
    return;
  }
  try {
    let added = false;
    await changeText(plugin, file, (text) => {
      const eol = text.includes('\r\n') ? '\r\n' : '\n';
      const lines = text.split(/\r?\n/);
      const block = findBlock(lines, 'header');
      if (block) {
        const after = lines[block.end] !== undefined && lines[block.end].trim() === '' ? 1 : 0;
        lines.splice(block.start, block.end - block.start + after);
        return lines.join(eol);
      }
      added = true;
      const nl = /^---\r?\n[\s\S]*?^language:\s*["']?nl\b[\s\S]*?^---/m.test(text);
      const cover = findCoverBlock(lines);
      const at = cover ? cover.end : frontmatterEnd(lines);
      const gapBefore = at > 0 && lines[at - 1]?.trim() !== '' ? [''] : [];
      const gapAfter = lines[at] !== undefined && lines[at].trim() === '' ? [] : [''];
      lines.splice(at, 0, ...gapBefore, '> [!header]', `> ${file.basename}`, nl ? '> ==Tweede regel van de kop==' : '> ==Second line of the header==', ...gapAfter);
      return lines.join(eol);
    });
    new Notice(added ? t('Header block added. Its first two lines are the header of the report pages.') : t('Header block removed: the header shows the title again. Press Ctrl+Z in the note to get it back.'));
  } catch (e) {
    plugin.errorLog.record('toggling the header block', e);
    new Notice(t('Changing the header failed: {error}', { error: e instanceof Error ? e.message : String(e) }), 10000);
  }
}

/** Adds or removes the automatic table of contents: a `> [!inhoud]` (Dutch) / `> [!contents]` block followed by a page
 *  break, placed after the cover and header blocks. Removing also takes away that page break. */
export async function toggleContents(plugin: IctiReportsPlugin, file: TFile | null): Promise<void> {
  if (!file || file.extension !== 'md') {
    new Notice(t('Open a report note first.'));
    return;
  }
  try {
    let added = false;
    await changeText(plugin, file, (text) => {
      const eol = text.includes('\r\n') ? '\r\n' : '\n';
      const lines = text.split(/\r?\n/);
      const block = findBlock(lines, 'contents');
      if (block) {
        let end = block.end;
        // The page break that belongs to it ("\pagebreak", possibly after a blank line) goes too.
        let k = end;
        while (k < lines.length && lines[k].trim() === '') k++;
        if (/^\s*\\pagebreak\s*$/.test(lines[k] ?? '')) end = k + 1;
        while (end < lines.length && lines[end].trim() === '' && end - block.end < 3) end++;
        lines.splice(block.start, end - block.start);
        return lines.join(eol);
      }
      added = true;
      const nl = /^---\r?\n[\s\S]*?^language:\s*["']?nl\b[\s\S]*?^---/m.test(text);
      const ends = [findCoverBlock(lines)?.end, findBlock(lines, 'header')?.end].filter((n): n is number => n !== undefined);
      const at = ends.length ? Math.max(...ends) : frontmatterEnd(lines);
      const gapBefore = at > 0 && lines[at - 1]?.trim() !== '' ? [''] : [];
      const gapAfter = lines[at] !== undefined && lines[at].trim() === '' ? [] : [''];
      lines.splice(at, 0, ...gapBefore, nl ? '> [!inhoud]' : '> [!contents]', '', '\\pagebreak', ...gapAfter);
      return lines.join(eol);
    });
    new Notice(added ? t('Table of contents added: it lists the chapters and sections with their page numbers, and updates by itself.') : t('Table of contents removed. Press Ctrl+Z in the note to get it back.'));
  } catch (e) {
    plugin.errorLog.record('toggling the table of contents', e);
    new Notice(t('Changing the table of contents failed: {error}', { error: e instanceof Error ? e.message : String(e) }), 10000);
  }
}

/** The line after the properties block (0 when the note has none). */
function frontmatterEnd(lines: string[]): number {
  if (lines[0]?.replace(/^﻿/, '').trim() !== '---') return 0;
  for (let i = 1; i < lines.length; i++) if (lines[i].trim() === '---') return i + 1;
  return 0;
}

export function changeCoverImage(plugin: IctiReportsPlugin, note: TFile | null): void {
  const { app } = plugin;
  if (!note || note.extension !== 'md') {
    new Notice(t('Open a report note first.'));
    return;
  }
  const images = app.vault.getFiles().filter((f) => IMAGE.test(f.extension)).sort((a, b) => b.stat.mtime - a.stat.mtime);
  new ImagePicker(app, images, async (choice) => {
      try {
        let image: TFile | null = null;
        if (choice.kind === 'file') image = choice.file;
        // The standard picture is written into the note too, so the Markdown always shows which picture is used.
        if (choice.kind === 'standard') image = await plugin.resources.standardCoverImage(plugin.settings.layoutPath);
        if (choice.kind === 'upload') {
          const picked = await pickFromComputer();
          if (!picked) return;
          if (!imageFormat(new Uint8Array(picked.data))) throw new Error(t('{name} is not a usable image (png, jpg, gif, webp or svg).', { name: picked.name }));
          // Stored where Obsidian puts attachments for this note (Settings → Files and links).
          const name = picked.name.replace(/[<>:"/\\|?*#^[\]]/g, '-');
          const path = await app.fileManager.getAvailablePathForAttachment(name, note.path);
          image = await app.vault.createBinary(path, picked.data);
        }
        if (!image) return;
        const imageLine = imageLineFor(note, image);
        await changeText(plugin, note, (current) => {
          const eol = current.includes('\r\n') ? '\r\n' : '\n';
          const ls = current.split(/\r?\n/);
          const b = findCoverBlock(ls);
          if (!b) {
            // No cover yet: add one with this picture.
            const at = frontmatterEnd(ls);
            const gapBefore = at > 0 && ls[at - 1]?.trim() !== '' ? [''] : [];
            ls.splice(at, 0, ...gapBefore, ...newCoverLines(note, current, imageLine), '');
            return ls.join(eol);
          }
          if (b.imageLine >= 0) {
            ls[b.imageLine] = imageLine;
            return ls.join(eol);
          }
          return withCoverImage(current, imageLine);
        });
        new Notice(t('Cover image set to {name}.', { name: image.name }));
      } catch (e) {
        plugin.errorLog.record('change cover image', e);
        new Notice(t('Changing the cover failed: {error}', { error: e instanceof Error ? e.message : String(e) }), 10000);
      }
    }).open();
}
