// Zoom per note: makes the text of one note larger or smaller without touching the rest of Obsidian.
// The level is remembered per note (by path) on this computer (local storage, not the synced plugin settings)
// and applied to every tab showing that note.
import { MarkdownView, TFile, type TAbstractFile, type WorkspaceLeaf } from 'obsidian';
import type IctiReportsPlugin from '../main';
import { markdownViews } from './views';

/** The zoom steps, in percent (like a browser). */
export const ZOOM_STEPS = [50, 67, 75, 80, 90, 100, 110, 125, 150, 175, 200, 250, 300];

/** The next step up (+1), down (-1), or back to 100% (0). */
export function nextZoom(current: number, direction: -1 | 0 | 1): number {
  if (direction === 0) return 100;
  if (direction > 0) return ZOOM_STEPS.find((s) => s > current) ?? ZOOM_STEPS[ZOOM_STEPS.length - 1];
  return [...ZOOM_STEPS].reverse().find((s) => s < current) ?? ZOOM_STEPS[0];
}

/**
 * The variables Obsidian sizes note text with. Both are resolved to px on <body>, so both are overridden on the
 * note's content element (editor and reading view use --font-preferred-size; headings and the title scale with it).
 */
const SIZE_VARS = ['--font-preferred-size', '--font-text-size'];

const ZOOM_KEY = 'icti-reports-note-zoom';

export class NoteZoom {
  private levels: Record<string, number> = {};

  /** The note the zoom buttons act on: the last note tab that was active (clicking the panel does not change it). */
  private last: MarkdownView | null = null;
  private listeners = new Set<() => void>();

  constructor(private plugin: IctiReportsPlugin) {}

  start(): void {
    const { workspace, vault } = this.plugin.app;
    const p = this.plugin;
    const stored: unknown = p.app.loadLocalStorage(ZOOM_KEY);
    this.levels = stored && typeof stored === 'object' ? { ...(stored as Record<string, number>) } : {};
    const legacy = p.settings.legacyNoteZoom;
    if (legacy) {
      this.levels = { ...legacy, ...this.levels };
      delete p.settings.legacyNoteZoom;
      this.save();
      void p.saveSettings(); // drops the old levels from the shared data.json
    }
    p.registerEvent(workspace.on('active-leaf-change', (leaf) => this.track(leaf)));
    p.registerEvent(workspace.on('file-open', () => {
      this.track(workspace.getMostRecentLeaf());
      this.update();
    }));
    p.registerEvent(workspace.on('layout-change', () => this.update()));
    p.registerEvent(workspace.on('css-change', () => this.applyAll())); // Obsidian's own font size changed
    p.registerEvent(vault.on('rename', (file: TAbstractFile, oldPath: string) => {
      const z = this.levels;
      if (file instanceof TFile && oldPath in z) {
        z[file.path] = z[oldPath];
        delete z[oldPath];
        this.save();
      }
    }));
    p.registerEvent(vault.on('delete', (file: TAbstractFile) => {
      if (file.path in this.levels) {
        delete this.levels[file.path];
        this.save();
      }
    }));
    workspace.onLayoutReady(() => {
      this.track(workspace.getMostRecentLeaf());
      this.update();
    });
    p.register(() => this.clearAll());
  }

  /** Calls `fn` whenever the target note or its zoom changes; returns a function that stops it. */
  onChange(fn: () => void): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  /** The note the buttons act on, or null when no note is open. */
  target(): TFile | null {
    const open = markdownViews(this.plugin.app);
    const view = this.last && open.includes(this.last) && this.last.file ? this.last : open.find((v) => v.file) ?? null;
    return view?.file ?? null;
  }

  level(file: TFile | null): number {
    const z = file ? this.levels[file.path] : undefined;
    return typeof z === 'number' && z > 0 ? z : 100;
  }

  /** Zoom the target note in (+1), out (-1) or back to 100% (0). */
  async change(direction: -1 | 0 | 1): Promise<void> {
    const file = this.target();
    if (!file) return;
    const z = nextZoom(this.level(file), direction);
    if (z === 100) delete this.levels[file.path];
    else this.levels[file.path] = z;
    this.update();
    this.save();
  }

  private save(): void {
    this.plugin.app.saveLocalStorage(ZOOM_KEY, Object.keys(this.levels).length ? this.levels : null);
  }

  private track(leaf: WorkspaceLeaf | null): void {
    if (leaf?.view instanceof MarkdownView) {
      this.last = leaf.view;
      this.notify();
    }
  }

  private update(): void {
    this.applyAll();
    this.notify();
  }

  private notify(): void {
    for (const fn of this.listeners) fn();
  }

  /** Sets the text size of every open note tab from its note's zoom level. */
  private applyAll(): void {
    for (const view of markdownViews(this.plugin.app)) {
      const el = view.contentEl;
      const z = this.level(view.file);
      for (const v of [...SIZE_VARS, '--file-line-width']) el.style.removeProperty(v);
      el.toggleClass('icti-note-zoomed', z !== 100);
      if (z === 100) continue;
      // Obsidian's text size (Settings → Appearance → Font size) and line width, as set on the window's body.
      const body = getComputedStyle(el.ownerDocument.body);
      const base = parseFloat(body.getPropertyValue('--font-preferred-size')) || 16;
      for (const v of SIZE_VARS) el.style.setProperty(v, `${Math.round(base * z) / 100}px`);
      // The readable line length grows with the text, so a zoomed note wraps the same way (up to the window width).
      const width = parseFloat(body.getPropertyValue('--file-line-width'));
      if (width) el.style.setProperty('--file-line-width', `${Math.round(width * z / 100)}px`);
    }
  }

  private clearAll(): void {
    for (const view of markdownViews(this.plugin.app)) {
      const el = view.contentEl;
      for (const v of [...SIZE_VARS, '--file-line-width']) el.style.removeProperty(v);
      el.removeClass('icti-note-zoomed');
    }
  }
}
