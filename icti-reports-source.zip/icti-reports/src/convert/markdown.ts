// Markdown (Obsidian flavour) -> document tree. Built on markdown-it with a few small custom rules:
//   ==placeholder==   <span style="color:red">red text</span>   ![[embed.png|300]]   [[wikilink|alias]]   \pagebreak   > [!callout] Title
//   > [!cover] (the cover page)   <br> in cells
import markdownIt, { type MarkdownIt, type StateBlock, type StateInline, type Token } from 'markdown-it';
import type { Block, Cell, CoverBlock, ImageNode, Inline } from './ast';

const IMAGE_EXT = /\.(png|jpe?g|gif|svg|webp)$/i;
const CALLOUT_RE = /^\[!([A-Za-z-]+)\][+-]?\s*/;
/** Callout types of the automatic table of contents. */
export const CONTENTS_CALLOUTS = ['inhoud', 'inhoudsopgave', 'contents', 'toc'];
const BR_RE = /<br\s*\/?>/i;
const SAFE_HREF = /^(https?:|mailto:)/i;

// ---------- markdown-it setup ----------

function placeholderRule(state: StateInline, silent: boolean): boolean {
  const src = state.src;
  const start = state.pos;
  if (src.charCodeAt(start) !== 0x3d || src.charCodeAt(start + 1) !== 0x3d) return false;
  const end = src.indexOf('==', start + 2);
  if (end < 0 || end === start + 2 || end > state.posMax) return false;
  if (!silent) {
    const oldMax = state.posMax;
    state.push('placeholder_open', 'span', 1);
    state.pos = start + 2;
    state.posMax = end;
    state.md.inline.tokenize(state);
    state.posMax = oldMax;
    state.push('placeholder_close', 'span', -1);
  }
  state.pos = end + 2;
  return true;
}

/**
 * Red on purpose: <span style="color:red">…</span>, the HTML Obsidian itself shows in red. Only this exact form is
 * read (color red, #f00, #ff0000 or rgb(255, 0, 0), quotes either way); any other HTML stays literal text, as before.
 * The text inside is ordinary Markdown (bold, italic, links …) up to its own </span> (spans inside it are counted;
 * other spans stay literal text); without a closing tag it all stays text. A "</span>" typed inside a code span
 * or link address within the red text also counts as a closing tag.
 */
const RED_OPEN = /^<span\s+style\s*=\s*(["'])\s*color\s*:\s*(?:red|#f00|#ff0000|rgb\(\s*255\s*,\s*0\s*,\s*0\s*\))\s*;?\s*\1\s*>/i;
const SPAN_TAG = /<span[\s>]|<\/span\s*>/gi;

/** Where the </span> that closes a span opened just before `from` starts, and its length; null when unclosed. */
function spanEnd(src: string, from: number, max: number): { at: number; len: number } | null {
  SPAN_TAG.lastIndex = from;
  let depth = 1;
  for (let m = SPAN_TAG.exec(src); m && m.index < max; m = SPAN_TAG.exec(src)) {
    if (m.index + m[0].length > max) break;
    depth += m[0][1] === '/' ? -1 : 1;
    if (depth === 0) return { at: m.index, len: m[0].length };
  }
  return null;
}

function redRule(state: StateInline, silent: boolean): boolean {
  if (state.src.charCodeAt(state.pos) !== 0x3c) return false;
  const m = RED_OPEN.exec(state.src.slice(state.pos, state.posMax));
  if (!m) return false;
  const from = state.pos + m[0].length;
  const close = spanEnd(state.src, from, state.posMax);
  if (!close) return false;
  const end = close.at;
  if (!silent) {
    const oldMax = state.posMax;
    state.push('red_open', 'span', 1);
    state.pos = from;
    state.posMax = end;
    state.md.inline.tokenize(state);
    state.posMax = oldMax;
    state.push('red_close', 'span', -1);
  }
  state.pos = end + close.len;
  return true;
}

function wikiRule(state: StateInline, silent: boolean): boolean {
  const src = state.src.slice(state.pos, state.posMax);
  const m = /^(!?)\[\[([^\[\]\n]+)\]\]/.exec(src);
  if (!m) return false;
  if (!silent) {
    const tok = state.push(m[1] ? 'wiki_embed' : 'wiki_link', '', 0);
    tok.content = m[2];
  }
  state.pos += m[0].length;
  return true;
}

/** Commands on a line of their own: \pagebreak. */
const MARKERS: Record<string, 'pagebreak'> = { '\\pagebreak': 'pagebreak' };

function markerRule(state: StateBlock, startLine: number, _endLine: number, silent: boolean): boolean {
  const pos = state.bMarks[startLine] + state.tShift[startLine];
  const type = MARKERS[state.src.slice(pos, state.eMarks[startLine]).trim()];
  if (!type) return false;
  if (!silent) {
    const tok = state.push(type, '', 0);
    tok.map = [startLine, startLine + 1];
  }
  state.line = startLine + 1;
  return true;
}

function createParser(): MarkdownIt {
  const md = markdownIt('default', { html: false, linkify: false, typographer: false });
  md.disable(['html_block', 'html_inline', 'linkify', 'replacements', 'smartquotes', 'lheading', 'reference']);
  md.inline.ruler.before('emphasis', 'placeholder', placeholderRule);
  md.inline.ruler.before('placeholder', 'red', redRule);
  md.inline.ruler.before('link', 'wiki', wikiRule);
  md.block.ruler.before('paragraph', 'markers', markerRule, { alt: ['paragraph', 'blockquote', 'list'] });
  return md;
}

const parser = createParser();

// ---------- token -> tree ----------

class Converter {
  constructor(private lines: string[], private lineOffset: number) {}

  lineOf(tok: Token | undefined): number {
    return tok?.map ? tok.map[0] + 1 + this.lineOffset : 0;
  }

  blocks(tokens: Token[], from: number, to: number): Block[] {
    const out: Block[] = [];
    let i = from;
    while (i < to) {
      const tok = tokens[i];
      const close = tok.nesting === 1 ? this.findClose(tokens, i) : i;
      const line = this.lineOf(tok);
      switch (tok.type) {
        case 'heading_open': {
          const c = this.inline(tokens[i + 1], line);
          if (c.length) out.push({ t: 'heading', level: Number(tok.tag.slice(1)), c, line }); // a bare "#" is dropped
          break;
        }
        case 'paragraph_open': {
          const c = this.inline(tokens[i + 1], line);
          out.push({ t: 'para', c, line });
          break;
        }
        case 'bullet_list_open':
        case 'ordered_list_open':
          out.push(this.list(tokens, i, close, line));
          break;
        case 'blockquote_open':
          out.push(...this.quote(tokens, i, close, line));
          break;
        case 'table_open':
          out.push(this.table(tokens, i, close, line));
          break;
        case 'fence':
        case 'code_block':
          out.push({ t: 'codeblock', v: tok.content.replace(/\n$/, ''), line });
          break;
        case 'hr':
          out.push({ t: 'rule', line });
          break;
        case 'pagebreak':
          out.push({ t: 'pagebreak', line });
          break;
        default:
          break;
      }
      i = close + 1;
    }
    return out;
  }

  findClose(tokens: Token[], open: number): number {
    let depth = 0;
    for (let j = open; j < tokens.length; j++) {
      depth += tokens[j].nesting;
      if (depth === 0) return j;
    }
    return tokens.length - 1;
  }

  list(tokens: Token[], open: number, close: number, line: number): Block {
    const ordered = tokens[open].type === 'ordered_list_open';
    const start = Number(tokens[open].attrGet('start') ?? 1);
    const items: Block[][] = [];
    let loose = false;
    for (let j = open + 1; j < close; j++) {
      if (tokens[j].type !== 'list_item_open') continue;
      const itemClose = this.findClose(tokens, j);
      for (let k = j + 1; k < itemClose; k++) {
        const t = tokens[k];
        if (t.type === 'paragraph_open' && !t.hidden && t.level === tokens[j].level + 1) loose = true;
      }
      items.push(noPagebreaks(this.blocks(tokens, j + 1, itemClose)));
      j = itemClose;
    }
    return { t: 'list', ordered, start, loose, items, line };
  }


  /** A callout `> [!type] Title` becomes a titled quote (`[!cover]`: the cover page); other quotes stay quotes. */
  quote(tokens: Token[], open: number, close: number, line: number): Block[] {
    // A callout's title ends at the first line break, so re-read its first paragraph keeping line breaks.
    const isCallout = tokens[open + 1]?.type === 'paragraph_open' && CALLOUT_RE.test(tokens[open + 2]?.content ?? '');
    const calloutType = isCallout ? CALLOUT_RE.exec(tokens[open + 2].content)![1].toLowerCase() : '';
    if (calloutType === 'cover') return [this.cover(tokens, open, close, line)];
    if (CONTENTS_CALLOUTS.includes(calloutType)) {
      // The automatic table of contents; text after the marker is its own title ("> [!inhoud] Inhoudsopgave").
      const { head } = this.calloutLines(tokens, open, close, line);
      return [{ t: 'contents', title: head.length ? head : null, line }];
    }
    if (calloutType === 'header') {
      // Every line of the block, in order (a heading too), is a header line; pictures are left out.
      const { head, items } = this.calloutLines(tokens, open, close, line);
      return [{ t: 'header', lines: [...(head.length ? [head] : []), ...items.map((i) => i.c)], line }];
    }
    const inner = noPagebreaks(this.blocks(tokens, open + 1, close));
    if (isCallout && inner[0]?.t === 'para') inner[0].c = this.inline(tokens[open + 2], line, true);
    const first = inner[0];
    const firstText = first?.t === 'para' && first.c[0]?.t === 'text' ? first.c[0].v : '';
    const m = CALLOUT_RE.exec(firstText);
    if (!m || first.t !== 'para') return [{ t: 'quote', title: null, c: inner, line }];

    // Split the first paragraph at its first line break: before = title, after = body.
    const rest: Inline[] = [{ t: 'text', v: firstText.slice(m[0].length) }, ...first.c.slice(1)];
    const brAt = rest.findIndex((n) => n.t === 'br');
    const title = trimInlines(brAt < 0 ? rest : rest.slice(0, brAt));
    const bodyFirst = brAt < 0 ? [] : trimInlines(rest.slice(brAt + 1));
    const body: Block[] = [...(bodyFirst.length ? [{ t: 'para' as const, c: bodyFirst, line }] : []), ...inner.slice(1)];
    return [{ t: 'quote', title: title.length ? title : null, c: body, line }];
  }

  /**
   * The lines of a cover or header block: `head` is the text after "[!type]" on the first line, `items` every
   * further line (each heading, and each line of a paragraph) in order, `image` the first picture. Lists, tables
   * and the like inside the block are left out.
   */
  calloutLines(tokens: Token[], open: number, close: number, line: number): { head: Inline[]; items: { c: Inline[]; heading: boolean; para: number }[]; image: ImageNode | null } {
    let head: Inline[] = [];
    const items: { c: Inline[]; heading: boolean; para: number }[] = [];
    let para = 0; // which paragraph (or heading) of the block a line is in
    let image: ImageNode | null = null;
    let first = true;
    for (let k = open + 1; k < close; k++) {
      const tok = tokens[k];
      const end = tok.nesting === 1 ? this.findClose(tokens, k) : k;
      if (tok.type === 'heading_open') {
        const c = this.inline(tokens[k + 1], this.lineOf(tok) || line);
        if (c.length) items.push({ c, heading: true, para: ++para });
      } else if (tok.type === 'paragraph_open') {
        let c = this.inline(tokens[k + 1], this.lineOf(tok) || line, true);
        para++;
        if (first && c[0]?.t === 'text') {
          // "[!cover] Title" on the first line: the rest of that line is the head.
          const rest: Inline[] = [{ t: 'text', v: c[0].v.replace(CALLOUT_RE, '') }, ...c.slice(1)];
          const brAt = rest.findIndex((n) => n.t === 'br');
          head = trimInlines(brAt < 0 ? rest : rest.slice(0, brAt));
          c = brAt < 0 ? [] : rest.slice(brAt + 1);
        }
        let cur: Inline[] = [];
        const flush = () => {
          const l = trimInlines(cur);
          if (l.length) items.push({ c: l, heading: false, para });
          cur = [];
        };
        for (const n of c) {
          if (n.t === 'br') flush();
          else if (n.t === 'image') {
            if (!image) image = n; // a second picture is left out
          } else cur.push(n);
        }
        flush();
      }
      first = false;
      k = end;
    }
    return { head, items, image };
  }

  /**
   * The cover block:
   *   > [!cover]
   *   > # Title
   *   > A line of text (each line of the block is a line on the cover)
   *   > ![](cover.png)
   * The text after "[!cover]" (or else the first heading, or else the first line) is the title; the first picture is
   * the cover image; every other line is a line of text. Below the bars (from the third line on), an empty line in
   * the block between two lines is kept as an empty line on the cover.
   */
  cover(tokens: Token[], open: number, close: number, line: number): CoverBlock {
    const { head, items, image } = this.calloutLines(tokens, open, close, line);
    let title = head;
    if (!title.length) {
      const at = Math.max(0, items.findIndex((i) => i.heading));
      title = items.splice(at, 1)[0]?.c ?? [];
    }
    const lines: Inline[][] = [];
    items.forEach((item, i) => {
      if (lines.length >= 3 && item.para !== items[i - 1].para) lines.push([]);
      lines.push(item.c);
    });
    return { t: 'cover', title, lines, image, line };
  }

  table(tokens: Token[], open: number, close: number, line: number): Block {
    const head: Cell[] = [];
    const rows: Cell[][] = [];
    let row: Cell[] | null = null;
    let rowLine = line;
    const rowLines: number[] = [];
    let inHead = false;
    for (let j = open; j < close; j++) {
      const tok = tokens[j];
      if (tok.type === 'thead_open') inHead = true;
      else if (tok.type === 'thead_close') inHead = false;
      else if (tok.type === 'tr_open') {
        row = [];
        rowLine = this.lineOf(tok) || line;
      }
      else if (tok.type === 'tr_close' && row) {
        if (inHead) head.push(...row);
        else {
          rows.push(row);
          rowLines.push(rowLine);
        }
        row = null;
      } else if ((tok.type === 'th_open' || tok.type === 'td_open') && row) {
        row.push(this.inline(tokens[j + 1], rowLine));
      }
    }
    return {
      t: 'table',
      widths: this.dashWidths(tokens[open], head.length) ?? guessWidths(head, rows),
      head,
      rows,
      rowLines,
      line,
    };
  }

  /**
   * Relative column widths from the delimiter row (|--|------|), or null when all are equal.
   * Each column counts as 4 to 30 dashes: Obsidian's table editor pads the delimiter row to the longest
   * text in each column (often hundreds of dashes), which must not starve the other columns.
   */
  dashWidths(tableOpen: Token, cols: number): number[] | null {
    if (!tableOpen.map) return null;
    const delim = this.lines[tableOpen.map[0] + 1] ?? '';
    const raw = delim.replace(/^[>\s]*/, '').trim().replace(/^\|/, '').replace(/\|$/, '').split('|').map((p) => p.trim().length);
    if (raw.length !== cols || raw.some((n) => n < 1)) return null;
    const parts = raw.map((n) => Math.min(30, Math.max(4, n)));
    return parts.every((n) => n === parts[0]) ? null : parts;
  }

  inline(tok: Token | undefined, line: number, softAsBreak = false): Inline[] {
    if (!tok?.children) return [];
    const root: Inline[] = [];
    const stack: Inline[][] = [root];
    const top = () => stack[stack.length - 1];
    const open = (node: Inline & { c: Inline[] }) => {
      top().push(node);
      stack.push(node.c);
    };
    let cur = line; // the source line of the current position, for images on later lines of a paragraph
    for (const ch of tok.children) {
      switch (ch.type) {
        case 'text':
          top().push(...splitBreaks(ch.content));
          break;
        case 'softbreak':
          top().push(softAsBreak ? { t: 'br' } : { t: 'text', v: ' ' });
          if (cur) cur++;
          break;
        case 'hardbreak':
          top().push({ t: 'br' });
          if (cur) cur++;
          break;
        case 'strong_open':
          open({ t: 'strong', c: [] });
          break;
        case 'em_open':
          open({ t: 'em', c: [] });
          break;
        case 'placeholder_open':
          open({ t: 'placeholder', c: [] });
          break;
        case 'red_open':
          open({ t: 'red', c: [] });
          break;
        case 'link_open': {
          const href = String(ch.attrGet('href') ?? '');
          open({ t: 'link', href: SAFE_HREF.test(href) ? href : '', c: [] });
          break;
        }
        case 'strong_close':
        case 'em_close':
        case 'placeholder_close':
        case 'red_close':
        case 'link_close':
          if (stack.length > 1) stack.pop();
          break;
        case 'code_inline':
          top().push({ t: 'code', v: ch.content });
          break;
        case 'image':
          top().push(this.image(String(ch.attrGet('src') ?? ''), undefined, cur));
          break;
        case 'wiki_embed': {
          const [target, size] = ch.content.split('|');
          if (!IMAGE_EXT.test(target.trim())) {
            top().push({ t: 'text', v: linkText(target, size) }); // embedding another note is not supported: show its name
            break;
          }
          const width = size && /^\d+(x\d+)?$/.test(size.trim()) ? Number(size.trim().split('x')[0]) : undefined;
          top().push(this.image(target.trim(), width, cur));
          break;
        }
        case 'wiki_link': {
          const [target, alias] = ch.content.split('|');
          top().push({ t: 'text', v: linkText(target, alias) });
          break;
        }
        default:
          if (ch.content) top().push({ t: 'text', v: ch.content });
      }
    }
    return mergeText(root);
  }

  image(ref: string, width: number | undefined, line: number): ImageNode {
    let target = ref;
    try {
      target = decodeURIComponent(ref);
    } catch {
      /* keep as written */
    }
    return { t: 'image', ref: target, ...(width ? { width } : {}), line };
  }
}

// ---------- inline helpers ----------

function plainText(nodes: Inline[]): string {
  return nodes.map((n) => (n.t === 'text' || n.t === 'code' ? n.v : 'c' in n ? plainText(n.c) : n.t === 'br' ? '\n' : '')).join('');
}

/** Relative column widths from content: longest line per column, clamped so no column is starved or huge. */
export function guessWidths(head: Cell[], rows: Cell[][]): number[] {
  return head.map((h, x) => {
    const cells = [h, ...rows.map((r) => r[x] ?? [])].map(plainText);
    const longestLine = Math.max(...cells.flatMap((c) => c.split('\n').map((l) => l.length)));
    const longestWord = Math.min(30, Math.max(...cells.flatMap((c) => c.split(/\s+/).map((w) => w.length))));
    return Math.max(longestWord, Math.min(longestLine, 30), 4);
  });
}

/** Display text of a wikilink: alias, else note name, else the heading after "#". */
function linkText(target: string, alias?: string): string {
  if (alias?.trim()) return alias.trim();
  const [name, section = ''] = target.split('#');
  return (name.trim() || section.trim()).split('/').pop() ?? '';
}

/** Page breaks (and the cover and header blocks) only work at the top level of the document. */
function noPagebreaks(blocks: Block[]): Block[] {
  return blocks.filter((b) => b.t !== 'pagebreak' && b.t !== 'cover' && b.t !== 'header');
}

function splitBreaks(text: string): Inline[] {
  const out: Inline[] = [];
  text.split(BR_RE).forEach((part, i) => {
    if (i > 0) out.push({ t: 'br' });
    if (part) out.push({ t: 'text', v: part });
  });
  return out;
}

function mergeText(nodes: Inline[]): Inline[] {
  const out: Inline[] = [];
  for (const n of nodes) {
    if ('c' in n) n.c = mergeText(n.c);
    const prev = out[out.length - 1];
    if (n.t === 'text' && prev?.t === 'text') prev.v += n.v;
    else out.push(n);
  }
  return out;
}

function trimInlines(nodes: Inline[]): Inline[] {
  const out = nodes.map((n) => ({ ...n })) as Inline[];
  const first = out[0];
  if (first?.t === 'text') first.v = first.v.trimStart();
  const last = out[out.length - 1];
  if (last?.t === 'text') last.v = last.v.trimEnd();
  return out.filter((n) => !(n.t === 'text' && n.v === ''));
}

// ---------- public API ----------

/** Splits off a leading `---` YAML frontmatter block. */
export function splitFrontmatter(src: string): { yaml: string; body: string; bodyLine: number } {
  const m = /^\uFEFF?---\r?\n(?:([\s\S]*?)\r?\n)?---[ \t]*(\r?\n|$)/.exec(src);
  if (!m) return { yaml: '', body: src.replace(/^\uFEFF/, ''), bodyLine: 0 };
  return { yaml: m[1] ?? '', body: src.slice(m[0].length), bodyLine: m[0].split('\n').length - 1 };
}

/**
 * Converts a note body to the document tree.
 * @param lineOffset number of lines before `body` in the note (the frontmatter), so lines point into the note.
 */
export function convertMarkdown(body: string, lineOffset = 0): Block[] {
  const src = body.replace(/\r\n?/g, '\n');
  const tokens = parser.parse(src, {});
  const conv = new Converter(src.split('\n'), lineOffset);
  return conv.blocks(tokens, 0, tokens.length);
}

/** Walks every image node in the tree. */
export function forEachImage(blocks: Block[], fn: (img: ImageNode) => void): void {
  const inl = (nodes: Inline[]) => {
    for (const n of nodes) {
      if (n.t === 'image') fn(n);
      else if ('c' in n) inl(n.c);
    }
  };
  for (const b of blocks) {
    if (b.t === 'heading' || b.t === 'para') inl(b.c);
    else if (b.t === 'list') b.items.forEach((it) => forEachImage(it, fn));
    else if (b.t === 'quote') {
      if (b.title) inl(b.title);
      forEachImage(b.c, fn);
    } else if (b.t === 'cover') {
      if (b.image) fn(b.image);
    } else if (b.t === 'table') {
      b.head.forEach(inl);
      b.rows.forEach((r) => r.forEach(inl));
    }
  }
}
