// The document tree handed to the Typst layout as JSON.
// It is plain data: the layout renders strings as text, so note content can never run as Typst code.

export type Inline =
  | { t: 'text'; v: string }
  | { t: 'strong'; c: Inline[] }
  | { t: 'em'; c: Inline[] }
  | { t: 'placeholder'; c: Inline[] } // ==text==, shown in red (text still to fill in)
  | { t: 'red'; c: Inline[] } // <span style="color:red">text</span>, red on purpose (not a placeholder)
  | { t: 'link'; href: string; c: Inline[] }
  | { t: 'code'; v: string }
  | { t: 'br' }
  | ImageNode;

export interface ImageNode {
  t: 'image';
  /** The target as written in the note (`file.png`, `img/a.png`). */
  ref: string;
  /** Width in pt from `![[file.png|300]]`, if given. */
  width?: number;
  /** Path in Typst's virtual file system, set by prepare(); absent = not found (the layout draws a placeholder). */
  src?: string;
  line: number;
}

export type Cell = Inline[];

/** The cover page, written as a `> [!cover]` block in the note: a title, lines of text and an optional picture. */
export interface CoverBlock {
  t: 'cover';
  title: Inline[];
  lines: Inline[][];
  image: ImageNode | null;
  line: number;
}

/** The two text lines at the top left of the inner pages, written as a `> [!header]` block in the note. */
export interface HeaderBlock {
  t: 'header';
  lines: Inline[][];
  line: number;
}

export type Block =
  | { t: 'heading'; level: number; c: Inline[]; line: number }
  | { t: 'para'; c: Inline[]; line: number }
  | { t: 'list'; ordered: boolean; start: number; loose: boolean; items: Block[][]; line: number }
  | { t: 'table'; widths: number[] | null; head: Cell[]; rows: Cell[][]; rowLines: number[]; line: number }
  | { t: 'quote'; title: Inline[] | null; c: Block[]; line: number }
  | { t: 'codeblock'; v: string; line: number }
  /** The automatic table of contents (`> [!inhoud]` or `> [!contents]`), with an optional own title. */
  | { t: 'contents'; title: Inline[] | null; line: number }
  | { t: 'pagebreak'; line: number }
  | { t: 'rule'; line: number }
  | CoverBlock
  | HeaderBlock;

export interface Diagnostic {
  /** 1-based line in the note (including the frontmatter), or 0 when not tied to a line. */
  line: number;
  severity: 'error' | 'warning';
  message: string;
}
