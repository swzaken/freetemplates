// Language of the plugin's own screens (commands, settings, notices, preview). The report's labels are
// separate (src/data/labels.ts, chosen per report with the `language` property).
// t('English text with {vars}', { vars }) returns the Dutch text when the plugin language is Dutch;
// missing translations fall back to English. tests/i18n.test.ts checks that every t() text has a translation.

export type UiLanguage = 'nl' | 'en';

let current: UiLanguage = 'en';

export function setUiLanguage(lang: UiLanguage): void {
  current = lang;
}

export function uiLanguage(): UiLanguage {
  return current;
}

export function t(en: string, vars: Record<string, string | number> = {}): string {
  const text = current === 'nl' ? NL[en] ?? en : en;
  return text.replace(/\{(\w+)\}/g, (m, key: string) => (key in vars ? String(vars[key]) : m));
}

export const NL: Record<string, string> = {
  // commands and ribbon
  'Export report to PDF': 'Rapport exporteren naar PDF',
  'Open report preview': 'Rapportvoorbeeld openen',
  'New report': 'Nieuw rapport',
  'Change cover image': 'Omslagafbeelding wijzigen',
  'New presentation': 'Nieuwe presentatie',
  'Import Word report': 'Word-rapport importeren',
  'Import Word report as template': 'Word-rapport importeren als sjabloon',
  // importing Word reports
  'the file is larger than 100 MB': 'het bestand is groter dan 100 MB',
  'this is not a readable Word file (.docx)': 'dit is geen leesbaar Word-bestand (.docx)',
  'the Word file is too large to import': 'het Word-bestand is te groot om te importeren',
  'the Word file is damaged': 'het Word-bestand is beschadigd',
  'The built-in report templates were put in {path} first, so they stay available next to the imported ones.': 'Eerst zijn de ingebouwde rapportsjablonen in {path} gezet, zodat ze naast de geïmporteerde beschikbaar blijven.',
  'Word reports are already being imported.': 'Er worden al Word-rapporten geïmporteerd.',
  'Set a templates folder inside the vault first (Settings → ICT Institute Reports → Templates folder).': 'Stel eerst een sjablonenmap in de kluis in (Instellingen → ICT Institute Reports → Sjablonenmap).',
  'Importing {name} failed: {error}': '{name} importeren mislukt: {error}',
  'Importing failed: {error}': 'Importeren mislukt: {error}',
  'only .docx files can be imported (save older .doc files as .docx in Word first)': 'alleen .docx-bestanden kunnen worden geïmporteerd (sla oudere .doc-bestanden eerst in Word op als .docx)',
  'no text found after the cover and table of contents': 'geen tekst gevonden na het voorblad en de inhoudsopgave',
  'cover page': 'voorblad',
  '{path} is a file, not a folder.': '{path} is een bestand, geen map.',
  charts: 'grafieken',
  'SmartArt diagrams': 'SmartArt-diagrammen',
  equations: 'formules',
  'pictures in a format the report cannot show': 'afbeeldingen in een formaat dat het rapport niet kan tonen',
  '{name} imported as report template "{template}".': '{name} is geïmporteerd als rapportsjabloon "{template}".',
  'Left out (the plugin makes these itself): {parts}.': 'Weggelaten (die maakt de plugin zelf): {parts}.',
  'Not imported: {parts}.': 'Niet geïmporteerd: {parts}.',
  'New template package': 'Nieuw templatepakket',
  'Turn on the plugin ICT Institute Templates to make template packages.': 'Zet de plugin ICT Institute Templates aan om templatepakketten te maken.',
  'Turn on the plugin ICT Institute Presentations to make presentations.': 'Zet de plugin ICT Institute Presentations aan om presentaties te maken.',
  'Show ICT Institute menu': 'ICT Institute-menu tonen',
  Search: 'Zoeken',
  'The report took too long to make (more than 90 seconds) and was stopped. Check the layout file or make the report smaller.':
    'Het maken van het rapport duurde te lang (meer dan 90 seconden) en is gestopt. Controleer het opmaakbestand of maak het rapport kleiner.',
  'The plugin was turned off.': 'De plugin is uitgezet.',
  'Set your name for the change log under Settings → ICT Institute Reports → Your name.':
    'Stel je naam voor de log in via Instellingen → ICT Institute Reports → Je naam.',
  'Your name is not set yet, so your changes are logged as "Unknown".': 'Je naam is nog niet ingesteld, dus je wijzigingen staan als "Onbekend" in de log.',
  'Set name': 'Naam instellen',
  'The change log could not be read: {error}': 'De log kon niet worden gelezen: {error}',
  'Change log': 'Log',
  'Change log: {note}': 'Log: {note}',
  Details: 'Details',
  '(added)': '(toegevoegd)',
  '(removed)': '(verwijderd)',
  'More changes were made than are shown here.': 'Er zijn meer wijzigingen gemaakt dan hier getoond.',
  'Date and time': 'Datum en tijd',
  Who: 'Wie',
  What: 'Wat',
  Created: 'Aangemaakt',
  'Created (date of the file; made before the change log existed)': 'Aangemaakt (datum van het bestand; gemaakt voordat de log bestond)',
  'Renamed from "{from}" to "{to}"': 'Hernoemd van "{from}" naar "{to}"',
  'Exported to PDF: {path}': 'Geëxporteerd naar PDF: {path}',
  '(text before the first heading)': '(tekst voor de eerste kop)',
  'Chapters: {list}': 'Hoofdstukken: {list}',
  'Properties: {list}': 'Eigenschappen: {list}',
  '+{added} / −{removed} characters': '+{added} / −{removed} tekens',
  Edited: 'Bewerkt',
  'Edits by the same person within 15 minutes are combined into one line. The log is kept in the hidden folder .logboek of the vault.':
    'Wijzigingen door dezelfde persoon binnen 15 minuten staan samen op één regel. De log staat in de verborgen map .logboek van de vault.',
  Unknown: 'Onbekend',
  'A change log could not be read and was set aside: {path}': 'Een log kon niet worden gelezen en is apart gezet: {path}',
  'Your name for the change log': 'Je naam voor de log',
  'Changes you make are logged under this name. You can change it later in the plugin settings.':
    'Wijzigingen die je maakt komen onder deze naam in de log. Je kunt hem later aanpassen in de plugin-instellingen.',
  'First and last name': 'Voor- en achternaam',
  Save: 'Opslaan',
  'Your name': 'Je naam',
  'Shown in the change log of every note you create or change. Saved on this computer only, so every colleague sets their own.':
    'Staat in de log van elke notitie die je maakt of wijzigt. Alleen op deze computer opgeslagen, zodat elke collega zijn eigen naam instelt.',
  'Open a note to see its change log.': 'Open een notitie om de log te zien.',
  'Zoom note': 'Zoom notitie',
  'Open a note to zoom it.': 'Open een notitie om in of uit te zoomen.',
  'Zoom in on the note': 'Inzoomen op de notitie',
  'Zoom out of the note': 'Uitzoomen van de notitie',
  'Reset the note zoom': 'Zoom van de notitie herstellen (100%)',
  'Zoom out': 'Uitzoomen',
  'Zoom in': 'Inzoomen',
  'Reset zoom': 'Zoom herstellen (100%)',
  'Command palette': 'Opdrachtenpalet',

  // engine and export
  'The report engine could not start. Is the plugin folder complete (typst.wasm, fonts)? {error}':
    'De rapportengine kon niet starten. Is de pluginmap compleet (typst.wasm, fonts)? {error}',
  'The report engine could not start.': 'De rapportengine kon niet starten.',
  'The report engine stopped; please try again.': 'De rapportengine is gestopt; probeer het opnieuw.',
  'The report engine was stopped.': 'De rapportengine is gestopt.',
  'The report engine stopped unexpectedly: {error}': 'De rapportengine is onverwacht gestopt: {error}',
  'The report engine crashed and will restart.': 'De rapportengine is vastgelopen en start opnieuw.',
  Images: 'Afbeeldingen',
  'One of the images in this report is damaged, so all images are shown as placeholders. Replace the image that was added or changed last.':
    'Een van de afbeeldingen in dit rapport is beschadigd, daarom worden alle afbeeldingen als plaatshouder getoond. Vervang de afbeelding die het laatst is toegevoegd of gewijzigd.',
  'Open a report note first.': 'Open eerst een rapportnotitie.',
  'An export is already running.': 'Er loopt al een export.',
  'The PDF folder in the settings must be a folder inside the vault (no "..", no drive letter).':
    'De PDF-map in de instellingen moet een map in de kluis zijn (geen "..", geen stationsletter).',
  'Exporting report…': 'Rapport wordt geëxporteerd…',
  '{path} is a folder, not a file.': '{path} is een map, geen bestand.',
  'Exported {path}': 'Geëxporteerd: {path}',
  'Exported {path} with {n} problem(s)': 'Geëxporteerd: {path} ({n} melding(en))',
  'Export failed: {error}': 'Exporteren mislukt: {error}',
  'The PDF could not be made': 'De PDF kon niet worden gemaakt',
  '…and {n} more.': '…en nog {n}.',
  '{path} already exists. Replace it?': '{path} bestaat al. Vervangen?',
  Replace: 'Vervangen',
  'This report still has red placeholder text in {n} place(s) (first on line {line}).':
    'Dit rapport bevat nog rode plaatshoudertekst op {n} plek(ken) (eerste op regel {line}).',
  Show: 'Tonen',
  'Export anyway': 'Toch exporteren',
  '{n} place(s) with red placeholder text still to fill in.': 'Nog {n} plek(ken) met rode plaatshoudertekst in te vullen.',
  Cancel: 'Annuleren',

  // settings
  'Starter files': 'Startbestanden',
  'Update layout': 'Opmaak bijwerken',
  'The artwork of the layout was updated; the old files are kept next to them as .bak.': 'De afbeeldingen van de opmaak zijn bijgewerkt; de oude bestanden zijn ernaast bewaard als .bak.',
  'Replaces the layout and its artwork in your vault with the versions from this plugin. Use this after updating the plugin. A backup of each old file is kept next to it.':
    'Vervangt de opmaak en de afbeeldingen ervan in je vault door de versies uit deze plugin. Gebruik dit na het bijwerken van de plugin. Van elk oud bestand blijft een reservekopie ernaast bewaard.',
  'The layout is already up to date.': 'De opmaak is al bijgewerkt.',
  ' Your layout is probably from an older version of the plugin: click "Update layout" in the plugin settings.':
    ' Je opmaak is waarschijnlijk van een oudere versie van de plugin: klik op "Opmaak bijwerken" in de plugin-instellingen.',
  Update: 'Bijwerken',
  'Layout updated. The old layout is kept as {path}.': 'Opmaak bijgewerkt. De oude opmaak is bewaard als {path}.',
  'There is no layout in the vault; the built-in layout is already used.': 'Er staat geen opmaak in de vault; de ingebouwde opmaak wordt al gebruikt.',
  'Install starter files': 'Startbestanden installeren',
  Install: 'Installeren',
  'Created {n} file(s).': '{n} bestand(en) aangemaakt.',
  'All starter files already exist.': 'Alle startbestanden bestaan al.',
  Folders: 'Mappen',
  'Layout file': 'Opmaakbestand',
  'Typst layout in your vault. Its artwork goes in an "assets" folder next to it.':
    'Typst-opmaak in je kluis. De afbeeldingen ervan staan in een map "assets" ernaast.',
  'Not found in the vault, so the built-in layout is used. "Install starter files" creates an editable copy.':
    'Niet gevonden in de kluis, dus de ingebouwde opmaak wordt gebruikt. "Startbestanden installeren" maakt een bewerkbare kopie.',
  'Templates folder': 'Sjablonenmap',
  'Each note in this folder is a report type for "New report". Without notes here the built-in templates are used.':
    'Elke notitie in deze map is een rapporttype voor "Nieuw rapport". Zonder notities hier worden de ingebouwde sjablonen gebruikt.',
  Export: 'Exporteren',
  'PDF folder': 'PDF-map',
  'Vault folder for exported PDFs. Leave empty to save the PDF next to the note.':
    "Map in de kluis voor geëxporteerde PDF's. Laat leeg om de PDF naast de notitie op te slaan.",
  'next to the note': 'naast de notitie',
  'PDF file name': 'PDF-bestandsnaam',
  Preview: 'Voorbeeld',
  'Preview delay': 'Vertraging voorbeeld',
  'How long to wait after you stop typing before the preview updates (milliseconds, 100–5000).':
    'Hoe lang er na het typen wordt gewacht voordat het voorbeeld wordt bijgewerkt (milliseconden, 100–5000).',
  Language: 'Taal',
  'Plugin language': 'Taal van de plugin',
  'Language of the commands, settings and messages of this plugin. Command names change after restarting Obsidian (or turning the plugin off and on).':
    'Taal van de opdrachten, instellingen en meldingen van deze plugin. De namen van de opdrachten veranderen na het herstarten van Obsidian (of de plugin uit- en aanzetten).',

  // preview
  'Report preview': 'Rapportvoorbeeld',
  'Open a report note.': 'Open een rapportnotitie.',
  '{note} is a presentation: the report preview only shows reports.': '{note} is een presentatie: het rapportvoorbeeld toont alleen rapporten.',
  '{note} is a presentation, not a report.': '{note} is een presentatie, geen rapport.',
  '{note} is an ISO template: the report preview only shows reports.': '{note} is een ISO-template of templatepakket: het rapportvoorbeeld toont alleen rapporten.',
  '{note} is an ISO template, not a report.': '{note} is een ISO-template of templatepakket, geen rapport.',
  'Cover image': 'Omslagafbeelding',
  'Export PDF': 'PDF exporteren',
  '{note}: updating…': '{note}: bijwerken…',
  'Report engine': 'Rapportengine',
  '{note}: not updated, see the problems above': '{note}: niet bijgewerkt, zie de meldingen hierboven',
  '{note}: updated {time}': '{note}: bijgewerkt om {time}',
  ' · {n} warning(s)': ' · {n} waarschuwing(en)',
  'Show in the note': 'Toon in de notitie',

  // cover image
  'Cover image: type to search the images in your vault': 'Omslagafbeelding: typ om de afbeeldingen in je kluis te doorzoeken',
  'Choose an image from this computer…': 'Kies een afbeelding van deze computer…',
  '{name} is not a usable image (png, jpg, gif, webp or svg).': '{name} is geen bruikbare afbeelding (png, jpg, gif, webp of svg).',
  'Cover image set to {name}.': 'Omslagafbeelding ingesteld op {name}.',
  'Changing the cover failed: {error}': 'Omslag wijzigen mislukt: {error}',
  '{name} could not be read.': '{name} kon niet worden gelezen.',

  // new client contact

  // new report
  'Document name of the new report': 'Documentnaam van het nieuwe rapport',
  'This becomes the name of the note and of the PDF.': 'Dit wordt de naam van de notitie en van de PDF.',
  Create: 'Aanmaken',
  'The folder "{path}" in the settings must be inside the vault.': 'De map "{path}" in de instellingen moet in de kluis staan.',
  'No report templates found in "{path}".': 'Geen rapportsjablonen gevonden in "{path}".',
  'Created {path}': 'Aangemaakt: {path}',
  'New report failed: {error}': 'Nieuw rapport mislukt: {error}',

  // files
  'No fonts found in {path}.': 'Geen lettertypen gevonden in {path}.',
  '"{path}" must be a path inside the vault (no "..", no drive letter).': '"{path}" moet een pad in de kluis zijn (geen "..", geen stationsletter).',
  '{path} is a file, so it cannot be used as a folder.': '{path} is een bestand en kan dus niet als map worden gebruikt.',

  // problems in the note, the layout and the engine
  'Line {n}': 'Regel {n}',
  Properties: 'Eigenschappen',
  'Layout file {name}, line {n}': 'Opmaakbestand {name}, regel {n}',
  'Layout file {name}': 'Opmaakbestand {name}',
  'An image in the report is damaged and could not be read; replace or remove it ({detail}).':
    'Een afbeelding in het rapport is beschadigd en kon niet worden gelezen; vervang of verwijder deze ({detail}).',
  'A file the layout needs is missing or unreadable ({detail}).': 'Een bestand dat de opmaak nodig heeft ontbreekt of is onleesbaar ({detail}).',
  'A font is missing from the plugin folder ({detail}).': 'Er ontbreekt een lettertype in de pluginmap ({detail}).',
  'The properties at the top of the note could not be read: {error}': 'De eigenschappen bovenaan de notitie konden niet worden gelezen: {error}',
  'Image "{ref}" is not a file in the vault (web addresses and paths outside the vault are not loaded).':
    'Afbeelding "{ref}" is geen bestand in de kluis (webadressen en paden buiten de kluis worden niet geladen).',
  '"{ref}" is not a supported image (png, jpg, gif, svg, webp).': '"{ref}" is geen ondersteunde afbeelding (png, jpg, gif, svg, webp).',
  'Image "{ref}" is damaged or not really an image.': 'Afbeelding "{ref}" is beschadigd of geen echte afbeelding.',
  'Image "{ref}" not found.': 'Afbeelding "{ref}" niet gevonden.',

  // the simple report: cover block, Markdown slider, project folders
  'Add or remove cover page': 'Voorblad toevoegen of verwijderen',
  'Add or remove header block': 'Kop toevoegen of verwijderen',
  Header: 'Kop',
  Contents: 'Inhoud',
  'Add or remove table of contents': 'Inhoudsopgave toevoegen of verwijderen',
  'Table of contents added: it lists the chapters and sections with their page numbers, and updates by itself.': 'Inhoudsopgave toegevoegd: de hoofdstukken en paragrafen met hun paginanummers, die zichzelf bijwerken.',
  'Table of contents removed. Press Ctrl+Z in the note to get it back.': 'Inhoudsopgave verwijderd. Druk op Ctrl+Z in de notitie om hem terug te krijgen.',
  'Changing the table of contents failed: {error}': 'De inhoudsopgave aanpassen is mislukt: {error}',
  'This report has more than one table of contents.': 'Dit rapport heeft meer dan één inhoudsopgave.',
  'Header block added. Its first two lines are the header of the report pages.': "Kop toegevoegd. De eerste twee regels zijn de kop van de pagina's van het rapport.",
  'Header block removed: the header shows the title again. Press Ctrl+Z in the note to get it back.': 'Kop verwijderd: in de kop staat weer de titel. Druk in de notitie op Ctrl+Z om hem terug te halen.',
  'Changing the header failed: {error}': 'De kop wijzigen is mislukt: {error}',
  'This report has more than one header block; only the first one is used.': 'Dit rapport heeft meer dan één kop-blok; alleen het eerste wordt gebruikt.',
  'The header block has more than two lines; only the first two are printed.': 'Het kop-blok heeft meer dan twee regels; alleen de eerste twee komen in het rapport.',
  'Cover page': 'Voorblad',
  'The cover image is damaged, so the standard one is used. Choose another image with "Cover image".':
    'De omslagafbeelding is beschadigd, daarom wordt de standaardafbeelding gebruikt. Kies een andere afbeelding met "Omslagafbeelding".',
  'This layout is from before the simple report, so the built-in layout is used instead. Click "Update layout" in the plugin settings to replace it.':
    'Deze opmaak is van vóór het eenvoudige rapport, daarom wordt de ingebouwde opmaak gebruikt. Klik op "Opmaak bijwerken" in de instellingen van de plugin om hem te vervangen.',
  'This layout is older than the plugin, so newer features may not work. Click "Update layout" in the plugin settings.':
    'Deze opmaak is ouder dan de plugin, dus nieuwere functies werken mogelijk niet. Klik op "Opmaak bijwerken" in de instellingen van de plugin.',
  'Use the standard picture': 'Standaardafbeelding gebruiken',
  'Cover page added at the top of the note. Edit the title and lines there.': 'Voorblad bovenaan de notitie toegevoegd. Pas daar de titel en de regels aan.',
  'Cover page removed. Press Ctrl+Z in the note to get it back.': 'Voorblad verwijderd. Druk in de notitie op Ctrl+Z om het terug te halen.',
  'Changing the cover page failed: {error}': 'Het voorblad wijzigen is mislukt: {error}',
  'Report template': 'Rapportsjabloon',
  'Client project or internal project?': 'Klantproject of intern project?',
  'Folder in {main} (type a new name to create one; "ABC/Audit 2026" makes a folder inside a folder)': 'Map in {main} (typ een nieuwe naam om er een te maken; "ABC/Audit 2026" maakt een map in een map)',
  'Create folder "{name}"': 'Map "{name}" maken',
  'Directly in {main}': 'Direct in {main}',
  'Client project': 'Klantproject',
  'Internal project': 'Intern project',
  'Show the Markdown code (like Notepad++) or the formatted note': 'Toon de Markdown-code (zoals in Notepad++) of de opgemaakte notitie',
  Markdown: 'Markdown',
  'This report has more than one cover block; only the first one is used.': 'Dit rapport heeft meer dan één voorblad; alleen het eerste wordt gebruikt.',
  'The cover block has no title. Write it on a line starting with "> # ".': 'Het voorblad heeft geen titel. Schrijf die op een regel die begint met "> # ".',
  'Copies the layout and the report templates into the folders below. Existing files are never overwritten.':
    'Kopieert de opmaak en de rapportsjablonen naar de mappen hieronder. Bestaande bestanden worden nooit overschreven.',
  'Client projects folder': 'Map klantprojecten',
  '"New report" → Client project makes the report in a folder inside this one (one folder per client or project).':
    '"Nieuw rapport" → Klantproject maakt het rapport in een map binnen deze map (één map per klant of project).',
  'Internal projects folder': 'Map interne projecten',
  '"New report" → Internal project makes the report in a folder inside this one.': '"Nieuw rapport" → Intern project maakt het rapport in een map binnen deze map.',
  'Tokens: {date} (YYYYMMDD), {folder} (the folder the note is in), {title}, {note} (the document name).':
    'Tokens: {date} (JJJJMMDD), {folder} (de map waar de notitie in staat), {title}, {note} (de documentnaam).',
};
