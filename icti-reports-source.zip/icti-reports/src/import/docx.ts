// Word (.docx) report → Markdown body for a report template. Reads the document XML directly: headings, paragraphs,
// bold/italic, highlighted or red text (→ ==placeholder==), lists, tables, links, images and footnotes.
// Left out, because the plugin makes them itself: the cover page (everything before the first chapter; the title and
// subtitle go into the template's cover block) and the table of contents.
// Comments, tracked deletions, hidden text and document properties such as authors are never read into the result;
// only the document's title property is used, when the text has no paragraph in Word's Title style.
import { escapeCell, escapeLineStart, escapeText, runsToMarkdown, type Run } from './md';
import { all, attr, kid, kids, on, parseXml, text, type XNode } from './xml';
import { TOO_LARGE, Zip } from './zip';

export interface DocxImage {
  data: Uint8Array;
  ext: string;
}

export interface DocxResult {
  title: string;
  subtitle: string;
  language: 'nl' | 'en';
  /** Markdown; images are written as `![[\u0000IMG{n}\u0000|width]]`, see fillImages(). */
  body: string;
  /** Images used in the body, by number. */
  images: Map<number, DocxImage>;
  /** Chapters and parts that were left out (for the message after the import). */
  left: string[];
  /** What Markdown cannot hold, e.g. charts. */
  warnings: string[];
}

/** Error texts (English; the import shows them translated). */
export const NOT_WORD = 'this is not a readable Word file (.docx)';

/** Chapters the plugin makes itself: left out of the template. */
export const GENERATED = /^(table of contents|contents|inhoudsopgave|inhoud)$/i;
const TOC_TITLE = /^(table of contents|contents|index|inhoudsopgave|inhoud)$/i;

const R_ID = 'r:id';

interface Style {
  name: string;
  basedOn: string | null;
  outline: string | null;
  numId: string | null;
  ilvl: string | null;
  b?: boolean;
  i?: boolean;
}
type Styles = Map<string, Style>;
interface Level {
  fmt: string;
  text: string;
  start: number;
}
interface Numbering {
  format(numId: string, ilvl: number): string;
  level(numId: string, ilvl: number): Level | null;
  abstractOf(numId: string): string | null;
}
type Rels = Map<string, { target: string; external: boolean }>;
interface Block {
  kind: 'para' | 'list' | 'heading' | 'table';
  md: string;
  level?: number; // headings: 1 = chapter; -1 = document title; -2 = subtitle
  text?: string; // headings: the Markdown of the heading text, without its number
  plain?: string; // headings: the text without Markdown
  numbered?: boolean; // headings: Word numbered it automatically
  dot?: boolean; // that number ended with a dot ("1." rather than "1")
}
interface Ctx {
  zip: Zip;
  styles: Styles;
  numbering: Numbering;
  footnotes: Map<string, XNode[]>;
  rels: Rels;
  counters: Map<string, number[]>;
  listLevel: number;
  images: Map<string, number>; // zip path → number
  imageData: Map<number, DocxImage>;
  warnings: Set<string>;
  coverSkipped: boolean;
}

export async function convertDocx(data: Uint8Array): Promise<DocxResult> {
  let zip: Zip;
  try {
    zip = Zip.open(data);
  } catch (e) {
    throw new Error(e instanceof Error && e.message === TOO_LARGE ? TOO_LARGE : NOT_WORD);
  }
  const docXml = await zip.text('word/document.xml');
  if (!docXml) throw new Error(NOT_WORD);
  const doc = parseXml(docXml);
  const ctx: Ctx = {
    zip,
    styles: readStyles(await zip.text('word/styles.xml')),
    numbering: readNumbering(await zip.text('word/numbering.xml')),
    footnotes: readNotes(await zip.text('word/footnotes.xml')),
    rels: readRels(await zip.text('word/_rels/document.xml.rels')),
    counters: new Map(),
    listLevel: -1,
    images: new Map(),
    imageData: new Map(),
    warnings: new Set(),
    coverSkipped: false,
  };
  if (/<c:chart\b/.test(docXml)) ctx.warnings.add('chart');
  if (/<dgm:relIds\b/.test(docXml)) ctx.warnings.add('smartart');
  if (/<m:oMath\b/.test(docXml)) ctx.warnings.add('equation');

  const blocks = await convertBlocks(kids(kid(doc, 'w:body')), ctx);
  const { kept, cover, left } = selectContent(blocks);

  const title = sensible(cover.find((b) => b.level === -1)?.plain ?? '') || sensible(coreTitle(await zip.text('docProps/core.xml')));
  const subtitle = sensible(cover.find((b) => b.level === -2)?.plain ?? '');
  if (ctx.coverSkipped && !left.includes('cover')) left.unshift('cover');
  const body = joinBlocks(kept);
  // Only the images that stayed in the template.
  const images = new Map<number, DocxImage>();
  for (const m of body.matchAll(/\u0000IMG(\d+)\u0000/g)) {
    const img = ctx.imageData.get(Number(m[1]));
    if (img) images.set(Number(m[1]), img);
  }
  return { title, subtitle, language: guessLanguage(body), body, images, left, warnings: [...ctx.warnings] };
}

/** Replaces the image markers with the names the images got in the vault. */
export function fillImages(body: string, names: Map<number, string>): string {
  return body.replace(/\u0000IMG(\d+)\u0000/g, (_, n: string) => names.get(Number(n)) ?? '');
}

/**
 * The cover is everything before the first chapter (heading 1); chapters the plugin makes itself are left out, as
 * are empty headings. Without any chapter, everything is kept.
 */
export function selectContent(blocks: Block[]): { kept: Block[]; cover: Block[]; left: string[] } {
  const first = blocks.findIndex((b) => b.kind === 'heading' && b.level === 1 && !!b.text?.trim());
  const cover = first > 0 ? blocks.slice(0, first) : first < 0 ? blocks.filter((b) => b.level === -1 || b.level === -2) : [];
  const rest = first >= 0 ? blocks.slice(first) : blocks.filter((b) => b.level !== -1 && b.level !== -2);
  const left: string[] = [];
  if (first > 0) left.push('cover');
  const kept: Block[] = [];
  let skipping = false;
  for (const b of rest) {
    if (b.kind === 'heading' && b.level === 1 && b.plain?.trim()) {
      const name = cleanHeading(b.plain);
      skipping = GENERATED.test(name);
      if (skipping) left.push(name);
    }
    if (skipping) continue;
    if (b.kind === 'heading' && !b.plain?.trim()) continue;
    // A title or subtitle style after the cover becomes an ordinary chapter heading.
    if (b.level === -1 || b.level === -2) kept.push({ ...b, level: 1, text: escapeText(b.plain ?? '') });
    else kept.push(b);
  }
  // Headings Word numbered itself are numbered again, so leaving chapters out leaves no gaps (1, 1.1, 1.2, 2 …).
  const counters: number[] = [];
  for (const b of kept) {
    if (b.kind !== 'heading' || !b.level || b.level < 1) continue;
    let number = '';
    if (b.numbered) {
      counters[b.level - 1] = (counters[b.level - 1] ?? 0) + 1;
      counters.length = b.level;
      number = Array.from({ length: b.level }, (_, i) => counters[i] ?? 1).join('.') + (b.dot ? '.' : '');
    }
    b.md = `${'#'.repeat(b.level)} ${number ? `${escapeText(number)} ` : ''}${b.text ?? ''}`;
  }
  return { kept, cover, left };
}

/** "1.2 Audit details:", "A. Versiebeheer", "Bijlage B: Document control" → the chapter name. */
function cleanHeading(s: string): string {
  return s
    .replace(/^(bijlage|appendix|annex)\s+[a-z0-9]+\s*[:.–-]?\s*/i, '')
    .replace(/^([a-z]|\d+(\.\d+)*)[.)]?\s+/i, '')
    .replace(/[\s:]+$/, '')
    .trim();
}

/** A title or subtitle: one short line, not a placeholder like "<title>" or "[Title]". */
function sensible(s: string): string {
  const t = s.replace(/\s+/g, ' ').trim();
  return t.length >= 3 && t.length <= 120 && !/^[<[].*[>\]]$/.test(t) && !/^(title|titel|subtitle|ondertitel)$/i.test(t) ? t : '';
}

function coreTitle(xml: string | null): string {
  if (!xml) return '';
  try {
    return clean(text(all(parseXml(xml), 'dc:title')[0])).trim();
  } catch {
    return '';
  }
}

/** Control characters never reach the template (they could also fake an image marker). */
// eslint-disable-next-line no-control-regex
const CONTROL = /[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g;
function clean(s: string): string {
  return s.replace(CONTROL, '');
}

/** Dutch or English, by counting common words that only one of the two languages has. */
export function guessLanguage(s: string): 'nl' | 'en' {
  const words = s.toLowerCase().match(/\p{L}+/gu) ?? [];
  const nl = new Set(['de', 'het', 'een', 'van', 'en', 'niet', 'voor', 'met', 'zijn', 'wordt', 'dat', 'deze', 'bij', 'ook', 'naar', 'worden']);
  const en = new Set(['the', 'and', 'of', 'to', 'not', 'for', 'with', 'are', 'that', 'this', 'be', 'by', 'from', 'which', 'should', 'has']);
  let score = 0;
  for (const w of words) score += nl.has(w) ? 1 : en.has(w) ? -1 : 0;
  return score > 0 ? 'nl' : 'en';
}

// ---------- parts of the file ----------

function readRels(xml: string | null): Rels {
  const map: Rels = new Map();
  if (!xml) return map;
  for (const r of all(parseXml(xml), 'Relationship')) map.set(attr(r, 'Id') ?? '', { target: attr(r, 'Target') ?? '', external: attr(r, 'TargetMode') === 'External' });
  return map;
}

function readStyles(xml: string | null): Styles {
  const map: Styles = new Map();
  if (!xml) return map;
  for (const s of kids(parseXml(xml), 'w:style')) {
    const id = attr(s, 'w:styleId') ?? '';
    const ppr = kid(s, 'w:pPr');
    const rpr = kid(s, 'w:rPr');
    map.set(id, {
      name: attr(kid(s, 'w:name'), 'w:val') ?? id,
      basedOn: attr(kid(s, 'w:basedOn'), 'w:val'),
      outline: attr(kid(ppr, 'w:outlineLvl'), 'w:val'),
      numId: attr(kid(kid(ppr, 'w:numPr'), 'w:numId'), 'w:val'),
      ilvl: attr(kid(kid(ppr, 'w:numPr'), 'w:ilvl'), 'w:val'),
      b: kid(rpr, 'w:b') ? on(kid(rpr, 'w:b')) : undefined,
      i: kid(rpr, 'w:i') ? on(kid(rpr, 'w:i')) : undefined,
    });
  }
  return map;
}

/** A style property, following basedOn. */
function styleProp<K extends keyof Style>(styles: Styles, id: string | null | undefined, key: K): Style[K] | undefined {
  let s = id ? styles.get(id) : undefined;
  for (let n = 0; s && n < 20; s = s.basedOn ? styles.get(s.basedOn) : undefined, n++) if (s[key] !== undefined && s[key] !== null) return s[key];
  return undefined;
}

function styleName(styles: Styles, id: string | null): string {
  return id ? (styles.get(id)?.name ?? id).toLowerCase() : '';
}

/** Heading level of a paragraph style: 1 … 6, -1 for the title, -2 for the subtitle, 0 for body text. */
function headingLevel(styles: Styles, id: string | null): number {
  if (!id) return 0;
  const name = styleName(styles, id);
  if (name === 'title') return -1;
  if (name === 'subtitle') return -2;
  const m = /^heading\s*(\d)$/.exec(name);
  if (m) return Math.min(Number(m[1]), 6);
  const o = styleProp(styles, id, 'outline');
  return o !== undefined && o !== null && Number(o) < 6 ? Number(o) + 1 : 0;
}

/** Word's table-of-contents styles: "toc 1" … "toc 9" and "TOC Heading". */
function isTocStyle(styles: Styles, id: string | null): boolean {
  return !!id && /^toc(\s*\d|\s*heading)$/i.test(styles.get(id)?.name ?? id);
}

function readNumbering(xml: string | null): Numbering {
  const abstract = new Map<string, Map<string, Level>>();
  const nums = new Map<string, string>();
  if (xml) {
    const root = parseXml(xml);
    for (const a of kids(root, 'w:abstractNum')) {
      const lvls = new Map<string, Level>();
      for (const l of kids(a, 'w:lvl')) lvls.set(attr(l, 'w:ilvl') ?? '0', { fmt: attr(kid(l, 'w:numFmt'), 'w:val') ?? 'bullet', text: attr(kid(l, 'w:lvlText'), 'w:val') ?? '', start: Number(attr(kid(l, 'w:start'), 'w:val') ?? 1) });
      abstract.set(attr(a, 'w:abstractNumId') ?? '', lvls);
    }
    for (const n of kids(root, 'w:num')) nums.set(attr(n, 'w:numId') ?? '', attr(kid(n, 'w:abstractNumId'), 'w:val') ?? '');
  }
  const level = (numId: string, ilvl: number) => abstract.get(nums.get(numId) ?? '')?.get(String(ilvl)) ?? null;
  return { format: (numId, ilvl) => level(numId, ilvl)?.fmt ?? 'bullet', level, abstractOf: (numId) => nums.get(numId) ?? null };
}

function readNotes(xml: string | null): Map<string, XNode[]> {
  const map = new Map<string, XNode[]>();
  if (!xml) return map;
  for (const n of kids(parseXml(xml), 'w:footnote')) {
    if (attr(n, 'w:type')) continue; // separators
    map.set(attr(n, 'w:id') ?? '', kids(n, 'w:p'));
  }
  return map;
}

// ---------- blocks ----------

/** A content control holding Word's cover page or table of contents: left out as a whole. */
function isGeneratedControl(sdt: XNode): boolean {
  return /^(cover pages|table of contents)$/i.test(gallery(sdt));
}

function gallery(sdt: XNode): string {
  return attr(kid(kid(kid(sdt, 'w:sdtPr'), 'w:docPartObj'), 'w:docPartGallery'), 'w:val') ?? '';
}

async function convertBlocks(nodes: XNode[], ctx: Ctx): Promise<Block[]> {
  const out: Block[] = [];
  for (const n of nodes) {
    if (n.nodeName === 'w:p') {
      if (isTocTitle(n, ctx.styles)) continue;
      const b = await convertParagraph(n, ctx);
      if (!b) continue;
      // A title over several lines on the cover: one title.
      const prev = out[out.length - 1];
      if (b.level === -1 && prev?.level === -1) {
        prev.plain = `${prev.plain} ${b.plain}`;
        continue;
      }
      out.push(b);
    } else if (n.nodeName === 'w:tbl') {
      const md = await convertTable(n, ctx);
      if (md) out.push({ kind: 'table', md });
      ctx.listLevel = -1;
    } else if (n.nodeName === 'w:sdt') {
      if (!isGeneratedControl(n)) out.push(...(await convertBlocks(kids(kid(n, 'w:sdtContent')), ctx)));
      else if (/cover/i.test(gallery(n))) ctx.coverSkipped = true;
    } else if (n.nodeName === 'w:customXml' || n.nodeName === 'w:ins') out.push(...(await convertBlocks(kids(n), ctx)));
  }
  return out;
}

/** The heading above a table of contents, when the next paragraph is part of the table of contents. */
function isTocTitle(p: XNode, styles: Styles): boolean {
  const own = all(p, 'w:t').map((t) => text(t)).join('').replace(/[\s :]+$/u, '').trim();
  if (!TOC_TITLE.test(own)) return false;
  let next = p.nextSibling;
  while (next && next.nodeType !== 1) next = next.nextSibling;
  if (!next) return false;
  if (next.nodeName === 'w:sdt') return isGeneratedControl(next);
  if (next.nodeName !== 'w:p') return false;
  return isTocStyle(styles, attr(kid(kid(next, 'w:pPr'), 'w:pStyle'), 'w:val')) || all(next, 'w:instrText').some((i) => /^\s*TOC\b/.test(text(i)));
}

async function convertParagraph(p: XNode, ctx: Ctx): Promise<Block | null> {
  const ppr = kid(p, 'w:pPr');
  const styleId = attr(kid(ppr, 'w:pStyle'), 'w:val');
  if (isTocStyle(ctx.styles, styleId)) return null;
  const style = { b: styleProp(ctx.styles, styleId, 'b'), i: styleProp(ctx.styles, styleId, 'i') };
  const { runs } = await paragraphRuns(p, ctx, style);
  const md = runsToMarkdown(runs).replace(/[ \t]+$/gm, '').trim();
  let level = headingLevel(ctx.styles, styleId);
  if (!md) {
    // An empty heading 1 still marks where a chapter starts (and so where the cover ends).
    return level === 1 ? { kind: 'heading', level: 1, text: '', plain: '', md: '' } : null;
  }

  // Numbering: the paragraph's own, else its style's.
  const numPr = kid(ppr, 'w:numPr');
  let numId = attr(kid(numPr, 'w:numId'), 'w:val') ?? styleProp(ctx.styles, styleId, 'numId') ?? null;
  let ilvl = Number(attr(kid(numPr, 'w:ilvl'), 'w:val') ?? styleProp(ctx.styles, styleId, 'ilvl') ?? 0);
  if (numId === '0') numId = null;
  const number = numId ? count(ctx, numId, ilvl) : '';

  if (level && /^(!\[\[\u0000IMG\d+\u0000[^\]]*\]\]\s*)+$/.test(md)) level = 0;
  if (level) {
    ctx.listLevel = -1;
    const head = unbold(md.split(BR).map((x) => x.trim()).filter(Boolean).join(' '));
    const plain = plainText(runs);
    if (level < 0) return { kind: 'heading', level, text: escapeText(plain), plain, md: escapeText(plain) };
    return { kind: 'heading', level, text: head, plain, numbered: !!number, dot: number.endsWith('.'), md: `${'#'.repeat(level)} ${head}` };
  }

  if (numId) {
    const fmt = ctx.numbering.format(numId, ilvl);
    const marker = fmt === 'bullet' || fmt === 'none' ? '-' : '1.';
    // A list that jumps two levels deeper would become a code block in Markdown.
    ilvl = Math.min(ilvl, ctx.listLevel + 1);
    ctx.listLevel = ilvl;
    const indent = `${'\t'.repeat(ilvl)}${' '.repeat(marker.length + 1)}`;
    return { kind: 'list', md: `${'\t'.repeat(ilvl)}${marker} ${hardBreaks(escapeLineStart(md), indent)}` };
  }
  ctx.listLevel = -1;
  return { kind: 'para', md: hardBreaks(escapeLineStart(md), '') };
}

const BR = '\u0001'; // a line break inside a paragraph (control characters are removed from the text itself)

/**
 * Line breaks inside a paragraph (Shift+Enter in Word): a Markdown hard break, a backslash at the end of the line.
 * Each new line is escaped like a line start ("- item" must not become a list) and indented inside a list item.
 */
function hardBreaks(md: string, indent: string): string {
  const lines = md.split(BR).map((x) => x.trim());
  while (lines.length > 1 && !lines[lines.length - 1]) lines.pop();
  let out = lines[0];
  for (let i = 1; i < lines.length; i++) {
    if (!lines[i]) continue;
    const gap = !lines[i - 1] && !indent; // after an empty line, outside lists: a new paragraph
    out += (gap ? '\n\n' : '\\\n') + indent + escapeLineStart(lines[i]);
  }
  return out;
}

/** The text of runs without Markdown (for the title and subtitle properties). */
function plainText(runs: Run[]): string {
  return runs.map((r) => r.text ?? (r.raw === BR ? ' ' : '')).join('').replace(/\s+/g, ' ').trim();
}

/** The number Word shows for this paragraph ("2.1"); "" for bullets and unnumbered levels. */
function count(ctx: Ctx, numId: string, ilvl: number): string {
  const key = ctx.numbering.abstractOf(numId) ?? numId;
  const counters = ctx.counters.get(key) ?? [];
  const lvl = ctx.numbering.level(numId, ilvl);
  counters[ilvl] = (counters[ilvl] ?? (lvl?.start ?? 1) - 1) + 1;
  counters.length = ilvl + 1;
  ctx.counters.set(key, counters);
  if (!lvl || lvl.fmt === 'bullet' || lvl.fmt === 'none' || !lvl.text) return '';
  return lvl.text
    .replace(/%(\d)/g, (_, n: string) => {
      const i = Number(n) - 1;
      const v = counters[i] ?? ctx.numbering.level(numId, i)?.start ?? 1;
      const fmt = ctx.numbering.level(numId, i)?.fmt;
      if (fmt === 'lowerLetter') return String.fromCharCode(96 + v);
      if (fmt === 'upperLetter') return String.fromCharCode(64 + v);
      if (fmt === 'lowerRoman' || fmt === 'upperRoman') {
        const r = roman(v);
        return fmt === 'lowerRoman' ? r.toLowerCase() : r;
      }
      return String(v);
    })
    .trim();
}

function roman(n: number): string {
  const map: [number, string][] = [[1000, 'M'], [900, 'CM'], [500, 'D'], [400, 'CD'], [100, 'C'], [90, 'XC'], [50, 'L'], [40, 'XL'], [10, 'X'], [9, 'IX'], [5, 'V'], [4, 'IV'], [1, 'I']];
  let out = '';
  for (const [v, r] of map) while (n >= v) {
    out += r;
    n -= v;
  }
  return out;
}

/** Headings are bold already: "**Scope**" → "Scope". */
function unbold(md: string): string {
  const m = /^\*\*([^*]+)\*\*$/.exec(md);
  return m ? m[1] : md;
}

/** Red text is a placeholder in ICT Institute documents, like highlighted text. */
function isRed(hex: string | null): boolean {
  if (!hex || !/^[0-9a-f]{6}$/i.test(hex)) return false;
  const [r, g, b] = [0, 2, 4].map((i) => parseInt(hex.slice(i, i + 2), 16));
  return r >= 0xb0 && g <= 0x50 && b <= 0x50;
}

/** Runs of a paragraph, following hyperlinks, fields, insertions and content controls. */
async function paragraphRuns(p: XNode, ctx: Ctx, style: { b?: boolean; i?: boolean }): Promise<{ runs: Run[] }> {
  const runs: Run[] = [];
  const fields: { inInstr: boolean; instr: string; link?: string }[] = [];
  const fieldLink = () => fields.find((f) => f.link)?.link;
  const inInstr = () => fields.some((f) => f.inInstr);
  const walk = async (el: XNode | null, link: string | null): Promise<void> => {
    for (const n of kids(el)) {
      switch (n.nodeName) {
        case 'w:r':
          await run(n, link);
          break;
        case 'w:hyperlink': {
          const id = attr(n, R_ID);
          const target = id ? ctx.rels.get(id)?.target : null;
          await walk(n, target && /^(https?:|mailto:)/i.test(target) ? target : link);
          break;
        }
        case 'w:fldSimple': {
          const m = /HYPERLINK\s+"([^"]+)"/.exec(attr(n, 'w:instr') ?? '');
          await walk(n, m && /^(https?:|mailto:)/i.test(m[1]) ? m[1] : link);
          break;
        }
        case 'w:ins': case 'w:moveTo': case 'w:smartTag': case 'w:customXml': case 'w:dir': case 'w:bdo':
          await walk(n, link);
          break;
        case 'w:sdt':
          await walk(kid(n, 'w:sdtContent'), link);
          break;
        default:
          break; // deletions, comments, bookmarks, proofing marks
      }
    }
  };
  const run = async (r: XNode, link: string | null): Promise<void> => {
    const rpr = kid(r, 'w:rPr');
    if (kid(rpr, 'w:vanish') && on(kid(rpr, 'w:vanish'))) return;
    const rStyle = attr(kid(rpr, 'w:rStyle'), 'w:val');
    const pick = (tag: string, key: 'b' | 'i') => (kid(rpr, tag) ? on(kid(rpr, tag)) : styleProp(ctx.styles, rStyle, key) ?? style[key] ?? false);
    const highlight = attr(kid(rpr, 'w:highlight'), 'w:val');
    const shade = attr(kid(rpr, 'w:shd'), 'w:fill');
    const look: Run = {
      b: pick('w:b', 'b'),
      i: pick('w:i', 'i'),
      mark: (!!highlight && highlight !== 'none') || (!!shade && /^ffff00$/i.test(shade)) || isRed(attr(kid(rpr, 'w:color'), 'w:val')),
    };
    for (const c of kids(r)) {
      switch (c.nodeName) {
        case 'w:fldChar': {
          const type = attr(c, 'w:fldCharType');
          if (type === 'begin') fields.push({ inInstr: true, instr: '' });
          else if (type === 'separate' && fields.length) {
            const f = fields[fields.length - 1];
            f.inInstr = false;
            const m = /HYPERLINK\s+"([^"]+)"/.exec(f.instr);
            if (m && /^(https?:|mailto:)/i.test(m[1])) f.link = m[1];
          } else if (type === 'end') fields.pop();
          break;
        }
        case 'w:instrText':
          if (fields.length) fields[fields.length - 1].instr += text(c);
          break;
        case 'w:t': {
          if (inInstr()) break;
          const t = clean(text(c));
          runs.push({ ...look, link: fieldLink() ?? link, text: t });
          break;
        }
        case 'w:tab': case 'w:ptab':
          if (!inInstr()) runs.push({ ...look, text: ' ' });
          break;
        case 'w:br': case 'w:cr':
          if (attr(c, 'w:type') !== 'page' && attr(c, 'w:type') !== 'column') runs.push({ raw: BR });
          break;
        case 'w:noBreakHyphen':
          runs.push({ ...look, text: '-' });
          break;
        case 'w:sym':
          runs.push({ ...look, text: symbol(attr(c, 'w:char')) });
          break;
        case 'w:footnoteReference': {
          // The footnote's text in brackets where it is referenced (the report layout has no footnotes).
          const parts: string[] = [];
          for (const fp of ctx.footnotes.get(attr(c, 'w:id') ?? '') ?? []) parts.push(runsToMarkdown((await paragraphRuns(fp, ctx, {})).runs).trim());
          const note = parts.filter(Boolean).join(' ');
          if (note) runs.push({ raw: ` (${note})` });
          break;
        }
        case 'w:drawing': case 'w:pict': case 'mc:AlternateContent': {
          const blip = all(c, 'a:blip')[0] ?? all(c, 'v:imagedata')[0];
          const id = blip ? attr(blip, 'r:embed') ?? attr(blip, R_ID) : null;
          if (id) {
            const img = await image(ctx, id, c);
            if (img) runs.push({ raw: img });
          } else {
            const box = all(c, 'w:txbxContent')[0];
            // Text boxes: their text inline (the older copy in mc:Fallback is skipped).
            if (box && !inFallback(box)) {
              for (const tp of kids(box, 'w:p')) {
                const inner = await paragraphRuns(tp, ctx, style);
                runs.push(...inner.runs, { raw: BR });
              }
            }
          }
          break;
        }
        default:
          break;
      }
    }
  };
  await walk(p, null);
  while (runs.length && runs[runs.length - 1].raw === BR) runs.pop();
  while (runs.length && runs[0].raw === BR) runs.shift();
  return { runs };
}

function inFallback(el: XNode): boolean {
  for (let n = el.parentNode; n; n = n.parentNode) if (n.nodeName === 'mc:Fallback') return true;
  return false;
}

/** An embedded picture: kept as a marker (named later), with its width in pixels when Word gives one. */
async function image(ctx: Ctx, relId: string, drawing: XNode): Promise<string> {
  const rel = ctx.rels.get(relId);
  if (!rel || rel.external) return ''; // linked pictures (web addresses) are never loaded
  const path = resolve('word', rel.target);
  let n = ctx.images.get(path);
  if (n === undefined) {
    const data = await ctx.zip.bytes(path);
    const ext = data ? imageExt(data) : null;
    if (!data || !ext) {
      ctx.warnings.add('image');
      return '';
    }
    n = ctx.images.size + 1;
    ctx.images.set(path, n);
    ctx.imageData.set(n, { data, ext });
  }
  const cx = Number(attr(all(drawing, 'wp:extent')[0], 'cx') ?? 0);
  const width = cx > 0 ? Math.min(Math.round(cx / 9525), 700) : 0;
  return `![[\u0000IMG${n}\u0000${width ? `|${width}` : ''}]]`;
}

/** The image format from the first bytes (only formats the report can show). */
function imageExt(b: Uint8Array): string | null {
  if (b.length > 8 && b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47) return 'png';
  if (b.length > 3 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return 'jpg';
  if (b.length > 6 && b[0] === 0x47 && b[1] === 0x49 && b[2] === 0x46) return 'gif';
  if (b.length > 12 && String.fromCharCode(...b.subarray(0, 4)) === 'RIFF' && String.fromCharCode(...b.subarray(8, 12)) === 'WEBP') return 'webp';
  return null; // emf/wmf and others cannot be shown
}

function resolve(dir: string, target: string): string {
  if (target.startsWith('/')) return target.slice(1);
  const parts = dir.split('/');
  for (const p of target.split('/')) {
    if (p === '..') parts.pop();
    else if (p !== '.') parts.push(p);
  }
  return parts.join('/');
}

function symbol(hex: string | null): string {
  const c = parseInt(hex ?? '', 16);
  const known: Record<number, string> = { 0xf0b7: '•', 0xf0a7: '▪', 0xf0fc: '✓', 0xf06f: '☐', 0xf0a8: '☐', 0xf0fe: '☒' };
  return known[c] ?? (c ? String.fromCharCode(c > 0xf000 ? c - 0xf000 : c) : '');
}

// ---------- tables ----------

async function convertTable(tbl: XNode, ctx: Ctx): Promise<string> {
  const rows: string[][] = [];
  for (const tr of flat(tbl, 'w:tr')) {
    const row: string[] = [];
    for (const tc of flat(tr, 'w:tc')) {
      const tcpr = kid(tc, 'w:tcPr');
      const span = Number(attr(kid(tcpr, 'w:gridSpan'), 'w:val') ?? 1);
      const vMerge = kid(tcpr, 'w:vMerge');
      const continued = !!vMerge && attr(vMerge, 'w:val') !== 'restart';
      let cell = '';
      if (!continued) {
        const parts: string[] = [];
        for (const b of await convertBlocks(kids(tc), ctx)) {
          if (b.kind === 'table') {
            parts.push(b.md.replace(/\n/g, '<br>'));
            continue;
          }
          // In a table cell a line break is <br> (a backslash line end would end the table row).
          let s = b.md.replace(/^#+ /, '').replace(/\\\n[\t ]*|\n+/g, '<br>');
          if (b.kind === 'heading') s = `**${b.text ?? s}**`;
          if (b.kind === 'list') s = s.replace(/^(\t*)(-|1\.) /, (_, tabs: string, m: string) => `${'  '.repeat(tabs.length)}${m === '-' ? '•' : '–'} `);
          if (s) parts.push(s);
        }
        cell = escapeCell(parts.join('<br>'));
      }
      row.push(cell);
      for (let i = 1; i < span; i++) row.push('');
    }
    rows.push(row);
  }
  ctx.listLevel = -1;
  if (!rows.length) return '';
  const width = Math.max(...rows.map((r) => r.length), 1);
  const line = (r: string[]) => `| ${Array.from({ length: width }, (_, i) => r[i] ?? '').join(' | ')} |`;
  return [line(rows[0]), `|${' --- |'.repeat(width)}`, ...rows.slice(1).map(line)].join('\n');
}

/** Children with this name, looking through content controls (w:sdt) and custom XML. */
function flat(el: XNode | null, name: string): XNode[] {
  const out: XNode[] = [];
  for (const n of kids(el)) {
    if (n.nodeName === name) out.push(n);
    else if (n.nodeName === 'w:sdt') out.push(...flat(kid(n, 'w:sdtContent'), name));
    else if (n.nodeName === 'w:customXml' || n.nodeName === 'w:ins') out.push(...flat(n, name));
  }
  return out;
}

/** Blank lines between blocks, except between items of the same list. */
function joinBlocks(blocks: Block[]): string {
  let out = '';
  let prev: Block | null = null;
  for (const b of blocks) {
    if (!b.md) continue;
    if (prev) out += prev.kind === 'list' && b.kind === 'list' ? '\n' : '\n\n';
    out += b.md;
    prev = b;
  }
  return out;
}
