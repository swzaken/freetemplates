// The report template made from an imported Word report, like the built-in "Simple report" / "Eenvoudig rapport":
// a cover block with the Word report's title, subtitle and the date, a header block, a table of contents written in
// Markdown (made once from the headings; Word's own table of contents is left out), then its text.
// "New report" fills in the {{tokens}} later, like in every template.
import { escapeText } from './md';

export interface ImportedTemplate {
  title: string;
  subtitle: string;
  language: 'nl' | 'en';
  body: string;
}

/** "{{" in imported text must not become a token that New report fills in. */
function noTokens(s: string): string {
  return s.replace(/\{\{/g, '{ {').replace(/\}\}/g, '} }');
}

/** One line of the cover block: Markdown characters escaped, on one line. */
function coverLine(s: string): string {
  return escapeText(noTokens(s.replace(/[\r\n\t]+/g, ' ').trim()));
}

export function templateNote(t: ImportedTemplate): string {
  const title = coverLine(t.title);
  const subtitle = coverLine(t.subtitle);
  const lines = [
    ...(t.language === 'nl' ? ['---', 'language: nl', '---', ''] : []),
    '> [!cover]',
    `> # ${title || '{{title}}'}`,
    ...(subtitle ? [`> ${subtitle}`] : []),
    '> {{long_date}}',
    '',
    '> [!header]',
    '> Project: {{title}}',
    `> Document: ${title || (t.language === 'nl' ? 'Rapport' : 'Report')}`,
    '',
    // The automatic table of contents (only when the document has headings), on its own page.
    ...(/^#{1,2}\s/m.test(t.body) ? [t.language === 'nl' ? '> [!inhoud]' : '> [!contents]', '', '\\pagebreak', ''] : []),
    t.body.trim(),
    '',
  ];
  return lines.join('\n');
}

/** A safe file name for the template (and its images) from the Word file's name. */
export function templateBaseName(fileName: string): string {
  // eslint-disable-next-line no-control-regex
  const base = fileName.replace(/\.docx$/i, '').replace(/[<>:"/\\|?*#^[\]{}\u0000-\u001f]/g, ' ').replace(/\s+/g, ' ').trim();
  const name = base.replace(/^[ .]+/, '').replace(/[ .]+$/, '').slice(0, 100) || 'Word-rapport';
  // Names Windows reserves for devices (CON, NUL, COM1 …) cannot be files.
  return /^(con|prn|aux|nul|com\d|lpt\d)(\..*)?$/i.test(name) ? `Word-rapport ${name}` : name;
}
