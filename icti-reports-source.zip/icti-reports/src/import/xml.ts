// Small helpers over @xmldom/xmldom for reading Word's XML. A pure-JavaScript parser: it never loads external
// entities or DTDs, and behaves the same in Obsidian and in the tests.
import { DOMParser } from '@xmldom/xmldom';

/** The few DOM members the import uses. */
export interface XNode {
  nodeType: number;
  nodeName: string;
  firstChild: XNode | null;
  nextSibling: XNode | null;
  parentNode: XNode | null;
  textContent: string | null;
  getAttribute(name: string): string | null;
  getElementsByTagName(name: string): ArrayLike<XNode>;
}

export function parseXml(text: string): XNode {
  const doc = new DOMParser({ onError: () => {} }).parseFromString(text, 'text/xml');
  const root = doc.documentElement as unknown as XNode | null;
  if (!root) throw new Error('unreadable XML');
  return root;
}

/** Element children, optionally only those with this qualified name (e.g. "w:p"). */
export function kids(el: XNode | null | undefined, name?: string): XNode[] {
  const out: XNode[] = [];
  for (let n = el?.firstChild ?? null; n; n = n.nextSibling) if (n.nodeType === 1 && (!name || n.nodeName === name)) out.push(n);
  return out;
}

export function kid(el: XNode | null | undefined, name: string): XNode | null {
  for (let n = el?.firstChild ?? null; n; n = n.nextSibling) if (n.nodeType === 1 && n.nodeName === name) return n;
  return null;
}

/** All descendants with this qualified name, in document order. */
export function all(el: XNode | null | undefined, name: string): XNode[] {
  return el ? Array.from(el.getElementsByTagName(name)) : [];
}

export function attr(el: XNode | null | undefined, name: string): string | null {
  return el?.getAttribute(name) ?? null;
}

/** Word's on/off properties: <w:b/> is on, <w:b w:val="0"/> or "false" is off. */
export function on(el: XNode | null | undefined): boolean {
  if (!el) return false;
  const v = attr(el, 'w:val');
  return v === null || !/^(0|false|off|none)$/i.test(v);
}

export function text(el: XNode | null | undefined): string {
  return el?.textContent ?? '';
}
