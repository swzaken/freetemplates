// A small reader for zip files (a .docx is a zip). Only what Word writes: stored or deflated entries, read through
// the central directory. Deflate uses the platform's DecompressionStream (Obsidian/Electron and Node), so no library
// and no network are needed. Sizes are checked so a damaged or hostile file cannot make us inflate gigabytes.

// Limits far above real reports, low enough that Obsidian cannot run out of memory: the XML parts are parsed in
// one go (a 30 MB document.xml is thousands of pages), pictures are only copied.
const MAX_XML = 30 * 1024 * 1024;
const MAX_ENTRY = 100 * 1024 * 1024;
const MAX_TOTAL = 250 * 1024 * 1024;

/** Error texts (English; the import shows them translated). */
export const TOO_LARGE = 'the Word file is too large to import';
export const DAMAGED = 'the Word file is damaged';

export interface ZipEntry {
  name: string;
  method: number;
  compressedSize: number;
  size: number;
  offset: number; // of the local header
}

export class Zip {
  private constructor(private data: Uint8Array, readonly entries: Map<string, ZipEntry>) {}

  static open(data: Uint8Array): Zip {
    const view = new DataView(data.buffer, data.byteOffset, data.byteLength);
    // The end-of-central-directory record is in the last 64 KiB + 22 bytes.
    let eocd = -1;
    for (let i = data.length - 22; i >= Math.max(0, data.length - 22 - 0xffff); i--) {
      if (view.getUint32(i, true) === 0x06054b50) {
        eocd = i;
        break;
      }
    }
    if (eocd < 0) throw new Error(DAMAGED);
    const count = view.getUint16(eocd + 10, true);
    let p = view.getUint32(eocd + 16, true);
    const entries = new Map<string, ZipEntry>();
    let total = 0;
    for (let n = 0; n < count; n++) {
      if (p + 46 > data.length || view.getUint32(p, true) !== 0x02014b50) throw new Error(DAMAGED);
      const method = view.getUint16(p + 10, true);
      const compressedSize = view.getUint32(p + 20, true);
      const size = view.getUint32(p + 24, true);
      const nameLen = view.getUint16(p + 28, true);
      const extraLen = view.getUint16(p + 30, true);
      const commentLen = view.getUint16(p + 32, true);
      const offset = view.getUint32(p + 42, true);
      const name = new TextDecoder().decode(data.subarray(p + 46, p + 46 + nameLen));
      const max = /\.(xml|rels)$/i.test(name) ? MAX_XML : MAX_ENTRY;
      if (size > max || (total += size) > MAX_TOTAL) throw new Error(TOO_LARGE);
      entries.set(name, { name, method, compressedSize, size, offset });
      p += 46 + nameLen + extraLen + commentLen;
    }
    return new Zip(data, entries);
  }

  has(name: string): boolean {
    return this.entries.has(name);
  }

  async bytes(name: string): Promise<Uint8Array | null> {
    const e = this.entries.get(name);
    if (!e) return null;
    const view = new DataView(this.data.buffer, this.data.byteOffset, this.data.byteLength);
    if (e.offset + 30 > this.data.length || view.getUint32(e.offset, true) !== 0x04034b50) throw new Error(DAMAGED);
    const start = e.offset + 30 + view.getUint16(e.offset + 26, true) + view.getUint16(e.offset + 28, true);
    const raw = this.data.subarray(start, start + e.compressedSize);
    if (raw.length !== e.compressedSize) throw new Error(DAMAGED);
    if (e.method === 0) return raw;
    if (e.method !== 8) throw new Error(DAMAGED);
    const out = await inflate(raw, e.size);
    if (out.length !== e.size) throw new Error(DAMAGED);
    return out;
  }

  async text(name: string): Promise<string | null> {
    const b = await this.bytes(name);
    return b ? new TextDecoder().decode(b) : null;
  }
}

async function inflate(raw: Uint8Array, expected: number): Promise<Uint8Array> {
  const stream = new Blob([raw as BlobPart]).stream().pipeThrough(new DecompressionStream('deflate-raw'));
  const reader = stream.getReader();
  const parts: Uint8Array[] = [];
  let length = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    length += value.length;
    if (length > expected) {
      await reader.cancel();
      throw new Error(DAMAGED);
    }
    parts.push(value);
  }
  const out = new Uint8Array(length);
  let o = 0;
  for (const part of parts) {
    out.set(part, o);
    o += part.length;
  }
  return out;
}
