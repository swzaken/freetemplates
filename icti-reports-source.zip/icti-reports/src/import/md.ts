// Markdown output for the Word import: escaping text so it shows literally, and inline formatting from runs.
// (Same rules as the ISO template converter of ICT Institute Templates.)

/**
 * Escapes every character that Markdown or Obsidian could read as markup, each one on its own: emphasis, code,
 * math ($), tags (#), HTML (<), entities (&), highlights (=), strike-through (~), links and embeds ([ ]), comments
 * (%), the report's own markers (\findings, \pagebreak) and template tokens ({ }). Escaping single characters (not
 * pairs) matters: text is escaped in pieces (per bold/italic group), and two harmless halves must not form "{{" or
 * "[[" when they are joined.
 */
export function escapeText(s: string): string {
  return s.replace(/[\\`*_{}[\]<#=%~$&]/g, (c) => '\\' + c);
}

/**
 * At the start of a line: list markers, block quotes, numbered-list look-alikes, horizontal rules ("---") and link
 * reference definitions ("[X]: …") are escaped too.
 */
export function escapeLineStart(s: string): string {
  return s
    .replace(/^(\s*)([-+>])(\s|$)/, '$1\\$2$3')
    .replace(/^(\s*)(\d+)([.)])(\s|$)/, '$1$2\\$3$4')
    .replace(/^(\s*)([-=])(?=(?:\s*[-=]){2,}\s*$)/, '$1\\$2')
    .replace(/^(\s*)\[(?=[^\]\n]*\]:)/, '$1\\[');
}

/** In table cells: also the cell separator. */
export function escapeCell(s: string): string {
  return s.replace(/\|/g, '\\|');
}

export interface Run {
  text?: string;
  raw?: string; // already Markdown (an image, a line break)
  b?: boolean;
  i?: boolean;
  mark?: boolean;
  link?: string | null;
}

const isSpace = (c: string | undefined) => !c || /\s/u.test(c);
const isPunct = (c: string | undefined) => !!c && /[\p{P}\p{S}]/u.test(c);
const DELIM = { b: '**', i: '*', mark: '==' } as const;
type Layer = keyof typeof DELIM;

/**
 * Runs → Markdown. Bold, italic and highlight are nested (bold outside). Spaces stay outside the markers, and a
 * marker is only written where Markdown reads it as one (CommonMark's flanking rule); elsewhere the formatting is
 * left out rather than shown as stray characters.
 */
export function runsToMarkdown(runs: Run[]): string {
  const items = runs.filter((r) => r.raw !== undefined || r.text);
  return renderLayer(items, ['b', 'i', 'mark'], '', '');
}

function renderLayer(items: Run[], layers: Layer[], before: string, after: string): string {
  if (!layers.length) return renderPlain(items);
  const [key, ...rest] = layers;
  const groups: { on: boolean; items: Run[] }[] = [];
  for (const it of items) {
    const on = it.raw === undefined && !!it[key];
    const last = groups[groups.length - 1];
    if (last && last.on === on) last.items.push(it);
    else groups.push({ on, items: [it] });
  }
  const inner = groups.map((g) => renderLayer(g.items, rest, '', ''));
  let out = '';
  for (let i = 0; i < groups.length; i++) {
    const text = inner[i];
    if (!groups[i].on) {
      out += text;
      continue;
    }
    const [, lead, core, trail] = /^(\s*)([\s\S]*?)(\s*)$/.exec(text)!;
    if (!core) {
      out += text;
      continue;
    }
    const prev = lead ? ' ' : i > 0 ? inner[i - 1].slice(-1) : before;
    const next = trail ? ' ' : i < groups.length - 1 ? inner[i + 1].slice(0, 1) : after;
    const first = core[0];
    const last = core[core.length - 1];
    const opens = !isSpace(first) && (!isPunct(first) || isSpace(prev) || isPunct(prev));
    const closes = !isSpace(last) && (!isPunct(last) || isSpace(next) || isPunct(next));
    out += opens && closes ? `${lead}${DELIM[key]}${core}${DELIM[key]}${trail}` : text;
  }
  return out;
}

/** Text and links: text escaped; a link whose text is its own address becomes the bare address. */
function renderPlain(items: Run[]): string {
  const merged: Run[] = [];
  for (const it of items) {
    const last = merged[merged.length - 1];
    if (it.raw === undefined && last && last.raw === undefined && last.link === it.link) last.text = (last.text ?? '') + (it.text ?? '');
    else merged.push({ ...it });
  }
  return merged
    .map((it) => {
      if (it.raw !== undefined) return it.raw;
      const text = it.text ?? '';
      if (!it.link) return escapeText(text);
      const [, lead, core, trail] = /^(\s*)([\s\S]*?)(\s*)$/.exec(text)!;
      if (!core) return text;
      // Always [text](address): the report's Markdown does not turn bare addresses into links.
      return `${lead}[${escapeText(core)}](${linkTarget(it.link)})${trail}`;
    })
    .join('');
}

/** A link address inside (…): brackets, braces, backslashes, spaces and the table separator percent-encoded. */
export function linkTarget(url: string): string {
  return url.replace(/[()\s|<>{}\\`[\]]/g, (c) => `%${c.charCodeAt(0).toString(16).toUpperCase().padStart(2, '0')}`);
}
