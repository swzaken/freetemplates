// Web Worker: owns the Typst engine so compiling never blocks Obsidian's editor.
// Bundled separately and started from a Blob URL by client.ts.
import { TypstEngine, type CompileResult } from './typst';

export type WorkerRequest =
  | { type: 'init'; wasm: ArrayBuffer; fonts: ArrayBuffer[] }
  | { type: 'compile'; id: number; files: Record<string, Uint8Array | string> };

export type WorkerResponse =
  | { type: 'ready' }
  | { type: 'init-error'; message: string }
  | ({ type: 'result'; id: number; fatal: boolean } & CompileResult);

declare const self: DedicatedWorkerGlobalScope;
let engine: TypstEngine | null = null;

self.onmessage = async (e: MessageEvent<WorkerRequest>) => {
  const msg = e.data;
  if (msg.type === 'init') {
    try {
      engine = await TypstEngine.create(msg.wasm, msg.fonts.map((f) => new Uint8Array(f)));
      self.postMessage({ type: 'ready' } satisfies WorkerResponse);
    } catch (err) {
      self.postMessage({ type: 'init-error', message: String(err) } satisfies WorkerResponse);
    }
    return;
  }
  let res: CompileResult;
  let fatal = false;
  try {
    if (!engine) throw new Error('The report engine is not started.');
    res = engine.compile(msg.files);
  } catch (err) {
    // A WebAssembly.RuntimeError is a Typst panic: report it, and let the client replace this worker.
    fatal = err instanceof WebAssembly.RuntimeError;
    res = { pdf: null, diagnostics: [{ path: '', line: 0, severity: 'error', message: `The report engine failed: ${String(err)}` }] };
  }
  const out: WorkerResponse = { type: 'result', id: msg.id, fatal, ...res };
  self.postMessage(out, res.pdf ? [res.pdf.buffer as ArrayBuffer] : []);
};
