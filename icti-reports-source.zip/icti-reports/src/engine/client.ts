// Main-thread side of the engine: runs the Typst compiler in a Web Worker so the editor stays responsive.
// (No main-thread fallback: Chromium refuses to compile a 28 MB WASM module synchronously there.)
import type { CompileResult } from './typst';
import type { WorkerRequest, WorkerResponse } from './worker';
import { t } from '../i18n';

export interface Compiler {
  compile(files: Record<string, Uint8Array | string>): Promise<CompileResult>;
  /** Called once when the worker crashed or was stopped; the plugin then starts a new one on next use. */
  onDead(cb: () => void): void;
  dispose(): void;
}

/** A compile taking longer than this is treated as hung: the worker is stopped and restarted on next use. */
const COMPILE_TIMEOUT = 90_000;

const failure = (message: string): CompileResult => ({ pdf: null, diagnostics: [{ path: '', line: 0, severity: 'error', message }] });

export function startCompiler(source: string, wasm: ArrayBuffer, fonts: ArrayBuffer[]): Promise<Compiler> {
  const url = URL.createObjectURL(new Blob([source], { type: 'text/javascript' }));
  const worker = new Worker(url);
  const pending = new Map<number, (r: CompileResult) => void>();
  const deadCallbacks: (() => void)[] = [];
  let nextId = 1;
  let dead = false;

  const kill = (message: string) => {
    if (dead) return;
    dead = true;
    worker.terminate();
    URL.revokeObjectURL(url);
    for (const resolve of pending.values()) resolve(failure(message));
    pending.clear();
    for (const cb of deadCallbacks) cb();
  };

  const compiler: Compiler = {
    compile(files) {
      if (dead) return Promise.resolve(failure(t('The report engine stopped; please try again.')));
      const id = nextId++;
      return new Promise((resolve) => {
        const timer = window.setTimeout(() => kill(t('The report took too long to make (more than 90 seconds) and was stopped. Check the layout file or make the report smaller.')), COMPILE_TIMEOUT);
        pending.set(id, (r) => {
          window.clearTimeout(timer);
          resolve(r);
        });
        worker.postMessage({ type: 'compile', id, files } satisfies WorkerRequest);
      });
    },
    onDead(cb) {
      if (dead) cb();
      else deadCallbacks.push(cb);
    },
    dispose: () => kill(t('The report engine was stopped.')),
  };

  return new Promise((resolve, reject) => {
    worker.onerror = (e) => {
      e.preventDefault();
      kill(t('The report engine stopped unexpectedly: {error}', { error: e.message }));
      reject(new Error(e.message || t('The report engine could not start.')));
    };
    worker.onmessage = (e: MessageEvent<WorkerResponse>) => {
      const msg = e.data;
      if (msg.type === 'ready') resolve(compiler);
      else if (msg.type === 'init-error') {
        kill(msg.message);
        reject(new Error(msg.message));
      } else if (msg.type === 'result') {
        pending.get(msg.id)?.({ pdf: msg.pdf, diagnostics: msg.diagnostics });
        pending.delete(msg.id);
        // After a Typst panic the WASM instance is unusable: replace the worker.
        if (msg.fatal) kill(t('The report engine crashed and will restart.'));
      }
    };
    worker.postMessage({ type: 'init', wasm, fonts } satisfies WorkerRequest);
  });
}
