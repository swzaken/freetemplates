// Thin wrapper around the Typst WASM compiler. Runs in a Web Worker (plugin) or in Node (CLI, tests).
// The WASM and fonts are passed in as bytes: nothing is fetched, and Typst only sees the files we map.
import { initSync, TypstCompilerBuilder, type TypstCompiler } from '@myriaddreamin/typst-ts-web-compiler/pkg/typst_ts_web_compiler.mjs';

export interface TypstDiagnostic {
  path: string;
  /** 1-based line, 0 when unknown. */
  line: number;
  severity: 'error' | 'warning';
  message: string;
}

export interface CompileResult {
  pdf: Uint8Array | null;
  diagnostics: TypstDiagnostic[];
}

const DIAG_FULL = 3; // structured diagnostics: { path, range: "l:c-l:c" (0-based), severity, message }

interface RawDiag {
  path?: string;
  range?: string;
  severity?: string;
  message?: string;
}

function toDiag(d: RawDiag | string): TypstDiagnostic {
  if (typeof d === 'string') return { path: '', line: 0, severity: 'error', message: d };
  const line = d.range ? Number(d.range.split(':')[0]) + 1 : 0;
  return {
    path: d.path ?? '',
    line: Number.isFinite(line) ? line : 0,
    severity: String(d.severity).toLowerCase() === 'warning' ? 'warning' : 'error',
    message: d.message ?? 'Unknown Typst error',
  };
}

export class TypstEngine {
  private constructor(private compiler: TypstCompiler) {}

  static async create(wasm: BufferSource, fonts: Uint8Array[]): Promise<TypstEngine> {
    initSync({ module: wasm });
    const builder = new TypstCompilerBuilder();
    builder.set_dummy_access_model(); // no file system, no package registry
    for (const f of fonts) await builder.add_raw_font(f);
    return new TypstEngine(await builder.build());
  }

  /** Compiles `main` against exactly the given files (path -> bytes or text) and returns a PDF. */
  compile(files: Record<string, Uint8Array | string>, main = '/report.typ'): CompileResult {
    const c = this.mapFiles(files);
    try {
      const out = c.compile(main, null, 'pdf', DIAG_FULL) as { result?: Uint8Array; diagnostics?: (RawDiag | string)[] };
      const diagnostics = (out.diagnostics ?? []).map(toDiag);
      const failed = diagnostics.some((d) => d.severity === 'error');
      return { pdf: !failed && out.result ? out.result : null, diagnostics };
    } catch (e) {
      if (e instanceof WebAssembly.RuntimeError) throw e; // a panic: the instance is unusable, let the caller restart
      return { pdf: null, diagnostics: [toDiag(String(e))] };
    }
  }

  /** Runs a Typst query (e.g. "heading") against the files; used by tests to read back rendered text. */
  query(files: Record<string, Uint8Array | string>, selector: string, main = '/report.typ'): unknown {
    return JSON.parse(this.mapFiles(files).query(main, null, selector, null));
  }

  private mapFiles(files: Record<string, Uint8Array | string>): TypstCompiler {
    const c = this.compiler;
    c.reset_shadow();
    const enc = new TextEncoder();
    for (const [path, data] of Object.entries(files)) c.map_shadow(path, typeof data === 'string' ? enc.encode(data) : data);
    return c;
  }
}
