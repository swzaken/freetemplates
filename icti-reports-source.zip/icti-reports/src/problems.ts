// Turns converter warnings and Typst diagnostics into plain-language problems for notices and the preview.
import type { Diagnostic } from './convert/ast';
import type { TypstDiagnostic } from './engine/typst';
import { t } from './i18n';

export interface Problem {
  severity: 'error' | 'warning';
  /** 1-based line in the note, or 0 for properties / not tied to a line. */
  line: number;
  /** Where the problem is: in the note (a line or its properties), the layout file, or the engine. */
  source: 'note' | 'layout' | 'engine';
  /** Where to look, in words: "Line 12", "Properties" or "Layout file, line 40". */
  where: string;
  message: string;
}

export function fromNote(d: Diagnostic): Problem {
  return { severity: d.severity, line: d.line, source: 'note', where: d.line > 0 ? t('Line {n}', { n: d.line }) : t('Properties'), message: d.message };
}

/** Typst only ever sees the layout and JSON data, so its errors point into the layout file. */
export function fromTypst(d: TypstDiagnostic, layoutName: string): Problem {
  const inLayout = d.path === '/report.typ';
  return {
    severity: d.severity,
    line: 0,
    source: inLayout ? 'layout' : 'engine',
    where: inLayout && d.line ? t('Layout file {name}, line {n}', { name: layoutName, n: d.line }) : inLayout ? t('Layout file {name}', { name: layoutName }) : t('Report engine'),
    message: plain(d.message) + (inLayout && layoutName !== '(built-in)' && /does not contain key/i.test(d.message)
      ? t(' Your layout is probably from an older version of the plugin: click "Update layout" in the plugin settings.')
      : ''),
  };
}

function plain(message: string): string {
  if (/failed to decode image/i.test(message)) return t('An image in the report is damaged and could not be read; replace or remove it ({detail}).', { detail: message });
  if (/file not found|failed to load file|file is not valid/i.test(message)) return t('A file the layout needs is missing or unreadable ({detail}).', { detail: message });
  if (/unknown font family/i.test(message)) return t('A font is missing from the plugin folder ({detail}).', { detail: message });
  return message.charAt(0).toUpperCase() + message.slice(1);
}

export function formatProblem(p: Problem): string {
  return `${p.where}: ${p.message}`;
}
