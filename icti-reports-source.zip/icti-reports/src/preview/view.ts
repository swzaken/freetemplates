// Live preview side panel: compiles the active report note (debounced, in the worker) and shows the
// PDF pages with Obsidian's built-in pdf.js, plus a list of problems that jump to the note line.
import { ItemView, loadPdfJs, MarkdownView, TFile, type WorkspaceLeaf } from 'obsidian';
import type IctiReportsPlugin from '../main';
import { formatProblem, type Problem } from '../problems';
import { RenderScheduler } from './scheduler';
import { changeCoverImage, toggleContents, toggleCover, toggleHeader } from '../obsidian/cover';
import { revealLine } from '../obsidian/reveal';
import { t } from '../i18n';

export const PREVIEW_VIEW = 'icti-report-preview';
const MAX_CANVAS_WIDTH = 1600; // backing pixels per page: sharp enough, bounded memory on long reports

// Minimal shape of the pdf.js objects we use (Obsidian types loadPdfJs() as any).
interface PdfPage {
  getViewport(o: { scale: number }): { width: number; height: number };
  render(o: { canvasContext: CanvasRenderingContext2D; viewport: unknown }): { promise: Promise<void> };
}
interface PdfDoc {
  numPages: number;
  getPage(n: number): Promise<PdfPage>;
  destroy(): Promise<void>;
}

export class PreviewView extends ItemView {
  private file: TFile | null = null;
  private doc: PdfDoc | null = null;
  private scheduler: RenderScheduler;
  /** All page drawing (new PDF, resize, clear) runs one at a time through this chain. */
  private drawing: Promise<void> = Promise.resolve();
  private closed = false;
  /** An update was skipped while the panel was hidden; catch up when it is shown again. */
  private missed = false;
  private resizeTimer: number | null = null;
  private lastWidth = 0;
  private statusEl!: HTMLElement;
  private problemsEl!: HTMLElement;
  private pagesEl!: HTMLElement;

  constructor(leaf: WorkspaceLeaf, private plugin: IctiReportsPlugin) {
    super(leaf);
    this.scheduler = new RenderScheduler(() => plugin.settings.previewDelay, () => this.update());
  }

  getViewType(): string {
    return PREVIEW_VIEW;
  }

  getDisplayText(): string {
    return t('Report preview');
  }

  getIcon(): string {
    return 'file-text';
  }

  async onOpen(): Promise<void> {
    const root = this.contentEl;
    root.empty();
    root.addClass('icti-preview');
    const bar = root.createDiv({ cls: 'icti-preview-bar' });
    this.statusEl = bar.createSpan({ cls: 'icti-preview-status', text: t('Open a report note.') });
    const buttons = bar.createDiv({ cls: 'icti-preview-buttons' });
    buttons.createEl('button', { text: t('Change log') }).addEventListener('click', () => this.plugin.showLog(this.file));
    buttons.createEl('button', { text: t('Cover page') }).addEventListener('click', () => void toggleCover(this.plugin, this.file));
    buttons.createEl('button', { text: t('Cover image') }).addEventListener('click', () => changeCoverImage(this.plugin, this.file));
    buttons.createEl('button', { text: t('Header') }).addEventListener('click', () => void toggleHeader(this.plugin, this.file));
    buttons.createEl('button', { text: t('Contents') }).addEventListener('click', () => void toggleContents(this.plugin, this.file));
    buttons.createEl('button', { text: t('Export PDF'), cls: 'mod-cta' }).addEventListener('click', () => {
      if (this.file) void this.plugin.exportFile(this.file);
    });
    this.problemsEl = root.createDiv({ cls: 'icti-preview-problems' });
    this.pagesEl = root.createDiv({ cls: 'icti-preview-pages' });

    const { workspace, metadataCache, vault } = this.app;
    this.registerEvent(workspace.on('active-leaf-change', () => this.followActive()));
    this.registerEvent(workspace.on('file-open', () => this.followActive())); // links, quick switcher, back/forward
    this.registerEvent(workspace.on('editor-change', (_e, info) => {
      if (info.file && info.file.path === this.file?.path) this.scheduler.request();
    }));
    // Linked directly from the report (an embedded image).
    const linked = (path: string) => !!this.file && !!metadataCache.resolvedLinks[this.file.path]?.[path];
    this.registerEvent(metadataCache.on('changed', (f) => {
      // The properties are read a moment after saving: only now can a note that became a presentation be seen.
      if (f.path === this.file?.path && this.plugin.notAReport(f, 'preview')) return this.followActive();
    }));
    // The note itself changed outside the editor (sync, reading mode, other plugins), an embedded image, or the layout.
    this.registerEvent(vault.on('modify', (f) => {
      // (Also fires for the note's own autosaves; property edits in the Properties panel arrive only this way.)
      // A note that just became a presentation is no longer previewed as a report.
      if (f.path === this.file?.path && this.plugin.notAReport(f as TFile, 'preview')) return this.followActive();
      if (f.path === this.file?.path || f.path === this.plugin.settings.layoutPath || linked(f.path)) this.scheduler.request();
    }));
    this.registerEvent(vault.on('delete', (f) => {
      if (f.path === this.file?.path) this.setFile(null);
    }));

    this.followActive();
  }

  async onClose(): Promise<void> {
    this.closed = true;
    this.scheduler.stop();
    if (this.resizeTimer) this.contentEl.win.clearTimeout(this.resizeTimer);
    this.queueDraw(null);
    await this.drawing;
  }

  /** Re-renders now (used when the settings change). */
  refresh(): void {
    this.scheduler.request(true);
  }

  /** Follows the note shown in the active editor; clicking into the preview keeps the current note. */
  private followActive(): void {
    const file = this.app.workspace.getActiveViewOfType(MarkdownView)?.file;
    // Presentations (`presentation: true` or `format: md-slides/N`) and ISO templates (`iso-template: true`) are not reports: leave them alone.
    const why = file ? this.plugin.notAReport(file, 'preview') : null;
    if (file && why) {
      if (this.file) this.setFile(null);
      this.statusEl.setText(why);
      return;
    }
    if (file && file.path !== this.file?.path) this.setFile(file);
  }

  private setFile(file: TFile | null): void {
    this.file = file;
    this.problemsEl.empty();
    this.pagesEl.removeClass('is-stale');
    this.queueDraw(null); // never show the previous note's pages under the new note's name
    this.statusEl.setText(file ? t('{note}: updating…', { note: file.basename }) : t('Open a report note.'));
    if (file) this.scheduler.request(true);
  }

  private async update(): Promise<void> {
    const file = this.file;
    if (!file || this.closed) return;
    if (!this.containerEl.isShown()) {
      this.missed = true; // sidebar collapsed or tab hidden: no point compiling now
      return;
    }
    this.missed = false;
    this.statusEl.setText(t('{note}: updating…', { note: file.basename }));
    let pdf: Uint8Array | null = null;
    let problems: Problem[];
    try {
      const text = await this.plugin.noteText(file);
      const result = await this.plugin.render(file, text);
      // Opening a note in a tab that showed another one: the editor may still have held the old text when we read
      // it. If the text differs now, render again (no change event follows that swap).
      if (file === this.file && (await this.plugin.noteText(file)) !== text) this.scheduler.request();
      pdf = result.pdf;
      problems = result.problems;
      if (result.placeholders.length) {
        const n = result.placeholders.length;
        problems = [...problems, { severity: 'warning', line: result.placeholders[0], source: 'note', where: t('Line {n}', { n: result.placeholders[0] }), message: t('{n} place(s) with red placeholder text still to fill in.', { n }) }];
      }
    } catch (e) {
      problems = [{ severity: 'error', line: 0, source: 'engine', where: t('Report engine'), message: e instanceof Error ? e.message : String(e) }];
    }
    if (file !== this.file || this.closed) return; // switched notes meanwhile; that note has its own update queued
    this.showProblems(problems);
    if (!pdf) {
      this.pagesEl.addClass('is-stale'); // keep the last good pages, dimmed
      this.statusEl.setText(t('{note}: not updated, see the problems above', { note: file.basename }));
      return;
    }
    const pdfjs = await loadPdfJs();
    const doc = (await pdfjs.getDocument({ data: pdf, isEvalSupported: false }).promise) as PdfDoc;
    if (file !== this.file || this.closed) {
      await doc.destroy();
      return;
    }
    this.queueDraw(doc);
    await this.drawing;
    this.pagesEl.removeClass('is-stale');
    const warnings = problems.filter((p) => p.severity === 'warning').length;
    this.statusEl.setText(t('{note}: updated {time}', { note: file.basename, time: new Date().toLocaleTimeString() }) + (warnings ? t(' · {n} warning(s)', { n: warnings }) : ''));
  }

  /**
   * Queues a redraw. `doc` replaces the current PDF (null clears the pages); undefined redraws the
   * current PDF at the new width. Old documents are destroyed only after the new pages are drawn.
   */
  private queueDraw(doc?: PdfDoc | null): void {
    this.drawing = this.drawing
      .then(async () => {
        if (doc !== undefined && doc !== this.doc) {
          const old = this.doc;
          this.doc = doc;
          if (doc) await this.drawPages(doc);
          else this.pagesEl.empty();
          await old?.destroy();
        } else if (this.doc && !this.closed) {
          await this.drawPages(this.doc);
        }
      })
      .catch((e) => console.error('ICT Reports: drawing the preview failed', e));
  }

  /** Draws every page into fresh canvases, then swaps them in at once (no flicker, scroll position kept). */
  private async drawPages(doc: PdfDoc): Promise<void> {
    const win = this.pagesEl.win; // the panel may live in a popout window with its own screen density
    const width = Math.max(200, this.pagesEl.clientWidth - 24);
    this.lastWidth = this.pagesEl.clientWidth;
    const canvases: HTMLCanvasElement[] = [];
    for (let n = 1; n <= doc.numPages; n++) {
      const page = await doc.getPage(n);
      const cssScale = width / page.getViewport({ scale: 1 }).width;
      const backing = Math.min(cssScale * (win.devicePixelRatio || 1), MAX_CANVAS_WIDTH / page.getViewport({ scale: 1 }).width);
      const viewport = page.getViewport({ scale: backing });
      const canvas = this.pagesEl.doc.createElement('canvas');
      canvas.className = 'icti-preview-page';
      canvas.width = Math.floor(viewport.width);
      canvas.height = Math.floor(viewport.height);
      canvas.style.width = `${Math.floor(width)}px`;
      await page.render({ canvasContext: canvas.getContext('2d')!, viewport }).promise;
      canvases.push(canvas);
    }
    if (this.closed) return;
    const scroll = this.pagesEl.scrollTop;
    this.pagesEl.replaceChildren(...canvases);
    this.pagesEl.scrollTop = scroll;
  }

  /** Called by Obsidian when the panel changes size or becomes visible again. */
  onResize(): void {
    if (!this.pagesEl || this.pagesEl.clientWidth === 0) return; // hidden or collapsed
    if (this.missed) this.scheduler.request(true);
    if (Math.abs(this.pagesEl.clientWidth - this.lastWidth) < 8) return;
    const win = this.pagesEl.win;
    if (this.resizeTimer) win.clearTimeout(this.resizeTimer);
    this.resizeTimer = win.setTimeout(() => this.queueDraw(), 200);
  }

  /** Problems as plain text; ones with a note line jump to that line when clicked. */
  private showProblems(problems: Problem[]): void {
    this.problemsEl.empty();
    for (const p of problems) {
      const row = this.problemsEl.createDiv({ cls: `icti-problem is-${p.severity}`, text: formatProblem(p) });
      if (p.source === 'note') {
        row.addClass('is-link');
        row.setAttr('title', t('Show in the note'));
        row.addEventListener('click', () => void this.reveal(Math.max(p.line, 1)));
      }
    }
  }

  private async reveal(line: number): Promise<void> {
    if (this.file) await revealLine(this.app, this.file, line);
  }
}
