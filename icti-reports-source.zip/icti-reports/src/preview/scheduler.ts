/**
 * Debounces preview updates and never runs two at once: requests during a run are coalesced into
 * one follow-up run, so typing fast compiles at most twice (the running one and the latest text).
 */
export class RenderScheduler {
  private timer: ReturnType<typeof setTimeout> | null = null;
  private running = false;
  private again = false;
  private stopped = false;

  constructor(private delay: () => number, private run: () => Promise<void>) {}

  /** Schedules a run after the delay (restarting the delay), or right away. */
  request(immediate = false): void {
    if (this.stopped) return;
    if (this.timer) clearTimeout(this.timer);
    this.timer = setTimeout(() => void this.fire(), immediate ? 0 : this.delay());
  }

  stop(): void {
    this.stopped = true;
    if (this.timer) clearTimeout(this.timer);
    this.timer = null;
  }

  private async fire(): Promise<void> {
    this.timer = null;
    if (this.running) {
      this.again = true;
      return;
    }
    this.running = true;
    try {
      await this.run();
    } catch (e) {
      console.error('ICT Reports: preview update failed', e);
    } finally {
      this.running = false;
      if (this.again && !this.stopped) {
        this.again = false;
        void this.fire();
      }
    }
  }
}
