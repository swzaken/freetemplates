import { Notice, PluginSettingTab, Setting, TFile, type App } from 'obsidian';
import { DEFAULT_PATTERN, OLD_DEFAULT_PATTERNS } from './data/filename';
import { setUiLanguage, t, type UiLanguage } from './i18n';
import type IctiReportsPlugin from './main';

export interface Settings {
  /** Language of the plugin's own screens (not of the reports). */
  uiLanguage: UiLanguage;
  /** Vault path of the editable layout; the built-in layout is used when this file does not exist. */
  layoutPath: string;
  /** Vault folder with the report templates (starter notes); built-in templates are used when it is empty. */
  templatesFolder: string;
  /** Main folder for client projects; "New report" makes reports in a subfolder of it. */
  clientProjectsFolder: string;
  /** Main folder for internal projects. */
  internalProjectsFolder: string;
  /** Vault folder for exported PDFs; empty = next to the note. */
  outputFolder: string;
  fileNamePattern: string;
  /** Milliseconds of no typing before the preview updates. */
  previewDelay: number;
  /** The ICT Institute panel was placed in the sidebar once (closing it is then respected). */
  menuPlaced: boolean;
  /** Zoom levels from older versions (moved to this computer's local storage on load; not saved again). */
  legacyNoteZoom?: Record<string, number>;
}

/** Settings as loaded from data.json, each field checked against the default's type (a hand-edited or
 *  sync-merged file must not crash the plugin), plus migrations of older settings. */
export function cleanSettings(raw: unknown): Settings {
  const r = (raw && typeof raw === 'object' ? raw : {}) as Record<string, unknown>;
  const out = { ...DEFAULT_SETTINGS } as Record<string, unknown>;
  for (const [k, v] of Object.entries(DEFAULT_SETTINGS)) {
    if (typeof r[k] === typeof v && r[k] !== null) out[k] = r[k];
  }
  const s = out as unknown as Settings;
  if (OLD_DEFAULT_PATTERNS.includes(s.fileNamePattern)) s.fileNamePattern = DEFAULT_PATTERN; // older defaults
  if (s.uiLanguage !== 'nl' && s.uiLanguage !== 'en') s.uiLanguage = 'nl';
  // Note zoom used to be stored here (shared through a synced vault); it is now per computer.
  if (r.noteZoom && typeof r.noteZoom === 'object' && !Array.isArray(r.noteZoom)) s.legacyNoteZoom = r.noteZoom as Record<string, number>;
  return s;
}

export const DEFAULT_SETTINGS: Settings = {
  uiLanguage: 'nl',
  layoutPath: 'ICT Rapporten/Opmaak/report.typ',
  templatesFolder: 'ICT Rapporten/Sjablonen',
  clientProjectsFolder: '02. Client Projects',
  internalProjectsFolder: '01. Internal projects',
  outputFolder: '',
  fileNamePattern: DEFAULT_PATTERN,
  previewDelay: 500,
  menuPlaced: false,
};

type TextKey = 'layoutPath' | 'templatesFolder' | 'clientProjectsFolder' | 'internalProjectsFolder' | 'outputFolder' | 'fileNamePattern';

export class SettingsTab extends PluginSettingTab {
  constructor(app: App, private plugin: IctiReportsPlugin) {
    super(app, plugin);
  }

  display(): void {
    const { containerEl } = this;
    containerEl.empty();
    const s = this.plugin.settings;

    // On leaving a field only the previews refresh: rebuilding the whole tab would swallow a click on a button
    // and break Tab from one field to the next.
    const text = (name: string, desc: string, key: TextKey, placeholder: string, onBlur?: (setting: Setting) => void) => {
      const setting = new Setting(containerEl).setName(name).setDesc(desc);
      setting.addText((field) => {
        let atFocus = s[key];
        field.setPlaceholder(placeholder).setValue(s[key]).onChange(async (v) => {
          s[key] = key === 'fileNamePattern' ? v : v.trim();
          await this.plugin.saveSettings();
        });
        field.inputEl.addEventListener('focus', () => (atFocus = s[key]));
        field.inputEl.addEventListener('blur', () => {
          if (s[key] === atFocus) return;
          onBlur?.(setting);
          this.plugin.refreshPreviews();
        });
      });
      return setting;
    };

    new Setting(containerEl).setName(t('Change log')).setHeading();
    new Setting(containerEl)
      .setName(t('Your name'))
      .setDesc(t('Shown in the change log of every note you create or change. Saved on this computer only, so every colleague sets their own.'))
      .addText((field) => field.setPlaceholder(t('First and last name')).setValue(this.plugin.changeLog.author()).onChange((v) => this.plugin.changeLog.setAuthor(v)));

    new Setting(containerEl).setName(t('Language')).setHeading();
    new Setting(containerEl)
      .setName(t('Plugin language'))
      .setDesc(t('Language of the commands, settings and messages of this plugin. Command names change after restarting Obsidian (or turning the plugin off and on).'))
      .addDropdown((d) => d.addOptions({ nl: 'Nederlands', en: 'English' }).setValue(s.uiLanguage).onChange(async (v) => {
        s.uiLanguage = v as UiLanguage;
        setUiLanguage(s.uiLanguage);
        await this.plugin.saveSettings();
        this.display();
      }));

    new Setting(containerEl).setName(t('Starter files')).setHeading();
    new Setting(containerEl)
      .setName(t('Install starter files'))
      .setDesc(t('Copies the layout and the report templates into the folders below. Existing files are never overwritten.'))
      .addButton((b) => b.setButtonText(t('Install')).onClick(async () => {
        try {
          const created = await this.plugin.resources.installStarter(s);
          new Notice(created.length ? t('Created {n} file(s).', { n: created.length }) : t('All starter files already exist.'));
          this.plugin.refreshPreviews();
        } catch (e) {
          new Notice(e instanceof Error ? e.message : String(e));
        }
        this.display();
      }));

    new Setting(containerEl)
      .setName(t('Update layout'))
      .setDesc(t('Replaces the layout and its artwork in your vault with the versions from this plugin. Use this after updating the plugin. A backup of each old file is kept next to it.'))
      .addButton((b) => b.setButtonText(t('Update')).onClick(async () => {
        try {
          const backup = await this.plugin.resources.updateLayout(s.layoutPath);
          new Notice(backup === 'current' ? t('The layout is already up to date.')
            : backup === 'artwork' ? t('The artwork of the layout was updated; the old files are kept next to them as .bak.')
            : backup ? t('Layout updated. The old layout is kept as {path}.', { path: backup })
            : t('There is no layout in the vault; the built-in layout is already used.'));
          this.plugin.refreshPreviews();
        } catch (e) {
          new Notice(e instanceof Error ? e.message : String(e));
        }
      }));

    new Setting(containerEl).setName(t('Folders')).setHeading();
    const layoutDesc = () => this.plugin.resources.find(s.layoutPath) instanceof TFile
      ? t('Typst layout in your vault. Its artwork goes in an "assets" folder next to it.')
      : t('Not found in the vault, so the built-in layout is used. "Install starter files" creates an editable copy.');
    text(t('Layout file'), layoutDesc(), 'layoutPath', DEFAULT_SETTINGS.layoutPath, (setting) => setting.setDesc(layoutDesc()));
    text(t('Templates folder'), t('Each note in this folder is a report type for "New report". Without notes here the built-in templates are used.'), 'templatesFolder', DEFAULT_SETTINGS.templatesFolder);
    text(t('Client projects folder'), t('"New report" → Client project makes the report in a folder inside this one (one folder per client or project).'), 'clientProjectsFolder', DEFAULT_SETTINGS.clientProjectsFolder);
    text(t('Internal projects folder'), t('"New report" → Internal project makes the report in a folder inside this one.'), 'internalProjectsFolder', DEFAULT_SETTINGS.internalProjectsFolder);

    new Setting(containerEl).setName(t('Export')).setHeading();
    text(t('PDF folder'), t('Vault folder for exported PDFs. Leave empty to save the PDF next to the note.'), 'outputFolder', t('next to the note'));
    text(t('PDF file name'), t('Tokens: {date} (YYYYMMDD), {folder} (the folder the note is in), {title}, {note} (the document name).'), 'fileNamePattern', DEFAULT_PATTERN);

    new Setting(containerEl).setName(t('Preview')).setHeading();
    new Setting(containerEl)
      .setName(t('Preview delay'))
      .setDesc(t('How long to wait after you stop typing before the preview updates (milliseconds, 100–5000).'))
      .addText((field) => field.setPlaceholder('500').setValue(String(s.previewDelay)).onChange(async (v) => {
        const n = Number(v);
        if (Number.isFinite(n) && n >= 100 && n <= 5000) {
          s.previewDelay = Math.round(n);
          await this.plugin.saveSettings();
        }
      }));
  }
}
