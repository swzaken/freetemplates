// Note text -> the set of files the Typst layout compiles against. Pure: all I/O goes through the host callbacks.
import type { Block, CoverBlock, Diagnostic, HeaderBlock, ImageNode, Inline } from './convert/ast';
import { convertMarkdown, forEachImage, splitFrontmatter } from './convert/markdown';
import { buildMeta, type Props, type ReportMeta } from './data/meta';
import { t } from './i18n';

export interface Host {
  /** Parses the frontmatter YAML (Obsidian's parseYaml in the plugin). */
  parseYaml(yaml: string): Props;
  /** Finds an image by the reference written in the note; null when it does not exist in the vault. */
  readImage(ref: string): Promise<Uint8Array | null>;
  today?: Date;
  /** The note's name: the title in the page header when the report has no cover and no `title` property. */
  noteName?: string;
}

export interface Prepared {
  meta: ReportMeta;
  blocks: Block[];
  /** Image files to map into Typst: virtual path -> bytes. */
  images: Record<string, Uint8Array>;
  diagnostics: Diagnostic[];
  /** Note lines that still contain ==placeholder== text (checked before export). */
  placeholders: number[];
}

const IMAGE_EXT = /\.(png|jpe?g|gif|svg|webp)$/i;

/** Only references to files are allowed: no URLs, no absolute paths. ("../" is resolved by joinInVault.) */
export function isSafeImageRef(ref: string): boolean {
  return !!ref && !/^[a-z][a-z0-9+.-]*:/i.test(ref) && !ref.startsWith('/') && !ref.startsWith('\\');
}

/** "a/b" + "../c.png" -> "a/c.png"; null when the path would leave the vault (more ".." than folders). */
export function joinInVault(folder: string, ref: string): string | null {
  const out: string[] = [];
  for (const part of [...folder.split('/'), ...ref.split(/[\\/]/)]) {
    if (part === '' || part === '.') continue;
    if (part === '..') {
      if (!out.length) return null;
      out.pop();
    } else out.push(part);
  }
  return out.join('/');
}

/**
 * The image format from the file's first bytes, or null when it is not a usable image. A damaged image
 * would otherwise stop the whole PDF with a Typst error that points into the layout, not the note.
 */
export function imageFormat(b: Uint8Array): 'png' | 'jpg' | 'gif' | 'webp' | 'svg' | null {
  const ascii = (from: number, to: number) => String.fromCharCode(...b.subarray(from, to));
  if (b.length > 24 && b[0] === 0x89 && ascii(1, 4) === 'PNG' && ascii(12, 16) === 'IHDR') return 'png';
  if (b.length > 4 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return 'jpg';
  if (b.length > 6 && ascii(0, 4) === 'GIF8') return 'gif';
  if (b.length > 12 && ascii(0, 4) === 'RIFF' && ascii(8, 12) === 'WEBP') return 'webp';
  if (/<svg[\s>]/i.test(new TextDecoder().decode(b.subarray(0, 4096)))) return 'svg';
  return null;
}

/** A folder or file path setting that stays inside the vault: no "..", no drive letter, no leading slash. */
export function isVaultPath(path: string): boolean {
  return !/^([a-z]:|[\\/])/i.test(path.trim()) && !path.split(/[\\/]/).includes('..');
}

export async function prepare(note: string, host: Host): Promise<Prepared> {
  const diagnostics: Diagnostic[] = [];
  const { yaml, body, bodyLine } = splitFrontmatter(note);
  let props: Props = {};
  try {
    props = (yaml ? host.parseYaml(yaml) : {}) ?? {};
  } catch (e) {
    diagnostics.push({ line: 1, severity: 'error', message: t('The properties at the top of the note could not be read: {error}', { error: String(e) }) });
  }
  const all = convertMarkdown(body, bodyLine);
  // The cover block may stand anywhere (normally at the top); it is the first page, not part of the text.
  const covers = all.filter((b): b is CoverBlock => b.t === 'cover');
  for (const extra of covers.slice(1)) {
    diagnostics.push({ line: extra.line, severity: 'warning', message: t('This report has more than one cover block; only the first one is used.') });
  }
  // The header block likewise: the two lines at the top of the inner pages.
  const headers = all.filter((b): b is HeaderBlock => b.t === 'header');
  for (const extra of headers.slice(1)) {
    diagnostics.push({ line: extra.line, severity: 'warning', message: t('This report has more than one header block; only the first one is used.') });
  }
  const blocks = all.filter((b) => b.t !== 'cover' && b.t !== 'header');
  const contents = blocks.filter((b) => b.t === 'contents');
  if (contents.length > 1) diagnostics.push({ line: contents[1].line, severity: 'warning', message: t('This report has more than one table of contents.') });
  const cover = covers[0] ?? null;
  const header = headers[0] ?? null;
  if (cover && !cover.title.length) diagnostics.push({ line: cover.line, severity: 'warning', message: t('The cover block has no title. Write it on a line starting with "> # ".') });
  if (header && header.lines.length > 2) diagnostics.push({ line: header.line, severity: 'warning', message: t('The header block has more than two lines; only the first two are printed.') });
  const meta = buildMeta(props, cover, host.noteName ?? '', host.today, header);
  const images: Record<string, Uint8Array> = {};
  const byRef = new Map<string, string | null>();

  const load = async (ref: string, line: number): Promise<string | null> => {
    if (byRef.has(ref)) return byRef.get(ref)!;
    let path: string | null = null;
    if (!isSafeImageRef(ref)) {
      diagnostics.push({ line, severity: 'warning', message: t('Image "{ref}" is not a file in the vault (web addresses and paths outside the vault are not loaded).', { ref }) });
    } else if (!IMAGE_EXT.test(ref)) {
      diagnostics.push({ line, severity: 'warning', message: t('"{ref}" is not a supported image (png, jpg, gif, svg, webp).', { ref }) });
    } else {
      const bytes = await host.readImage(ref);
      const format = bytes && imageFormat(bytes);
      if (format) {
        path = `/img/${byRef.size}.${format}`; // named by its real format, so a .jpg saved as .png still works
        images[path] = bytes!;
      } else {
        diagnostics.push({ line, severity: 'warning', message: bytes ? t('Image "{ref}" is damaged or not really an image.', { ref }) : t('Image "{ref}" not found.', { ref }) });
      }
    }
    byRef.set(ref, path);
    return path;
  };

  const nodes: ImageNode[] = [];
  forEachImage(cover ? [cover, ...blocks] : blocks, (img) => nodes.push(img));
  for (const img of nodes) {
    const path = await load(img.ref, img.line);
    if (path) img.src = path;
  }

  // The cover picture: the one in the cover block, else (or when it cannot be used) the default.
  if (meta.cover) {
    meta.cover.image = cover?.image?.src ?? DEFAULT_COVER;
    meta.cover.ownImage = !!cover?.image?.src;
  }
  return { meta, blocks, images, diagnostics, placeholders: placeholderLines([...(cover ? [cover] : []), ...(header ? [header] : []), ...blocks]) };
}

export const DEFAULT_COVER = '/assets/cover-default.png';

/** The note lines that still contain ==placeholder== text (one per paragraph, list item, table row or cover). */
export function placeholderLines(blocks: Block[]): number[] {
  const lines: number[] = [];
  const has = (ns: Inline[]): boolean => ns.some((n) => n.t === 'placeholder' || ('c' in n && has(n.c)));
  for (const b of blocks) {
    if ((b.t === 'para' || b.t === 'heading') && has(b.c)) lines.push(b.line);
    else if (b.t === 'cover' && (has(b.title) || b.lines.some(has))) lines.push(b.line);
    else if (b.t === 'header' && b.lines.slice(0, 2).some(has)) lines.push(b.line);
    else if (b.t === 'list') b.items.forEach((item) => lines.push(...placeholderLines(item)));
    else if (b.t === 'quote') lines.push(...placeholderLines(b.c));
    else if (b.t === 'table') {
      if (b.head.some(has)) lines.push(b.line);
      b.rows.forEach((row, i) => {
        if (row.some(has)) lines.push(b.rowLines[i] ?? b.line);
      });
    }
  }
  return lines;
}

/** All files for one compile: layout, data and images. `assets` holds the layout's own artwork. */
export function typstFiles(p: Prepared, layout: string, assets: Record<string, Uint8Array>): Record<string, Uint8Array | string> {
  return {
    '/report.typ': layout,
    '/meta.json': JSON.stringify(p.meta),
    '/doc.json': JSON.stringify(p.blocks),
    ...assets,
    ...p.images,
  };
}
