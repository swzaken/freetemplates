import { MarkdownView, Modal, Notice, normalizePath, Plugin, TFile, type App } from 'obsidian';
import workerSource from 'icti:worker-source';
import { startCompiler, type Compiler } from './engine/client';
import { buildFileName } from './data/filename';
import { DEFAULT_COVER, isVaultPath, prepare, typstFiles } from './pipeline';
import { forEachImage } from './convert/markdown';
import { formatProblem, fromNote, fromTypst, type Problem } from './problems';
import { Resources } from './obsidian/resources';
import { cleanSettings, DEFAULT_SETTINGS, SettingsTab, type Settings } from './settings';
import { PREVIEW_VIEW, PreviewView } from './preview/view';
import { newReport } from './obsidian/newReport';
import { changeCoverImage, toggleContents, toggleCover, toggleHeader } from './obsidian/cover';
import { SourceToggle } from './obsidian/sourceToggle';
import { importWordReports } from './obsidian/importWord';
import { revealLine } from './obsidian/reveal';
import { MENU_VIEW, MenuView, showMenu } from './obsidian/menu';
import { markdownViews } from './obsidian/views';
import { ErrorLog } from './obsidian/errorLog';
import { NoteZoom } from './obsidian/noteZoom';
import { ChangeLog } from './obsidian/changeLog';
import { LogModal } from './obsidian/logView';
import type { ReportMeta } from './data/meta';
import { setUiLanguage, t } from './i18n';

export interface RenderResult {
  pdf: Uint8Array | null;
  problems: Problem[];
  meta: ReportMeta;
  /** Note lines that still contain ==placeholder== text. */
  placeholders: number[];
}

export default class IctiReportsPlugin extends Plugin {
  settings: Settings = { ...DEFAULT_SETTINGS };
  resources!: Resources;
  noteZoom!: NoteZoom;
  changeLog!: ChangeLog;
  errorLog!: ErrorLog;
  private compiler: Promise<Compiler> | null = null;
  /** Set in onunload: a preview or export still running then must not start a new engine. */
  private unloaded = false;
  private exporting = false;

  async onload(): Promise<void> {
    const dir = this.manifest.dir ?? `${this.app.vault.configDir}/plugins/${this.manifest.id}`;
    this.errorLog = new ErrorLog(this, dir);
    this.errorLog.start();
    try {
      await this.setUp();
    } catch (e) {
      this.errorLog.record('loading the plugin', e);
      throw e;
    }
  }

  /** Everything onload does; errors are written to errors.log before Obsidian reports the plugin as failed. */
  private async setUp(): Promise<void> {
    this.settings = cleanSettings(await this.loadData());
    setUiLanguage(this.settings.uiLanguage === 'en' ? 'en' : 'nl'); // before any command or view is registered
    this.resources = new Resources(this.app, this.manifest.dir ?? `${this.app.vault.configDir}/plugins/${this.manifest.id}`);
    this.addSettingTab(new SettingsTab(this.app, this));
    new SourceToggle(this).start();
    this.changeLog = new ChangeLog(this);
    this.changeLog.start();
    this.addCommand({
      id: 'change-log',
      name: t('Change log'),
      checkCallback: (checking) => {
        const file = this.app.workspace.getActiveFile();
        if (!file || file.extension !== 'md') return false;
        if (!checking) this.showLog(file);
        return true;
      },
    });
    this.noteZoom = new NoteZoom(this);
    this.noteZoom.start();
    const zoomCommand = (id: string, name: string, direction: -1 | 0 | 1) => this.addCommand({
      id,
      name,
      checkCallback: (checking) => {
        if (!this.noteZoom.target()) return false;
        if (!checking) void this.noteZoom.change(direction);
        return true;
      },
    });
    zoomCommand('note-zoom-in', t('Zoom in on the note'), 1);
    zoomCommand('note-zoom-out', t('Zoom out of the note'), -1);
    zoomCommand('note-zoom-reset', t('Reset the note zoom'), 0);
    this.registerView(PREVIEW_VIEW, (leaf) => new PreviewView(leaf, this));
    this.registerView(MENU_VIEW, (leaf) => new MenuView(leaf, this));
    this.addCommand({ id: 'show-menu', name: t('Show ICT Institute menu'), callback: () => void showMenu(this) });
    // First start: the ICT Institute panel above the file list (once; if the user closes it, it stays closed).
    this.app.workspace.onLayoutReady(async () => {
      if (this.settings.menuPlaced) return;
      try {
        await showMenu(this, true);
      } catch (e) {
        this.errorLog.record('placing the ICT Institute menu', e); // not retried at every start
      }
      this.settings.menuPlaced = true;
      await this.saveSettings();
    });

    this.addRibbonIcon('file-down', t('Export report to PDF'), () => void this.exportActive());
    this.addRibbonIcon('file-text', t('Open report preview'), () => void this.openPreview());
    this.addCommand({
      id: 'export-pdf',
      name: t('Export report to PDF'),
      checkCallback: (checking) => {
        const file = this.app.workspace.getActiveFile();
        if (!file || file.extension !== 'md') return false;
        if (!checking) void this.exportFile(file);
        return true;
      },
    });
    this.addCommand({ id: 'open-preview', name: t('Open report preview'), callback: () => void this.openPreview() });
    this.addCommand({ id: 'new-report', name: t('New report'), callback: () => void newReport(this) });
    this.addCommand({ id: 'import-word-report', name: t('Import Word report as template'), callback: () => void importWordReports(this) });
    this.addCommand({
      id: 'toggle-cover',
      name: t('Add or remove cover page'),
      checkCallback: (checking) => {
        const file = this.app.workspace.getActiveFile();
        if (!file || file.extension !== 'md') return false;
        if (!checking) void toggleCover(this, file);
        return true;
      },
    });
    this.addCommand({
      id: 'toggle-header',
      name: t('Add or remove header block'),
      checkCallback: (checking) => {
        const file = this.app.workspace.getActiveFile();
        if (!file || file.extension !== 'md') return false;
        if (!checking) void toggleHeader(this, file);
        return true;
      },
    });
    this.addCommand({
      id: 'toggle-contents',
      name: t('Add or remove table of contents'),
      checkCallback: (checking) => {
        const file = this.app.workspace.getActiveFile();
        if (!file || file.extension !== 'md') return false;
        if (!checking) void toggleContents(this, file);
        return true;
      },
    });
    this.addCommand({
      id: 'change-cover',
      name: t('Change cover image'),
      checkCallback: (checking) => {
        const file = this.app.workspace.getActiveFile();
        if (!file || file.extension !== 'md') return false;
        if (!checking) changeCoverImage(this, file);
        return true;
      },
    });
    this.addRibbonIcon('file-plus', t('New report'), () => void newReport(this));
  }

  /** The change log window of a note. */
  showLog(file: TFile | null): void {
    if (!file) {
      new Notice(t('Open a note to see its change log.'));
      return;
    }
    new LogModal(this, file).open();
  }

  /** Opens the preview in the right sidebar, or reveals it if it is already open. */
  async openPreview(): Promise<void> {
    const { workspace } = this.app;
    let leaf = workspace.getLeavesOfType(PREVIEW_VIEW)[0];
    if (!leaf) {
      leaf = workspace.getRightLeaf(false) ?? workspace.getLeaf('split');
      await leaf.setViewState({ type: PREVIEW_VIEW, active: false });
    }
    await workspace.revealLeaf(leaf);
  }

  onunload(): void {
    this.unloaded = true;
    if (this.saveTimer !== undefined) {
      window.clearTimeout(this.saveTimer);
      void this.writeSettings();
    }
    void this.compiler?.then((c) => c.dispose()).catch(() => {});
    this.compiler = null;
  }

  private saveTimer: number | undefined;
  private saveWaiting: (() => void)[] = [];

  /** Saves the settings half a second after the last change (typing in a field saves once, not per key). data.json
   *  lives in .obsidian and is synced with a shared vault, so it is written as little as possible. */
  saveSettings(): Promise<void> {
    window.clearTimeout(this.saveTimer);
    return new Promise((resolve) => {
      this.saveWaiting.push(resolve);
      this.saveTimer = window.setTimeout(() => void this.writeSettings(), 500);
    });
  }

  private async writeSettings(): Promise<void> {
    this.saveTimer = undefined;
    const waiting = this.saveWaiting.splice(0);
    const { legacyNoteZoom: _legacy, ...data } = this.settings;
    try {
      await this.saveData(data);
    } catch (e) {
      this.errorLog.record('saving settings', e);
    }
    waiting.forEach((r) => r());
  }

  /** data.json was changed outside this window (for example by a sync program): use the new settings. */
  async onExternalSettingsChange(): Promise<void> {
    // Same object: an open settings tab keeps editing the settings that are saved.
    Object.assign(this.settings, cleanSettings(await this.loadData()));
    setUiLanguage(this.settings.uiLanguage);
    this.refreshPreviews();
  }

  /** Re-renders open previews (after a settings field is left, not on every keystroke). */
  refreshPreviews(): void {
    for (const leaf of this.app.workspace.getLeavesOfType(PREVIEW_VIEW)) if (leaf.view instanceof PreviewView) leaf.view.refresh();
  }

  /** Starts the engine on first use (reading ~28 MB of WASM); a crashed or failed engine is forgotten and restarted. */
  private getCompiler(): Promise<Compiler> {
    if (this.unloaded) return Promise.reject(new Error(t('The plugin was turned off.')));
    if (!this.compiler) {
      const p = this.resources.engineFiles().then(({ wasm, fonts }) => startCompiler(workerSource, wasm, fonts));
      const forget = () => {
        if (this.compiler === p) this.compiler = null;
      };
      p.then((c) => c.onDead(forget), forget);
      this.compiler = p;
    }
    return this.compiler.catch((e) => {
      throw new Error(t('The report engine could not start. Is the plugin folder complete (typst.wasm, fonts)? {error}', { error: String(e) }));
    });
  }

  /** Note text -> PDF. Used by export and by the live preview. */
  async render(file: TFile, text: string): Promise<RenderResult> {
    const prepared = await prepare(text, this.resources.host(file.path));
    const layout = await this.resources.layout(this.settings.layoutPath);
    const compiler = await this.getCompiler();
    let result = await compiler.compile(typstFiles(prepared, layout.source, layout.assets));
    const notes = prepared.diagnostics.map(fromNote);
    // An image can pass the header check and still be damaged. Rather than failing the whole PDF, make it again:
    // first with the standard cover picture (the own one may be the damaged image), then, if that is not it,
    // with every note image as a placeholder, and say so.
    const imageError = () => !result.pdf && result.diagnostics.some((d) => /decode image|parse svg|svg/i.test(d.message)) && Object.keys(prepared.images).length > 0;
    const cover = prepared.meta.cover;
    if (imageError() && cover?.image?.startsWith('/img/')) {
      cover.image = DEFAULT_COVER;
      cover.ownImage = false;
      result = await compiler.compile(typstFiles(prepared, layout.source, layout.assets));
      if (result.pdf) {
        notes.push({ severity: 'warning', line: 0, source: 'note', where: t('Images'), message: t('The cover image is damaged, so the standard one is used. Choose another image with "Cover image".') });
      }
    }
    if (imageError()) {
      forEachImage(prepared.blocks, (img) => delete img.src);
      if (cover) {
        cover.image = DEFAULT_COVER;
        cover.ownImage = false;
      }
      prepared.images = {};
      result = await compiler.compile(typstFiles(prepared, layout.source, layout.assets));
      if (result.pdf) {
        notes.push({ severity: 'warning', line: 0, source: 'note', where: t('Images'), message: t('One of the images in this report is damaged, so all images are shown as placeholders. Replace the image that was added or changed last.') });
      }
    }
    if (layout.outdated) {
      notes.push({
        severity: 'warning', line: 0, source: 'layout', where: t('Layout file {name}', { name: layout.name }),
        message: layout.replaced
          ? t('This layout is from before the simple report, so the built-in layout is used instead. Click "Update layout" in the plugin settings to replace it.')
          : t('This layout is older than the plugin, so newer features may not work. Click "Update layout" in the plugin settings.'),
      });
    }
    const problems = [...notes, ...result.diagnostics.map((d) => fromTypst(d, layout.name))];
    return { pdf: result.pdf, problems, meta: prepared.meta, placeholders: prepared.placeholders };
  }

  /** The editor's current text when the note is open in any pane (unsaved changes included), else the file. */
  async noteText(file: TFile): Promise<string> {
    for (const view of markdownViews(this.app)) {
      if (view.file?.path === file.path) return view.editor.getValue();
    }
    return this.app.vault.read(file);
  }

  async exportActive(): Promise<void> {
    const file = this.app.workspace.getActiveFile();
    if (!file || file.extension !== 'md') {
      new Notice(t('Open a report note first.'));
      return;
    }
    await this.exportFile(file);
  }

  /** A presentation note (ICT Institute Presentations): not a report, so no report preview or report PDF. */
  isPresentation(file: TFile): boolean {
    const fm = this.app.metadataCache.getFileCache(file)?.frontmatter;
    const v: unknown = fm?.presentation;
    // MD Slides presentations are marked with `format: md-slides/N`.
    return v === true || v === 'true' || v === 'yes' || (typeof fm?.format === 'string' && /^md-slides\/\d+$/.test(fm.format));
  }

  /** An ISO template (`iso-template: true`) or a template package note (`template-package: true`) of ICT Institute
   *  Templates: not a report either. */
  isIsoTemplate(file: TFile): boolean {
    const fm = this.app.metadataCache.getFileCache(file)?.frontmatter;
    const on = (v: unknown) => v === true || v === 'true' || v === 'yes';
    return on(fm?.['iso-template']) || on(fm?.['template-package']);
  }

  /** Why this note is not shown or exported as a report (a presentation or an ISO template), or null. */
  notAReport(file: TFile, where: 'preview' | 'export'): string | null {
    const note = file.basename;
    if (this.isPresentation(file)) return where === 'preview' ? t('{note} is a presentation: the report preview only shows reports.', { note }) : t('{note} is a presentation, not a report.', { note });
    if (this.isIsoTemplate(file)) return where === 'preview' ? t('{note} is an ISO template: the report preview only shows reports.', { note }) : t('{note} is an ISO template, not a report.', { note });
    return null;
  }

  async exportFile(file: TFile): Promise<void> {
    const why = this.notAReport(file, 'export');
    if (why) {
      new Notice(why);
      return;
    }
    if (this.exporting) {
      new Notice(t('An export is already running.'));
      return;
    }
    if (!isVaultPath(this.settings.outputFolder)) {
      new Notice(t('The PDF folder in the settings must be a folder inside the vault (no "..", no drive letter).'));
      return;
    }
    this.exporting = true;
    const progress = new Notice(t('Exporting report…'), 0);
    try {
      const { pdf, problems, meta, placeholders } = await this.render(file, await this.noteText(file));
      if (!pdf) {
        progress.hide();
        showProblems(t('The PDF could not be made'), problems.filter((p) => p.severity === 'error'));
        return;
      }
      const folder = normalizePath(this.settings.outputFolder || file.parent?.path || '/');
      const target = normalizePath(`${folder === '/' ? '' : folder}/${buildFileName(this.settings.fileNamePattern, meta, file.basename, file.parent?.isRoot() ? '' : file.parent?.name ?? '')}`);
      const existing = this.resources.find(target); // case-insensitive, like the Windows file system
      progress.hide();
      if (existing && !(existing instanceof TFile)) throw new Error(t('{path} is a folder, not a file.', { path: existing.path }));
      // Red placeholder text left? Ask before making a PDF that might go to a client.
      if (placeholders.length) {
        const answer = await ask(this.app, t('This report still has red placeholder text in {n} place(s) (first on line {line}).', { n: placeholders.length, line: placeholders[0] }), [
          ['show', t('Show')],
          ['export', t('Export anyway')],
          ['cancel', t('Cancel')],
        ], 'show');
        if (answer === 'show') await revealLine(this.app, file, placeholders[0]);
        if (answer !== 'export') return;
      }
      if (existing && (await ask(this.app, t('{path} already exists. Replace it?', { path: existing.path }), [['replace', t('Replace')], ['cancel', t('Cancel')]], 'cancel')) !== 'replace') return;
      await this.resources.ensureFolder(folder === '/' ? '' : folder);
      const bytes = pdf.slice().buffer as ArrayBuffer;
      if (existing instanceof TFile) await this.app.vault.modifyBinary(existing, bytes);
      else await this.app.vault.createBinary(target, bytes);
      await this.changeLog.exported(file, target);
      // Errors can still leave a PDF (e.g. unreadable properties): always show what went wrong.
      if (problems.length) showProblems(t('Exported {path} with {n} problem(s)', { path: target, n: problems.length }), problems);
      else new Notice(t('Exported {path}', { path: target }));
    } catch (e) {
      progress.hide();
      console.error('ICT Reports export failed', e);
      new Notice(t('Export failed: {error}', { error: e instanceof Error ? e.message : String(e) }), 10000);
    } finally {
      this.exporting = false;
    }
  }
}

/** Shows up to five problems as plain text (never HTML: messages contain note text). */
function showProblems(title: string, problems: Problem[]): void {
  const lines = problems.slice(0, 5).map(formatProblem);
  if (problems.length > 5) lines.push(t('…and {n} more.', { n: problems.length - 5 }));
  for (const p of problems) console.warn(`ICT Reports: ${formatProblem(p)}`);
  const frag = createFragment((f) => {
    f.createEl('strong', { text: title });
    for (const line of lines) f.createDiv({ text: line });
  });
  new Notice(frag, 15000);
}

/** A question with several answers; resolves with the chosen key, or null when closed. `primary` is highlighted. */
function ask(app: App, question: string, answers: [string, string][], primary: string): Promise<string | null> {
  return new Promise((resolve) => {
    const modal = new Modal(app);
    let answer: string | null = null;
    modal.contentEl.createEl('p', { text: question });
    const buttons = modal.contentEl.createDiv({ cls: 'modal-button-container' });
    answers.forEach(([key, label]) => {
      buttons.createEl('button', { text: label, cls: key === primary ? 'mod-cta' : '' }).addEventListener('click', () => {
        answer = key;
        modal.close();
      });
    });
    modal.onClose = () => resolve(answer);
    modal.open();
  });
}
