// The raw wasm-bindgen module is imported directly (skipping the package's shim, which uses `new Function`).
declare module '@myriaddreamin/typst-ts-web-compiler/pkg/typst_ts_web_compiler.mjs' {
  export * from '@myriaddreamin/typst-ts-web-compiler';
}

// The worker bundle as text, injected by esbuild.config.mjs and started from a Blob URL.
declare module 'icti:worker-source' {
  const source: string;
  export default source;
}
