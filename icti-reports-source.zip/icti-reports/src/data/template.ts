// Report templates are ordinary notes in the templates folder. "New report" copies one and fills in:
//   {{title}}        the document name the consultant typed
//   {{long_date}}    today, written out ("13 november 2026" in a template with `language: nl`, else "November 13 2026")
//   {{date}}         today as YYYY-MM-DD
//   {{year}}         the current year
//   {{folder}}       the name of the folder the report is made in (the client or project folder)
//   {{type}}         the template name
// ({{client}} and {{client_name}} from older templates are the folder name too.)
// In the properties, put tokens inside double quotes ("{{title}}"): values are escaped for that.
// Unknown {{tokens}} are left as they are, so templates can still contain Templater syntax etc.
import { formatDate } from './labels';

export interface TemplateVars {
  type: string;
  folder: string;
  title: string;
  today: Date;
}

export function fillTemplate(text: string, v: TemplateVars): string {
  const pad = (n: number) => String(n).padStart(2, '0');
  const fm = /^(---\r?\n[\s\S]*?\r?\n---[ \t]*(?:\r?\n|$))/.exec(text);
  const nl = !!fm && /^language:\s*["']?nl\b/im.test(fm[1]);
  const values: Record<string, string> = {
    type: v.type,
    folder: v.folder,
    client: v.folder,
    client_name: v.folder,
    title: v.title,
    long_date: formatDate(v.today, nl ? 'nl' : 'en'),
    date: `${v.today.getFullYear()}-${pad(v.today.getMonth() + 1)}-${pad(v.today.getDate())}`,
    year: String(v.today.getFullYear()),
  };
  const fill = (part: string, escape: (s: string) => string) =>
    part.replace(/\{\{\s*(\w+)\s*\}\}/g, (m, key: string) => (key.toLowerCase() in values ? escape(values[key.toLowerCase()]) : m));
  const yamlSafe = (s: string) => s.replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/[\r\n]+/g, ' ');
  return fm ? fill(fm[1], yamlSafe) + fill(text.slice(fm[1].length), (s) => s) : fill(text, (s) => s);
}

/** A safe note or folder name from what the consultant typed (characters Windows or links forbid removed). */
export function noteFileName(typed: string): string {
  // eslint-disable-next-line no-control-regex
  const name = typed.replace(/[<>:"/\\|?*#^[\]\u0000-\u001f]/g, ' ').replace(/\s+/g, ' ').trim();
  return name.replace(/^[ .]+/, '').replace(/[ .]+$/, '').slice(0, 120);
}
