// What the layout needs besides the text: the language, the cover (from the `> [!cover]` block), the page header
// (from the `> [!header]` block) and the title.
// A report has almost no properties: only `language` (en/nl). The table of contents is written in the note itself.
import type { CoverBlock, HeaderBlock, Inline } from '../convert/ast';
import { LABELS, type Labels, type Lang } from './labels';

export interface CoverMeta {
  title: Inline[];
  lines: Inline[][];
  /** Image reference as written in the note; empty = the default cover picture. */
  imageRef: string;
  /** Virtual path of the picture, set by prepare() (the default picture when the note has none, for older layouts). */
  image?: string;
  /** The note has a usable picture of its own (layouts 9 and 10 left the laptop screen white otherwise). */
  ownImage?: boolean;
}

export interface ReportMeta {
  lang: Lang;
  labels: Labels;
  /** Plain-text title: the cover's title, else the `title` property, else the note's name (the PDF's title). */
  title: string;
  /** The two lines at the top left of the inner pages: the header block's lines, else the title and an empty line. */
  header: Inline[][];
  /** Today (or the `date` property) as YYYYMMDD, for the PDF file name. */
  isoDate: string;
  /** Null: the report has no cover page. */
  cover: CoverMeta | null;
  /** Always false: there is no automatic table of contents any more (layouts 7-12 still read this field). */
  contents: false;
}

export type Props = Record<string, unknown>;

export function str(v: unknown): string {
  if (v === null || v === undefined) return '';
  if (Array.isArray(v)) return v.map(str).join(', ');
  return String(v).trim();
}

/** The text of inline content, without formatting. */
export function plainText(nodes: Inline[]): string {
  return nodes.map((n) => (n.t === 'text' || n.t === 'code' ? n.v : n.t === 'br' ? ' ' : 'c' in n ? plainText(n.c) : '')).join('').replace(/\s+/g, ' ').trim();
}

export function buildMeta(props: Props, cover: CoverBlock | null, noteName: string, today: Date = new Date(), header: HeaderBlock | null = null): ReportMeta {
  const lang: Lang = str(props.language).toLowerCase() === 'nl' ? 'nl' : 'en';
  const pad = (n: number) => String(n).padStart(2, '0');
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(str(props.date));
  const isoDate = m ? `${m[1]}${m[2]}${m[3]}` : `${today.getFullYear()}${pad(today.getMonth() + 1)}${pad(today.getDate())}`;
  const title = (cover && plainText(cover.title)) || str(props.title) || noteName;
  return {
    lang,
    labels: LABELS[lang],
    title,
    header: header ? [header.lines[0] ?? [], header.lines[1] ?? []] : [[{ t: 'text', v: title }], []],
    isoDate,
    cover: cover ? { title: cover.title, lines: cover.lines, imageRef: cover.image?.ref ?? '' } : null,
    contents: false,
  };
}
