// Finding and editing the `> [!cover]` and `> [!header]` blocks in a note's text (pure, so it can be tested without Obsidian).
import { joinInVault } from '../pipeline';

export interface CoverLines {
  /** First line of the block (the "> [!cover]" line), 0-based. */
  start: number;
  /** The line after the block. */
  end: number;
  /** The block's line that holds only a picture ("> ![…](…)" or "> ![[…]]"), or -1. */
  imageLine: number;
}

const COVER_START = /^\s*>\s*\[!cover\]/i;
const HEADER_START = /^\s*>\s*\[!header\]/i;
const CONTENTS_START = /^\s*>\s*\[!(inhoud|inhoudsopgave|contents|toc)\]/i;
const QUOTE_LINE = /^\s*>/;
const IMAGE_LINE = /^\s*>\s*!\[(?:\[[^\]]*\]\]|[^\]]*\]\([^)]*\))\s*$/;

/** The first cover block in the lines, skipping code blocks; null when there is none. */
export function findCoverBlock(lines: string[]): CoverLines | null {
  return findBlock(lines, 'cover');
}

/** The first `> [!cover]` or `> [!header]` block in the lines, skipping code blocks; null when there is none. */
export function findBlock(lines: string[], kind: 'cover' | 'header' | 'contents'): CoverLines | null {
  const start = kind === 'cover' ? COVER_START : kind === 'header' ? HEADER_START : CONTENTS_START;
  let fence: string | null = null;
  for (let i = 0; i < lines.length; i++) {
    const fenceMark = /^\s*(```|~~~)/.exec(lines[i])?.[1];
    if (fenceMark) {
      fence = fence === null ? fenceMark : fence === fenceMark ? null : fence;
      continue;
    }
    if (fence !== null || !start.test(lines[i])) continue;
    let end = i + 1;
    while (end < lines.length && QUOTE_LINE.test(lines[end])) end++;
    let imageLine = -1;
    for (let j = i + 1; j < end; j++) {
      if (IMAGE_LINE.test(lines[j])) {
        imageLine = j;
        break;
      }
    }
    return { start: i, end, imageLine };
  }
  return null;
}

/**
 * The note's text with `imageLine` ("> ![Cover](…)") directly under the "> [!cover]" line, when the note has a cover
 * block without a picture; otherwise the text is returned unchanged. So the picture a cover uses is always visible in
 * the Markdown.
 */
export function withCoverImage(text: string, imageLine: string): string {
  const eol = text.includes('\r\n') ? '\r\n' : '\n';
  const lines = text.split(/\r?\n/);
  const block = findCoverBlock(lines);
  if (!block || block.imageLine >= 0) return text;
  lines.splice(block.start + 1, 0, imageLine);
  return lines.join(eol);
}

/**
 * The note's text with the cover picture's relative path rewritten for a note in another folder: a template's
 * `> ![Cover](../Opmaak/assets/x.png)` points from the templates folder, but the report is made elsewhere.
 * Only a Markdown image with a relative path that resolves to an existing file (`exists`) is changed; `![[x.png]]`
 * links (found by name) and anything else stay as they are.
 */
export function rebaseCoverImage(text: string, fromFolder: string, toFolder: string, exists: (vaultPath: string) => boolean): string {
  const eol = text.includes('\r\n') ? '\r\n' : '\n';
  const lines = text.split(/\r?\n/);
  const block = findCoverBlock(lines);
  if (!block || block.imageLine < 0) return text;
  const m = /^(\s*>\s*!\[[^\]]*\]\()([^)]*)(\)\s*)$/.exec(lines[block.imageLine]);
  if (!m || /^[a-z][a-z0-9+.-]*:/i.test(m[2]) || m[2].startsWith('/')) return text;
  let ref = m[2].trim().replace(/^<(.*)>$/, '$1');
  try {
    ref = decodeURIComponent(ref);
  } catch {
    return text;
  }
  const target = joinInVault(fromFolder, ref);
  if (!target || !exists(target)) return text;
  lines[block.imageLine] = `${m[1]}${markdownImagePath(toFolder, target)}${m[3]}`;
  return lines.join(eol);
}

/**
 * The picture's path as written in a Markdown image, relative to the note's folder ("../Images/logo%20blue.png"),
 * so it also works in other Markdown programs. Spaces and characters that would end the link are encoded.
 */
export function markdownImagePath(noteFolder: string, imagePath: string): string {
  const from = noteFolder.split('/').filter(Boolean);
  const to = imagePath.split('/').filter(Boolean);
  let same = 0;
  while (same < from.length && same < to.length - 1 && from[same] === to[same]) same++;
  const rel = [...Array(from.length - same).fill('..'), ...to.slice(same)].join('/');
  return rel.replace(/[%\s()<>#]/g, (c) => `%${c.charCodeAt(0).toString(16).toUpperCase().padStart(2, '0')}`);
}
