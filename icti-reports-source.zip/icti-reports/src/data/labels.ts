export type Lang = 'en' | 'nl';

export interface Labels {
  contents: string;
  imageMissing: string;
}

export const LABELS: Record<Lang, Labels> = {
  en: { contents: 'Contents', imageMissing: 'Image not found' },
  nl: { contents: 'Inhoud', imageMissing: 'Afbeelding niet gevonden' },
};

const MONTHS: Record<Lang, string[]> = {
  en: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
  nl: ['januari', 'februari', 'maart', 'april', 'mei', 'juni', 'juli', 'augustus', 'september', 'oktober', 'november', 'december'],
};

/** "November 9 2026" (en) or "9 november 2026" (nl). */
export function formatDate(d: Date, lang: Lang): string {
  const month = MONTHS[lang][d.getMonth()];
  return lang === 'nl' ? `${d.getDate()} ${month} ${d.getFullYear()}` : `${month} ${d.getDate()} ${d.getFullYear()}`;
}

/** Parses YYYY-MM-DD (as written by Obsidian's date property) as a local date; null when invalid. */
export function parseDate(v: unknown): Date | null {
  if (v instanceof Date) return isNaN(v.getTime()) ? null : v;
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(v ?? '').trim());
  if (!m) return null;
  const d = new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]));
  return d.getMonth() === Number(m[2]) - 1 ? d : null;
}
