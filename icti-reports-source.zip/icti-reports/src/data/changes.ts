// What changed between two versions of a note, in words a reader of the change log understands:
// which chapters (headings) and which properties changed, and how much text was added and removed.
// Pure functions without Obsidian, so they can be tested.

export interface ChangeSummary {
  /** Headings whose section text changed, was added or was removed, in document order. */
  chapters: string[];
  /** Property names that were changed, added or removed. */
  properties: string[];
  /** Characters added and removed (an estimate from a line comparison). */
  added: number;
  removed: number;
}

export interface LogEntry {
  /** ISO time the action happened (for an editing session: when it started). */
  time: string;
  /** ISO time of the last change in an editing session. */
  end?: string;
  author: string;
  kind: 'created' | 'edited' | 'renamed' | 'exported';
  /** Editing session: what changed. */
  chapters?: string[];
  properties?: string[];
  added?: number;
  removed?: number;
  /** Renamed: the old and new note path. Exported: the PDF path in `to`. */
  from?: string;
  to?: string;
  /** Editing session: exactly what changed (old and new property values, removed and added lines). */
  details?: ChangeDetails;
  /** Identifies an open editing session, so later saves update the same entry. */
  session?: string;
}

/** Splits a note into its properties block (between the --- lines at the top) and the body. */
export function splitNote(text: string): { frontmatter: string; body: string } {
  const m = /^---\r?\n([\s\S]*?)\r?\n---[ \t]*(?:\r?\n|$)/.exec(text);
  return m ? { frontmatter: m[1], body: text.slice(m[0].length) } : { frontmatter: '', body: text };
}

/** Top-level properties as raw text per key (a key line plus its indented or list continuation lines). */
export function propertyBlocks(frontmatter: string): Map<string, string> {
  const out = new Map<string, string>();
  let key: string | null = null;
  for (const line of frontmatter.split(/\r?\n/)) {
    const m = /^([^\s#:][^:]*?)\s*:(.*)$/.exec(line);
    if (m && !/^\s/.test(line) && !line.startsWith('- ')) {
      key = m[1].trim().replace(/^["']|["']$/g, '');
      out.set(key, m[2].trim());
    } else if (key !== null) {
      out.set(key, `${out.get(key)}\n${line.trim()}`);
    }
  }
  return out;
}

/** The body split into sections: the text before the first heading ("") and one section per heading. */
export function sections(body: string): { heading: string; text: string }[] {
  const out: { heading: string; text: string }[] = [{ heading: '', text: '' }];
  let inCode = false;
  for (const line of body.split(/\r?\n/)) {
    if (/^\s*(```|~~~)/.test(line)) inCode = !inCode;
    const h = !inCode && /^#{1,6}\s+(.+?)\s*#*\s*$/.exec(line);
    if (h) out.push({ heading: h[1].replace(/==/g, '').trim(), text: '' });
    else out[out.length - 1].text += `${line}\n`;
  }
  return out;
}

/** Characters added and removed, from a comparison of lines (common lines at the start and end are skipped). */
export function textDelta(before: string, after: string): { added: number; removed: number } {
  const a = before.split(/\r?\n/);
  const b = after.split(/\r?\n/);
  let start = 0;
  while (start < a.length && start < b.length && a[start] === b[start]) start++;
  let endA = a.length;
  let endB = b.length;
  while (endA > start && endB > start && a[endA - 1] === b[endB - 1]) {
    endA--;
    endB--;
  }
  const midA = a.slice(start, endA);
  const midB = b.slice(start, endB);
  // The same number of lines changed: compare them line by line, so a small edit counts as a few characters.
  if (midA.length === midB.length) {
    let added = 0;
    let removed = 0;
    midA.forEach((x, i) => {
      const d = charDelta(x, midB[i]);
      added += d.added;
      removed += d.removed;
    });
    return { added, removed };
  }
  // Otherwise count whole lines; lines present on both sides (moved) do not count.
  const count = new Map<string, number>();
  for (const l of midA) count.set(l, (count.get(l) ?? 0) + 1);
  let added = 0;
  for (const l of midB) {
    const n = count.get(l) ?? 0;
    if (n > 0) count.set(l, n - 1);
    else added += l.length + 1;
  }
  let removed = 0;
  for (const [l, n] of count) removed += n * (l.length + 1);
  return { added, removed };
}

/** Characters added and removed within one edited line (common start and end skipped). */
function charDelta(x: string, y: string): { added: number; removed: number } {
  let s = 0;
  while (s < x.length && s < y.length && x[s] === y[s]) s++;
  let ex = x.length;
  let ey = y.length;
  while (ex > s && ey > s && x[ex - 1] === y[ey - 1]) {
    ex--;
    ey--;
  }
  return { added: ey - s, removed: ex - s };
}

/** What changed from `before` to `after`. */
export function summarize(before: string, after: string): ChangeSummary {
  const a = splitNote(before);
  const b = splitNote(after);
  const pa = propertyBlocks(a.frontmatter);
  const pb = propertyBlocks(b.frontmatter);
  const properties = [...new Set([...pa.keys(), ...pb.keys()])].filter((k) => pa.get(k) !== pb.get(k));

  const sa = sections(a.body);
  const sb = sections(b.body);
  const textOf = (list: { heading: string; text: string }[], heading: string, nth: number) =>
    list.filter((s) => s.heading === heading)[nth]?.text;
  const chapters: string[] = [];
  const seen = new Map<string, number>();
  for (const s of sb) {
    const nth = seen.get(s.heading) ?? 0;
    seen.set(s.heading, nth + 1);
    const old = textOf(sa, s.heading, nth);
    if (old === undefined || old.trim() !== s.text.trim()) chapters.push(s.heading);
  }
  const kept = new Map<string, number>();
  for (const s of sb) kept.set(s.heading, (kept.get(s.heading) ?? 0) + 1);
  const gone = new Map<string, number>();
  for (const s of sa) {
    const n = (gone.get(s.heading) ?? 0) + 1;
    gone.set(s.heading, n);
    if (n > (kept.get(s.heading) ?? 0) && !chapters.includes(s.heading)) chapters.push(s.heading);
  }
  return { chapters, properties, ...textDelta(a.body, b.body) };
}

/** The log file name for a note path: the path with "/" and "%" escaped, so every note has its own file. */
export function logFileName(notePath: string): string {
  return `${notePath.replace(/%/g, '%25').replace(/\//g, '%2F')}.json`;
}

export interface PropertyChange {
  name: string;
  /** The raw value before and after ('' when the property did not exist). */
  before: string;
  after: string;
}

export interface TextChange {
  /** The heading of the chapter the change is in ('' = before the first heading). */
  chapter: string;
  removed: string[];
  added: string[];
}

export interface ChangeDetails {
  properties: PropertyChange[];
  text: TextChange[];
  /** True when the text changes were cut off at MAX_DETAIL_LINES. */
  truncated?: boolean;
}

/** At most this many changed lines are kept per log entry (a pasted chapter is shown, a whole new report is cut off). */
export const MAX_DETAIL_LINES = 300;

/** Line operations from a longest-common-subsequence comparison. */
function lineOps(a: string[], b: string[]): { op: 'eq' | 'del' | 'add'; line: string; at: number }[] {
  let start = 0;
  while (start < a.length && start < b.length && a[start] === b[start]) start++;
  let endA = a.length;
  let endB = b.length;
  while (endA > start && endB > start && a[endA - 1] === b[endB - 1]) {
    endA--;
    endB--;
  }
  const A = a.slice(start, endA);
  const B = b.slice(start, endB);
  const ops: { op: 'eq' | 'del' | 'add'; line: string; at: number }[] = [];
  for (let i = 0; i < start; i++) ops.push({ op: 'eq', line: a[i], at: i });
  if (A.length * B.length > 4_000_000) {
    // Very large change: show it as one replaced block instead of comparing line by line.
    A.forEach((line) => ops.push({ op: 'del', line, at: start }));
    B.forEach((line, j) => ops.push({ op: 'add', line, at: start + j }));
  } else {
    // lcs[i][j] = length of the longest common subsequence of A[i..] and B[j..]
    const lcs: Uint32Array[] = Array.from({ length: A.length + 1 }, () => new Uint32Array(B.length + 1));
    for (let i = A.length - 1; i >= 0; i--) {
      for (let j = B.length - 1; j >= 0; j--) {
        lcs[i][j] = A[i] === B[j] ? lcs[i + 1][j + 1] + 1 : Math.max(lcs[i + 1][j], lcs[i][j + 1]);
      }
    }
    let i = 0;
    let j = 0;
    while (i < A.length || j < B.length) {
      if (i < A.length && j < B.length && A[i] === B[j]) {
        ops.push({ op: 'eq', line: A[i], at: start + j });
        i++;
        j++;
      } else if (j < B.length && (i >= A.length || lcs[i][j + 1] >= lcs[i + 1][j])) {
        ops.push({ op: 'add', line: B[j], at: start + j });
        j++;
      } else {
        ops.push({ op: 'del', line: A[i], at: start + j });
        i++;
      }
    }
  }
  for (let k = endA; k < a.length; k++) ops.push({ op: 'eq', line: a[k], at: endB + (k - endA) });
  return ops;
}

/** Exactly what changed from `before` to `after`: every changed property with its old and new value, and the
 *  removed and added lines of the text, grouped per chapter. */
export function changeDetails(before: string, after: string): ChangeDetails {
  const a = splitNote(before);
  const b = splitNote(after);
  const pa = propertyBlocks(a.frontmatter);
  const pb = propertyBlocks(b.frontmatter);
  const properties = [...new Set([...pa.keys(), ...pb.keys()])]
    .filter((k) => pa.get(k) !== pb.get(k))
    .map((name) => ({ name, before: pa.get(name) ?? '', after: pb.get(name) ?? '' }));

  const bl = b.body.split(/\r?\n/);
  // The chapter of each line of the new text.
  const chapterAt: string[] = [];
  let current = '';
  bl.forEach((line, i) => {
    const h = /^#{1,6}\s+(.+?)\s*#*\s*$/.exec(line);
    if (h) current = h[1].replace(/==/g, '').trim();
    chapterAt[i] = current;
  });
  const text: TextChange[] = [];
  let hunk: TextChange | null = null;
  let lines = 0;
  let truncated = false;
  for (const o of lineOps(a.body.split(/\r?\n/), bl)) {
    if (o.op === 'eq') {
      hunk = null;
      continue;
    }
    if (lines >= MAX_DETAIL_LINES) {
      truncated = true;
      break;
    }
    if (!hunk) {
      hunk = { chapter: chapterAt[Math.min(o.at, bl.length - 1)] ?? '', removed: [], added: [] };
      text.push(hunk);
    }
    (o.op === 'del' ? hunk.removed : hunk.added).push(o.line);
    lines++;
  }
  // Empty lines at the edges of a change are noise; changes of only empty lines are not worth showing.
  const trim = (l: string[]) => {
    let i = 0;
    let j = l.length;
    while (i < j && !l[i].trim()) i++;
    while (j > i && !l[j - 1].trim()) j--;
    return l.slice(i, j);
  };
  const shown = text
    .map((h) => ({ ...h, removed: trim(h.removed), added: trim(h.added) }))
    .filter((h) => h.removed.length || h.added.length);
  return truncated ? { properties, text: shown, truncated } : { properties, text: shown };
}
