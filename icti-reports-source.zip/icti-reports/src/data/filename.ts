import type { ReportMeta } from './meta';

export const DEFAULT_PATTERN = '{date}_{folder}_{note}';
/** Older defaults; saved settings with one of them are moved to DEFAULT_PATTERN. */
export const OLD_DEFAULT_PATTERNS = ['{date}_{client}_{project}_{document}', '{date}_{client}_{note}'];

/**
 * Builds the PDF file name from the pattern in the settings.
 * Tokens: {date} (YYYYMMDD: today, or the date property), {folder} (the name of the folder the note is in, such as
 * the client or project folder; {client} is the old name), {title}, {note} (the note name = the document name).
 * Empty tokens are dropped together with a separator next to them; characters Windows forbids become "-".
 */
export function buildFileName(pattern: string, meta: ReportMeta, noteName: string, folderName = ''): string {
  const tokens: Record<string, string> = {
    date: meta.isoDate,
    folder: folderName,
    client: folderName,
    title: meta.title,
    note: noteName,
  };
  let name = (pattern.trim() || DEFAULT_PATTERN).replace(/\{(\w+)\}/g, (m, key: string) =>
    key.toLowerCase() in tokens ? sanitize(tokens[key.toLowerCase()]) : m,
  );
  name = name
    .replace(/([_\- ])\1+/g, '$1') // "20261109__X" when a token is empty
    .replace(/^[_\- .]+|[_\- .]+$/g, '');
  name = sanitize(name).slice(0, 150).replace(/[ .]+$/, '');
  if (/^(con|prn|aux|nul|com\d|lpt\d)$/i.test(name)) name = `_${name}`;
  return `${name || sanitize(noteName) || 'report'}.pdf`;
}

function sanitize(s: string): string {
  // eslint-disable-next-line no-control-regex
  return s.replace(/[<>:"/\\|?*\u0000-\u001f]/g, '-').replace(/\s+/g, ' ').trim();
}
