// Minimal YAML reader for flat Obsidian properties (CLI and tests only; the plugin uses Obsidian's parseYaml).
// Supports `key: value`, `key: [a, b]`, block lists (`- item`), quoted strings, true/false and numbers.
export function parseSimpleYaml(src: string): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  let listKey: string | null = null;
  for (const raw of src.split(/\r?\n/)) {
    if (!raw.trim() || raw.trim().startsWith('#')) continue;
    const item = /^\s+-\s*(.*)$/.exec(raw) ?? /^-\s+(.*)$/.exec(raw);
    if (item && listKey) {
      (out[listKey] as unknown[]).push(scalar(item[1]));
      continue;
    }
    const kv = /^([A-Za-z0-9_-]+):\s*(.*)$/.exec(raw);
    if (!kv) throw new Error(`Cannot read property line: ${raw}`);
    const [, key, value] = kv;
    listKey = null;
    if (value === '') {
      out[key] = [];
      listKey = key;
    } else if (value.startsWith('[') && value.endsWith(']')) {
      out[key] = splitFlow(value.slice(1, -1)).map(scalar);
    } else {
      out[key] = scalar(value);
    }
  }
  return out;
}

function splitFlow(s: string): string[] {
  const parts: string[] = [];
  let cur = '';
  let quote = '';
  let depth = 0;
  for (const ch of s) {
    if (quote) {
      if (ch === quote) quote = '';
    } else if (ch === '"' || ch === "'") quote = ch;
    else if (ch === '[') depth++;
    else if (ch === ']') depth--;
    else if (ch === ',' && depth === 0) {
      parts.push(cur);
      cur = '';
      continue;
    }
    cur += ch;
  }
  if (cur.trim()) parts.push(cur);
  return parts.map((p) => p.trim());
}

function scalar(v: string): unknown {
  const s = v.trim();
  if (/^".*"$/.test(s)) return s.slice(1, -1).replace(/\\"/g, '"');
  if (/^'.*'$/.test(s)) return s.slice(1, -1).replace(/''/g, "'");
  if (s === 'true') return true;
  if (s === 'false') return false;
  if (s === '' || s === 'null' || s === '~') return null;
  if (/^-?\d+(\.\d+)?$/.test(s)) return Number(s);
  return s;
}
