// Offline check: scans the built plugin for anything that could reach the network.
// Every hit must match an explained allowlist entry, otherwise the check fails.
import { readFileSync } from 'node:fs';

const FILES = ['dist/icti-reports/main.js', 'dist/icti-reports/layout/report.typ', 'dist/themes/ICT Institute/theme.css', 'dist/snippets/ICT Institute - ribbon labels.css'];
const PATTERN = /https?:\/\/[^\s'"`)]*|fetch\(|XMLHttpRequest|WebSocket|EventSource|sendBeacon|importScripts|cdn\.|jsdelivr|unpkg|child_process|\beval\(|new Function\b|\brequire\(\s*["'][^"']+["']\s*\)/g;
const ALLOWED = [
  // markdown-it normalises/validates link text; it builds these strings but never requests them.
  { re: /^https?:\/\/(\$\{|$)/, why: 'markdown-it / linkify-it: string prefix used when normalising link text' },
  { re: /^https?:\/\/(\w+\.)?github\.com\//, why: 'source comment / error text from a bundled library' },
  { re: /^require\(\s*["']obsidian["']\s*\)$/, why: 'the Obsidian API itself' },
  // @xmldom/xmldom (Word import) names the standard XML namespaces; they are identifiers, never fetched.
  { re: /^http:\/\/www\.w3\.org\/(1999\/xhtml|2000\/svg|XML\/1998\/namespace|2000\/xmlns\/)$/, why: 'XML namespace identifiers in @xmldom/xmldom (not requested)' },
  // wasm-bindgen glue inside the worker source: builds JS functions from fixed strings in typst.wasm, never from note text.
  { re: /^new Function$/, why: 'wasm-bindgen glue (__wbg_new_no_args / __wbg_new_with_args) in the worker: bodies come from the WASM binary' },
];

let failed = false;
for (const file of FILES) {
  const src = readFileSync(file, 'utf8');
  for (const m of src.matchAll(PATTERN)) {
    const hit = m[0];
    const ok = ALLOWED.find((a) => a.re.test(hit));
    const ctx = src.slice(Math.max(0, m.index - 40), m.index + 60).replace(/\s+/g, ' ');
    if (ok) console.log(`ok    ${file}: ${hit}  -- ${ok.why}`);
    else {
      failed = true;
      console.log(`FAIL  ${file}: ${hit}\n      ...${ctx}...`);
    }
  }
}
console.log(failed ? '\nOffline check FAILED' : '\nOffline check passed');
process.exit(failed ? 1 : 0);
