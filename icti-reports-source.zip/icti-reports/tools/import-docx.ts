// Developer check of the Word import: node out/import-docx.mjs <file.docx> <outDir>
// Writes the template note and its pictures to outDir (never into a vault).
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { basename, join } from 'node:path';
import { convertDocx, fillImages } from '../src/import/docx';
import { templateBaseName, templateNote } from '../src/import/template';

const [file, outDir] = process.argv.slice(2);
mkdirSync(outDir, { recursive: true });
const doc = await convertDocx(new Uint8Array(readFileSync(file)));
const base = templateBaseName(basename(file));
const names = new Map<number, string>();
for (const [n, img] of doc.images) {
  const name = `${base} ${n}.${img.ext}`;
  writeFileSync(join(outDir, name), img.data);
  names.set(n, name);
}
writeFileSync(join(outDir, `${base}.md`), templateNote({ title: doc.title, subtitle: doc.subtitle, language: doc.language, body: fillImages(doc.body, names) }));
console.log(JSON.stringify({ title: doc.title, subtitle: doc.subtitle, language: doc.language, images: doc.images.size, left: doc.left, warnings: doc.warnings, chars: doc.body.length }));
