"""Dev tool: looks up the licence of every Rust crate compiled into typst.wasm (names/versions are read
from the binary into out/crates.txt) on crates.io and writes tools/crate-licenses.json.
Run only when the Typst engine version changes."""
import json, re, sys, time, urllib.request
crates = [l.strip() for l in open('out/crates.txt') if l.strip()]
out = {}
for c in crates:
    m = re.match(r'^(.*)-(\d+\.\d+\.\d+.*)$', c)
    name, ver = m.group(1), m.group(2)
    req = urllib.request.Request(f'https://crates.io/api/v1/crates/{name}/{ver}', headers={'User-Agent': 'icti-reports-notices (internal build tool)'})
    try:
        d = json.load(urllib.request.urlopen(req, timeout=20))['version']
        out[c] = {'name': name, 'version': ver, 'license': d.get('license') or '?', 'repository': ''}
    except Exception as e:
        out[c] = {'name': name, 'version': ver, 'license': f'? ({e})', 'repository': ''}
    time.sleep(1.0)
json.dump(out, open('tools/crate-licenses.json', 'w'), indent=1)
lic = {}
for v in out.values(): lic[v['license']] = lic.get(v['license'], 0) + 1
for k, n in sorted(lic.items(), key=lambda x: -x[1]): print(n, k)
