"""Compare our PDF with the Word reference: 150 dpi rasters, an overlay per page, and text-line offsets.

usage: py tools/compare.py ours.pdf reference.pdf [outdir]
Overlay colours: reference in red, ours in blue; where both have ink the pixel is dark.
"""
import sys, os, re
import pdfplumber
from PIL import Image, ImageChops, ImageOps
sys.path.insert(0, os.path.dirname(__file__))
from measure import lines

def norm(s):
    return re.sub(r'\s+', ' ', s.replace('’', "'")).strip()

def raster(page):
    return page.to_image(resolution=150).original.convert('L')

def main(ours_path, ref_path, outdir='out/compare'):
    os.makedirs(outdir, exist_ok=True)
    ours, ref = pdfplumber.open(ours_path), pdfplumber.open(ref_path)
    print(f'pages: ours {len(ours.pages)}, reference {len(ref.pages)}')
    for i in range(max(len(ours.pages), len(ref.pages))):
        print(f'\n=== page {i+1}')
        if i >= len(ours.pages) or i >= len(ref.pages):
            print('  (missing on one side)'); continue
        a, b = raster(ours.pages[i]), raster(ref.pages[i])
        b = b.resize(a.size)
        # Overlay: R channel = ours, G/B = reference => ref-only ink red, ours-only ink cyan/blue
        overlay = Image.merge('RGB', (a, b, b))
        overlay.save(f'{outdir}/overlay-p{i+1}.png')
        side = Image.new('L', (a.width * 2, a.height), 255); side.paste(a, (0, 0)); side.paste(b, (a.width, 0))
        side.save(f'{outdir}/side-p{i+1}.png')
        diff = ImageChops.difference(a, b)
        pct = sum(1 for p in diff.getdata() if p > 64) / (a.width * a.height) * 100
        print(f'  pixels differing: {pct:.2f}%')
        ol = [l for l in lines(ours.pages[i]) if norm(l[6])]
        rl = [l for l in lines(ref.pages[i]) if norm(l[6])]
        used = set()
        for r in rl:
            key = norm(r[6])[:18]
            if len(key) < 2: continue
            match = next((o for j, o in enumerate(ol) if j not in used and norm(o[6]).startswith(key)), None)
            if match is None:
                print(f'  ref only : y{r[1]:6.1f} x{r[0]:6.1f} {r[3]} {r[4]} {norm(r[6])[:50]!r}')
                continue
            used.add(ol.index(match))
            dx, dy, dw = match[0] - r[0], match[1] - r[1], (match[2] - match[0]) - (r[2] - r[0])
            flag = '' if abs(dx) < 1 and abs(dy) < 1 else '  <--'
            print(f'  dy{dy:+6.1f} dx{dx:+6.1f} dw{dw:+6.1f}  y{r[1]:6.1f} {match[3][:18]:18} {match[4]:4} {norm(r[6])[:40]!r}{flag}')
        for j, o in enumerate(ol):
            if j not in used:
                print(f'  ours only: y{o[1]:6.1f} x{o[0]:6.1f} {o[3]} {o[4]} {norm(o[6])[:50]!r}')

if __name__ == '__main__':
    main(*sys.argv[1:])
