// node tools/install-test-vault.mjs [vaultDir] [--fixtures]: copies the built plugin (keeping its settings,
// data.json), the theme and the snippet into a test vault (default ../Test Vault) and enables them there.
// --fixtures also copies the test notes from tests/fixtures/vault into the vault root.
import { cpSync, existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
const args = process.argv.slice(2);
const vault = args.find((a) => !a.startsWith('--')) ?? '../Test Vault';
if (!existsSync(`${vault}/.obsidian`)) throw new Error(`${vault} is not an Obsidian vault`);
const plugin = `${vault}/.obsidian/plugins/icti-reports`;
const settingsFile = `${plugin}/data.json`;
const settings = existsSync(settingsFile) ? readFileSync(settingsFile) : null;
rmSync(plugin, { recursive: true, force: true });
mkdirSync(plugin, { recursive: true });
cpSync('dist/icti-reports', plugin, { recursive: true });
if (settings) writeFileSync(settingsFile, settings);
// Enable the plugin next to the plugins already enabled (e.g. icti-presentations).
const listFile = `${vault}/.obsidian/community-plugins.json`;
let enabled = [];
try {
  enabled = JSON.parse(readFileSync(listFile, 'utf8'));
} catch {
  // missing or empty
}
if (!enabled.includes('icti-reports')) writeFileSync(listFile, JSON.stringify([...enabled, 'icti-reports']));
if (args.includes('--fixtures')) cpSync('tests/fixtures/vault', vault, { recursive: true, filter: (src) => !src.endsWith('.pdf') });
// The ICT Institute theme, switched on in the test vault.
const theme = `${vault}/.obsidian/themes/ICT Institute`;
rmSync(theme, { recursive: true, force: true });
cpSync('dist/themes/ICT Institute', theme, { recursive: true });
const appearanceFile = `${vault}/.obsidian/appearance.json`;
let appearance = {};
try {
  appearance = JSON.parse(readFileSync(appearanceFile, 'utf8'));
} catch {
  // missing or empty (Obsidian can leave it empty when it is closed while writing)
}
mkdirSync(`${vault}/.obsidian/snippets`, { recursive: true });
cpSync('dist/snippets/ICT Institute - ribbon labels.css', `${vault}/.obsidian/snippets/ICT Institute - ribbon labels.css`);
const snippets = new Set([...(appearance.enabledCssSnippets ?? []), 'ICT Institute - ribbon labels']);
writeFileSync(appearanceFile, JSON.stringify({ ...appearance, cssTheme: 'ICT Institute', enabledCssSnippets: [...snippets] }, null, 2));
console.log(`installed into ${vault}`);
