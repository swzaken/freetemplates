// CLI: render a note to PDF with the same engine and layout as the plugin.
//   npm run render -- <note.md> [out.pdf] [--vault <dir>]
import { existsSync, readFileSync, readdirSync, statSync, writeFileSync } from 'node:fs';
import { basename, dirname, isAbsolute, join, relative, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { TypstEngine } from '../src/engine/typst';
import { prepare, typstFiles } from '../src/pipeline';
import { parseSimpleYaml } from './simple-yaml';

// Repo root: works for tools/render.ts (tests) and out/render.mjs (bundled CLI).
const ROOT = fileURLToPath(new URL('..', import.meta.url));

function findFile(dir: string, name: string): string | null {
  for (const e of readdirSync(dir)) {
    const p = join(dir, e);
    if (statSync(p).isDirectory()) {
      if (!e.startsWith('.')) {
        const hit = findFile(p, name);
        if (hit) return hit;
      }
    } else if (e.toLowerCase() === name.toLowerCase()) return p;
  }
  return null;
}

let enginePromise: Promise<TypstEngine> | null = null;

function engine(): Promise<TypstEngine> {
  enginePromise ??= (async () => {
    const wasm = readFileSync(join(ROOT, 'node_modules/@myriaddreamin/typst-ts-web-compiler/pkg/typst_ts_web_compiler_bg.wasm'));
    const fontDir = join(ROOT, 'assets/fonts');
    const fonts = readdirSync(fontDir).filter((f) => f.endsWith('.ttf')).map((f) => new Uint8Array(readFileSync(join(fontDir, f))));
    return TypstEngine.create(wasm, fonts);
  })();
  return enginePromise;
}

export async function renderNote(notePath: string, vault: string, today?: Date) {
  const img = (f: string) => new Uint8Array(readFileSync(join(ROOT, 'assets/img', f)));
  const assets = Object.fromEntries(['header-logo.png', 'cover-default.png'].map((f) => [`/assets/${f}`, img(f)]));

  const prepared = await prepare(readFileSync(notePath, 'utf8'), {
    parseYaml: parseSimpleYaml,
    today,
    noteName: basename(notePath, '.md'),
    readImage: async (ref) => {
      // Relative to the note, but never outside the vault folder; else by name anywhere in the vault.
      const rel = relative(resolve(vault), resolve(dirname(notePath), ref));
      const direct = rel && !rel.startsWith('..') && !isAbsolute(rel) ? join(vault, rel) : null;
      const p = direct && existsSync(direct) ? direct : ref.split(/[\\/]/).includes('..') ? null : findFile(vault, basename(ref));
      return p ? new Uint8Array(readFileSync(p)) : null;
    },
  });
  const layout = readFileSync(join(ROOT, 'layout/report.typ'), 'utf8');
  const files = typstFiles(prepared, layout, assets);
  const e = await engine();
  return { ...e.compile(files), prepared, files, engine: e };
}

const isMain = process.argv[1] && /render\.(mjs|ts)$/.test(process.argv[1]);
if (isMain) {
  const args = process.argv.slice(2);
  const vi = args.indexOf('--vault');
  const vault = vi >= 0 ? args.splice(vi, 2)[1] : null;
  const [note, out] = args;
  if (!note) {
    console.error('usage: render <note.md> [out.pdf] [--vault <dir>]');
    process.exit(2);
  }
  const t0 = Date.now();
  const r = await renderNote(note, vault ?? dirname(note));
  for (const d of r.prepared.diagnostics) console.warn(`note line ${d.line}: ${d.severity}: ${d.message}`);
  for (const d of r.diagnostics) console.warn(`${d.path}:${d.line}: ${d.severity}: ${d.message}`);
  if (!r.pdf) process.exit(1);
  const target = out ?? note.replace(/\.md$/, '.pdf');
  writeFileSync(target, r.pdf);
  console.log(`wrote ${target} (${r.pdf.length} bytes) in ${Date.now() - t0} ms`);
}
