"""Dump text lines (x0, top, x1, font, size), rects and images of a PDF, for layout comparison."""
import sys, pdfplumber
from itertools import groupby

def lines(page):
    chars = sorted(page.chars, key=lambda c: (round(c['top']), c['x0']))
    for top, grp in groupby(chars, key=lambda c: round(c['top'])):
        grp = list(grp)
        # split runs by font/size
        runs, cur = [], [grp[0]]
        for ch in grp[1:]:
            if ch['fontname'] == cur[-1]['fontname'] and abs(ch['size'] - cur[-1]['size']) < 0.05 and ch['x0'] - cur[-1]['x1'] < 8:
                cur.append(ch)
            else:
                runs.append(cur); cur = [ch]
        runs.append(cur)
        for r in runs:
            col = r[0].get('non_stroking_color')
            yield (round(r[0]["x0"],1), round(page.height - r[0]["matrix"][5],1), round(r[-1]['x1'],1), r[0]['fontname'].split('+')[-1], round(r[0]['size'],1), col, ''.join(c['text'] for c in r))

if __name__ == '__main__':
    pdf = pdfplumber.open(sys.argv[1])
    only = int(sys.argv[2]) if len(sys.argv) > 2 else None
    for i, p in enumerate(pdf.pages, 1):
        if only and i != only: continue
        print(f'=== page {i}')
        for l in lines(p): print(*l[:5], l[5], repr(l[6][:70]))
        for r in p.rects: print('RECT', round(r['x0'],1), round(r['top'],1), round(r['width'],1), round(r['height'],1), 'fill', r.get('non_stroking_color'), 'stroke', r.get('stroking_color'), r.get('linewidth'))
        for im in p.images: print('IMG', round(im['x0'],1), round(im['top'],1), round(im['width'],1), round(im['height'],1))
