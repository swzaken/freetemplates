// node tools/notices.mjs: writes THIRD_PARTY_NOTICES.md for everything that ships in dist/icti-reports.
// Inputs: the npm packages esbuild bundles (with their own licence files), the Rust crates compiled into
// typst.wasm (tools/crate-licenses.json, made by tools/crate-licenses.py), the fonts' OFL texts and the
// standard licence texts in licenses/.
import { readFileSync, readdirSync, writeFileSync } from 'node:fs';

const NPM = ['markdown-it', 'mdurl', 'uc.micro', 'linkify-it', 'punycode.js', 'entities'];
const pkg = (name) => JSON.parse(readFileSync(`node_modules/${name}/package.json`, 'utf8'));
const licenceFile = (name) => {
  const f = readdirSync(`node_modules/${name}`).find((x) => /^licen[cs]e/i.test(x));
  return f ? readFileSync(`node_modules/${name}/${f}`, 'utf8').trim() : null;
};
const engine = pkg('@myriaddreamin/typst-ts-web-compiler');
const crates = Object.values(JSON.parse(readFileSync('tools/crate-licenses.json', 'utf8'))).sort((a, b) => a.name.localeCompare(b.name));

const out = [];
out.push('# Third-party notices', '');
out.push('The ICT Institute Reports plugin folder contains the following third-party components. They are used unmodified, except that the build removes the "load the engine from a URL" code path from the typst.ts JavaScript glue (the plugin always loads typst.wasm from its own folder).');
out.push('The placeholder cover picture and logo in assets/img were made for this repository and fall under its licence (see LICENSE).', '');
out.push('| Component | Version | Licence | Where |', '|---|---|---|---|');
out.push(`| Typst compiler (WASM build by typst.ts, @myriaddreamin/typst-ts-web-compiler) | ${engine.version} (Typst 0.14.2) | ${engine.license} | typst.wasm, main.js |`);
for (const n of NPM) out.push(`| ${n} | ${pkg(n).version} | ${pkg(n).license} | main.js |`);
out.push('| Carlito font | Google Fonts | OFL-1.1 | fonts/Carlito-*.ttf |');
out.push('| Open Sans font | googlefonts/opensans | OFL-1.1 | fonts/OpenSans-*.ttf; embedded as WOFF2 in the ICT Institute theme (themes/ICT Institute/theme.css, with OFL-OpenSans.txt) |');
out.push(`| ${crates.length} Rust crates compiled into the Typst WASM | see below | permissive (see below) | typst.wasm |`, '');

out.push('## Typst and typst.ts', '');
out.push(`typst.wasm is the npm package @myriaddreamin/typst-ts-web-compiler ${engine.version} (https://github.com/Myriad-Dreamin/typst.ts), which compiles the Typst typesetting system (https://github.com/typst/typst). Both are licensed under the Apache License 2.0; its full text is at the end of this file.`, '');

out.push('### Data inside typst.wasm', '');
out.push('The Typst engine embeds data files from typst-assets and hayagriva: Citation Style Language (CSL) bibliography styles and locales, licensed CC BY-SA 3.0 by the Citation Style Language project and the style authors (https://citationstyles.org, https://creativecommons.org/licenses/by-sa/3.0/), and hyphenation patterns under their own permissive licences. The plugin does not use bibliographies or hyphenation, but the data ships inside the engine binary.', '');
out.push('## npm packages bundled in main.js', '');
for (const n of NPM) {
  out.push(`### ${n} ${pkg(n).version} (${pkg(n).license})`, '', '```', licenceFile(n) ?? `Licence: ${pkg(n).license}`, '```', '');
}

out.push('## Fonts', '');
for (const [name, file] of [['Carlito', 'OFL-Carlito.txt'], ['Open Sans', 'OFL-OpenSans.txt']]) {
  out.push(`### ${name} (SIL Open Font License 1.1)`, '', '```', readFileSync(`assets/fonts/${file}`, 'utf8').trim(), '```', '');
}

out.push('## Rust crates inside typst.wasm', '');
out.push('Names and versions are read from the WASM binary; licences are the SPDX expressions published on crates.io. Where a crate offers a choice ("MIT OR Apache-2.0"), any of the listed licences applies. The standard licence texts follow below.', '');
out.push('| Crate | Version | Licence |', '|---|---|---|');
for (const c of crates) out.push(`| ${c.name} | ${c.version} | ${c.license} |`);
out.push('');

out.push('## Licence texts', '');
for (const f of readdirSync('licenses').sort()) {
  out.push(`### ${f.replace(/\.txt$/, '')}`, '', '```', readFileSync(`licenses/${f}`, 'utf8').trim(), '```', '');
}
writeFileSync('THIRD_PARTY_NOTICES.md', out.join('\n'));
console.log(`wrote THIRD_PARTY_NOTICES.md (${crates.length} crates, ${NPM.length} npm packages, 2 fonts)`);
