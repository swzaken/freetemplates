// Builds dist/themes/ICT Institute/ (copy it into <vault>/.obsidian/themes/): theme.css with Open Sans
// embedded as WOFF2 data URLs, so the theme works offline, plus manifest.json and the font licence.
import { cpSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';

const out = 'dist/themes/ICT Institute';
const faces = [
  ['OpenSans-Regular', 400, 'normal'],
  ['OpenSans-Italic', 400, 'italic'],
  ['OpenSans-SemiBold', 600, 'normal'],
  ['OpenSans-Bold', 700, 'normal'],
  ['OpenSans-BoldItalic', 700, 'italic'],
];
const fontCss = faces.map(([file, weight, style]) => {
  const b64 = readFileSync(`theme/fonts/${file}.woff2`).toString('base64');
  return `@font-face {\n  font-family: 'Open Sans';\n  font-weight: ${weight};\n  font-style: ${style};\n  font-display: swap;\n  src: url(data:font/woff2;base64,${b64}) format('woff2');\n}`;
}).join('\n');

const src = readFileSync('theme/theme.src.css', 'utf8');
const marker = '/* @fonts (replaced by the build with the embedded Open Sans @font-face rules) */';
if (!src.includes(marker)) throw new Error('font marker missing in theme.src.css');
rmSync(out, { recursive: true, force: true });
mkdirSync(out, { recursive: true });
writeFileSync(`${out}/theme.css`, src.replace(marker, fontCss));
cpSync('theme/manifest.json', `${out}/manifest.json`);
cpSync('theme/fonts/OFL-OpenSans.txt', `${out}/OFL-OpenSans.txt`);
// The ribbon labels snippet: a separate CSS file for <vault>/.obsidian/snippets/ (works with any theme).
mkdirSync('dist/snippets', { recursive: true });
writeFileSync('dist/snippets/ICT Institute - ribbon labels.css', readFileSync('theme/ribbon-labels.css', 'utf8'));
console.log(`built ${out} and dist/snippets`);
